$file = $args[0]
$user = $args[1]
$permission = $args[2]

$members = @()
Get-Acl $file | select -ExpandProperty Access | ForEach-Object { $members += $_.IdentityReference.ToString() }
if ($members -contains $user.ToUpper())
{
    Write-Output "changed=no comment='User object is already in the ACL.'"
}
else
{
    $acl = (Get-Item $file).GetAccessControl('Access')
    if ((Get-Item $file) -is [System.IO.DirectoryInfo])
    {
        $ar = New-Object System.Security.AccessControl.FileSystemAccessRule($user, $permission, 'ContainerInherit, ObjectInherit', 'InheritOnly', 'Allow')
    }
    else
    {
        $ar = New-Object System.Security.AccessControl.FileSystemAccessRule($user, $permission, 'None', 'None', 'Allow')
    }
    $acl.SetAccessRule($ar)
    Set-Acl $file $acl
    Write-Output "changed=yes comment='User object added to ACL.'"
}