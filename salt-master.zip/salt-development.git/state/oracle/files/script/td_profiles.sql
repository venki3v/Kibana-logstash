drop profile TD_ACF2_DEFAULT_PROFILE;
drop profile TD_PROXY_DEFAULT_PROFILE;


CREATE PROFILE TD_ACF2_DEFAULT_PROFILE LIMIT
   FAILED_LOGIN_ATTEMPTS    4
   PASSWORD_LIFE_TIME       90
   PASSWORD_REUSE_TIME      30
   PASSWORD_REUSE_MAX       5
   PASSWORD_VERIFY_FUNCTION TD_PWD_VERIFY_FUNC
   PASSWORD_LOCK_TIME       30
   PASSWORD_GRACE_TIME      3;

CREATE PROFILE TD_PROXY_DEFAULT_PROFILE LIMIT
   FAILED_LOGIN_ATTEMPTS    UNLIMITED
   PASSWORD_LIFE_TIME       UNLIMITED
   PASSWORD_REUSE_TIME      30
   PASSWORD_REUSE_MAX       5
   PASSWORD_LOCK_TIME       30
   PASSWORD_GRACE_TIME      3
   PASSWORD_VERIFY_FUNCTION TD_PWD_VERIFY_FUNC;

alter profile td_acf2_default_profile limit FAILED_LOGIN_ATTEMPTS 5;
alter profile td_acf2_default_profile limit PASSWORD_LIFE_TIME 28;
alter profile td_acf2_default_profile limit PASSWORD_REUSE_TIME 280;
alter profile td_acf2_default_profile limit PASSWORD_REUSE_MAX 5;
alter profile td_acf2_default_profile limit PASSWORD_LOCK_TIME UNLIMITED;
alter profile td_acf2_default_profile limit PASSWORD_GRACE_TIME 10;


alter profile td_proxy_default_profile limit FAILED_LOGIN_ATTEMPTS UNLIMITED;
alter profile td_proxy_default_profile limit PASSWORD_LIFE_TIME UNLIMITED;
alter profile td_proxy_default_profile limit PASSWORD_REUSE_TIME 280;
alter profile td_proxy_default_profile limit PASSWORD_REUSE_MAX 5;
alter profile td_proxy_default_profile limit PASSWORD_LOCK_TIME UNLIMITED;
alter profile td_proxy_default_profile limit PASSWORD_GRACE_TIME 10;
