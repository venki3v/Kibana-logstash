-- ------------------------------------------------------------------
-- Name : TD_PWD_VERIFY_FUNC
-- DESC : password verification function to satisfy TRMIS requirements
--        Generally we like length 8 with at least 1 numeric 
--        This function must be created in SYS schema.
-- HIST : 
--        2007.09.06 Ling Zhu New
--        2007.10.19 Ling Zhu 
--             disabled : check if it has at least 1 punctuation 
--             modified : check if it has at least 2 number 
--             modified : check if it's more than 8 chars
-- ------------------------------------------------------------------

CREATE OR REPLACE FUNCTION TD_PWD_VERIFY_FUNC
(username varchar2,
  password varchar2,
  old_password varchar2)
  RETURN boolean IS
   n boolean;
   m integer;
   differ integer;
   isdigit boolean;
   ischar  boolean;
   ispunct boolean;
   digitarray varchar2(20);
   punctarray varchar2(25);
   chararray varchar2(52);
   numchar integer;

BEGIN
   digitarray:= '0123456789';
   chararray:= 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
   punctarray:='!"#$%&()``*+,-/:;<=>?_';

   -- Check if the password is same as the username
   IF NLS_LOWER(password) = NLS_LOWER(username) THEN
     raise_application_error(-20001, 'Password same as or similar to user');
   END IF;

   -- Check for the minimum length of the password
   IF length(password) < 8 THEN
      raise_application_error(-20002, 'Password length less than 8');
   END IF;

   -- Check if the password is too simple. A dictionary of words may be
   -- maintained and a check may be made so as not to allow the words
   -- that are too simple for the password.
   IF NLS_LOWER(password) IN ('welcome', 'database', 'account', 'user', 'password', 'oracle', 'computer', 'abcd') THEN
      raise_application_error(-20002, 'Password too simple');
   END IF;

   -- Check if the password contains at least one letter, one digit and one
   -- punctuation mark.
   -- 1. Check for the digit      
   
   -- isdigit:=FALSE;
   -- m := length(password);
   -- FOR i IN 1..10 LOOP
   --    FOR j IN 1..m LOOP
   --       IF substr(password,j,1) = substr(digitarray,i,1) THEN
   --          isdigit:=TRUE;
   --           GOTO findchar;
   --       END IF;
   --    END LOOP;
   -- END LOOP;
   -- IF isdigit = FALSE THEN
   --    raise_application_error(-20003, 'Password should contain at least one digits, one character and one punctuation');
   -- END IF;
   
   isdigit:=FALSE;
   numchar:=0;
   m := length(password);
   FOR i IN 1..10 LOOP
      FOR j IN 1..m LOOP
         IF substr(password,j,1) = substr(digitarray,i,1) THEN
         		numchar := numchar + 1;
         		if (numchar >=2 ) then
         			isdigit:=TRUE;
            	GOTO findchar;
            end if;
         END IF;
      END LOOP;
   END LOOP;
   IF isdigit = FALSE THEN
      raise_application_error(-20003, 'Password should contain at least two digit, and one character');
   END IF;
   
   -- 2. Check for the character
   <<findchar>>
   ischar:=FALSE;
   FOR i IN 1..length(chararray) LOOP
      FOR j IN 1..m LOOP
         IF substr(password,j,1) = substr(chararray,i,1) THEN
            ischar:=TRUE;
             GOTO findpunct;
         END IF;
      END LOOP;
   END LOOP;
   IF ischar = FALSE THEN
      raise_application_error(-20003, 'Password should contain at least two digits, and one character');
   END IF;
   -- 3. Check for the punctuation
   <<findpunct>>
   -- TRMIS not require Debbie Johnson Oct 19, 2007
   -- ispunct:=FALSE;
   -- FOR i IN 1..length(punctarray) LOOP
   --    FOR j IN 1..m LOOP
   --       IF substr(password,j,1) = substr(punctarray,i,1) THEN
   --          ispunct:=TRUE;
   --           GOTO endsearch;
   --       END IF;
   --    END LOOP;
   -- END LOOP;
   -- IF ispunct = FALSE THEN
   --    raise_application_error(-20003, 'Password should contain at least two digits, one character and one punctuation');
   -- END IF;

   <<endsearch>>
   -- Check if the password differs from the previous password by at least
   -- 3 letters
   IF old_password IS NOT NULL THEN
     differ := length(old_password) - length(password);

     IF abs(differ) < 3 THEN
       IF length(password) < length(old_password) THEN
         m := length(password);
       ELSE
         m := length(old_password);
       END IF;

       differ := abs(differ);
       FOR i IN 1..m LOOP
         IF substr(password,i,1) != substr(old_password,i,1) THEN
           differ := differ + 1;
         END IF;
       END LOOP;

       IF differ < 3 THEN
         raise_application_error(-20004, 'Password should differ by at \
         least 3 characters');
       END IF;
     END IF;
   END IF;
   -- Everything is fine; return TRUE ;
   RETURN(TRUE);
END;
/

-- This script alters the default parameters for Password Management
-- This means that all the users on the system have Password Management
-- enabled and set to the following values unless another profile is
-- created with parameter values set to different value or UNLIMITED
-- is created and assigned to the user.

-- ALTER PROFILE DEFAULT LIMIT
-- PASSWORD_LIFE_TIME 60
-- PASSWORD_GRACE_TIME 10
-- PASSWORD_REUSE_TIME 1800
-- PASSWORD_REUSE_MAX UNLIMITED
-- FAILED_LOGIN_ATTEMPTS 3
-- PASSWORD_LOCK_TIME 1/1440
-- PASSWORD_VERIFY_FUNCTION verify_function;


