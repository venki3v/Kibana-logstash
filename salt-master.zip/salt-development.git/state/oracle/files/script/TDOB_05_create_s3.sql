set echo off
set feedback off
set verify off
set linesize 200
set trimspool on
set serveroutput on size 1000000

--define sqlplus_password
-- accept sqlplus_password char prompt 'Enter password for S3 acccounts:'
set termout off
col defpw new_value 1
select null defpw from dual where 1=2;
select nvl('&1','S3pwd06!defp6d22') defpw from dual;
set termout on
 
spool 05_setup_l3_ids.log
declare
    PROD BOOLEAN := FALSE;
    type table_varchar is table of varchar(30);
    l3_ids table_varchar;
    l3_role varchar2(30) := 'S3DBA';
    v_password varchar2(30):='"&1"';
    v_user varchar2(30);
    tmp_count number;
    v_account_status varchar2(32);
    cyberark_id varchar2(30) := 'S3ORACB';
begin
    l3_ids := table_varchar('S3ORA01','S3ORA02','S3ORA03','S3ORA04','S3ORA05','S3ORA06');
   

    -- Check l3 role and create if it does not exist
    begin
        dbms_output.put('Role ' || l3_role);
        select 1 into tmp_count from dba_roles where role = l3_role;
        dbms_output.put_line(' already exists');
    exception when no_data_found then
        execute immediate 'create role '|| l3_role;
        execute immediate 'grant CREATE SESSION to ' || l3_role;
        execute immediate 'grant DBA to ' || l3_role;
        dbms_output.put_line(' created');
    end;

    -- blank line
    dbms_output.put(CHR(10));


    -- loop trough l3 users
    for u in 1..l3_ids.count loop 
    begin
        v_user := l3_ids(u);
        dbms_output.put('User ' || v_user);

        -- Check if user exists
	begin
            select account_status into v_account_status from dba_users where username=v_user;
            dbms_output.put_line('   ... OK');

            -- Gabriel - added unlimited tablespace to allow exp-imp
            -- for users that already exists
            execute immediate 'grant UNLIMITED TABLESPACE to ' || v_user;

	exception when no_data_found then
            dbms_output.put_line('   ... created');
            execute immediate 'create user ' || v_user || ' identified by ' || v_password || ' default tablespace users profile TD_PROXY_DEFAULT_PROFILE';
            execute immediate 'grant ' || l3_role || ' to ' || v_user;
            execute immediate 'grant UNLIMITED TABLESPACE to ' || v_user;
        end;
    end;
    end loop;


    -- blank line
    dbms_output.put(CHR(10));


    -- Check Cyberark user
    dbms_output.put('Cyberark user ' || cyberark_id);
    begin
        select account_status into v_account_status from dba_users where username=cyberark_id;
        dbms_output.put_line('   ... OK');
    exception when no_data_found then
        dbms_output.put_line('   ... created');
        execute immediate 'create user ' || cyberark_id || ' identified by ' || v_password || ' default tablespace users profile TD_PROXY_DEFAULT_PROFILE';
        execute immediate 'grant CREATE SESSION to ' || cyberark_id;
        execute immediate 'grant ALTER USER to ' || cyberark_id;
    end;


    -- blank line
    dbms_output.put(CHR(10));
end;
/

prompt
prompt
prompt S3 roles:
select role from dba_roles where role like 'S3DBA%';

prompt
prompt
prompt L3 IDs:
select username,created,profile from dba_users
where username like 'S3ORA%'
order by username;

spool off


!chmod 600 05_setup_l3_ids.log

