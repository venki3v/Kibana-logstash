set echo on

-- spool ./create_itm_user_role.log

drop user tivoli cascade;

drop role tivoli_role;

create user tivoli identified by &1 
default tablespace users temporary tablespace temp
profile TD_PROXY_DEFAULT_PROFILE;

grant create session to tivoli;

create role tivoli_role;

-- spool off

