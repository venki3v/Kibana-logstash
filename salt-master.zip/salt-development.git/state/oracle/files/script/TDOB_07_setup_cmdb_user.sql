spool 07_create_cmdb_user.log
set echo on
set timing on
select name,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') from v$database; 

grant connect, create synonym to svc_cmdb identified by values 'E759891BFCD77E60';
 
alter user svc_cmdb
 profile td_proxy_default_profile
 temporary tablespace temp 
 default tablespace users; 
 
GRANT SELECT ON sys.v_$version TO SVC_CMDB;
GRANT SELECT ON sys.gv_$version TO SVC_CMDB;
 
GRANT SELECT ON sys.v_$datafile TO SVC_CMDB;
GRANT SELECT ON sys.gv_$datafile TO SVC_CMDB;
 
GRANT SELECT ON sys.v_$log TO SVC_CMDB; 
GRANT SELECT ON sys.gv_$log TO SVC_CMDB; 
 
GRANT SELECT ON sys.v_$logfile TO SVC_CMDB; 
GRANT SELECT ON sys.gv_$logfile TO SVC_CMDB;
 
GRANT SELECT ON sys.v_$recover_file TO SVC_CMDB;
GRANT SELECT ON sys.gv_$recover_file TO SVC_CMDB;
 
GRANT SELECT ON sys.v_$backup TO SVC_CMDB;
GRANT SELECT ON sys.gv_$backup TO SVC_CMDB;
 
GRANT SELECT ON sys.v_$session TO SVC_CMDB;
GRANT SELECT ON sys.gv_$session TO SVC_CMDB;
 
GRANT SELECT ON sys.v_$controlfile TO SVC_CMDB;
GRANT SELECT ON sys.gv_$controlfile TO SVC_CMDB;
 
GRANT SELECT ON sys.v_$database TO SVC_CMDB; 
GRANT SELECT ON sys.gv_$database TO SVC_CMDB; 
 
GRANT SELECT ON sys.v_$parameter TO SVC_CMDB;
GRANT SELECT ON sys.gv_$parameter TO SVC_CMDB;
 
GRANT SELECT ON sys.v_$instance TO SVC_CMDB; 
GRANT SELECT ON sys.gv_$instance TO SVC_CMDB; 
 
GRANT SELECT ON sys.v_$spparameter TO SVC_CMDB;
GRANT SELECT ON sys.gv_$spparameter TO SVC_CMDB;
 
grant select on dba_scheduler_jobs to SVC_CMDB;
 
spool off;
