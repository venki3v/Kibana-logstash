set echo off
set feedback off
set linesize 200
set trimspool on
set serveroutput on size 1000000

col username format a30
col profile format a30
col instance_name format a20
col host_name format a30
col account_status format a15


alter session set nls_date_format='DD/MM/YYYY HH24:MI:SS';

spool setup_l2_ids.log

select instance_name,host_name from v$instance;
prompt

declare
    PROD BOOLEAN := TRUE;
    type table_varchar is table of varchar(30);
    delete_accounts table_varchar;
    eng_dba table_varchar;
    drt_dba table_varchar;
    v_user varchar2(30);
    v_account_status varchar2(32);
    role_eng varchar2(30) := 'S2ENGINEERING';
    role_drt varchar2(30) := 'S2OPERATION';
    tmp_count number;
    db_version number(2);
    v_os_authent_prefix varchar2(30);
    drt_count number;
    eng_count number;
    delete_count number;
begin
    -- get DB version
    select replace(substr(banner,6,2),'.','') into db_version from v$version where banner like 'CORE%';

    -- these accounts are delete if they exist as they are for US DBAs or managers or ex-DBAs
    delete_accounts := table_varchar('KENANJ2','KATAPP2','BOTTOD2','FRATTT2','SURAPS2','PENKG2','WHITCR2','KANA3','TURUTR2','NELSOG2','RASHIM3','DOBREC2','KUMARN2','LOMANA2');
    delete_count := delete_accounts.count;

    eng_dba := table_varchar('CRISAC2','CUNLID2','DAIT2','LIH6','TANGY3','XUS4','ZHUL2','SONGP2','XUY3');
    eng_count := eng_dba.count;

    drt_dba := table_varchar('BACALS2','KHANN6','PAULOG2','ZHENGS3','NAYAKK3','RAFIQM2','ROYCHD2','ZHIVOA2');
    drt_count := drt_dba.count;


    -- Check os_authent_prefix, change it to empty
    -- if not empty create OPS$users too
    select value into v_os_authent_prefix from v$parameter where name='os_authent_prefix';
    if v_os_authent_prefix<>' ' then 
        execute immediate 'alter system set os_authent_prefix='''' scope=spfile sid=''*''';
        /* COMMENT OUT - don't create OPS$ users
        tmp_count := 0;
        for r in 1..drt_count loop
            tmp_count := tmp_count + 1;
            drt_dba.extend;
            drt_dba(drt_count+tmp_count) := upper(v_os_authent_prefix || drt_dba(r));
        end loop;
        */
     end if;

    --
    

    -- Check drt role and create if it does not exist
    begin
        dbms_output.put('Role ' || role_drt);
        select 1 into tmp_count from dba_roles where role = role_drt;
        dbms_output.put_line(' already exists');
    exception when no_data_found then
        execute immediate 'create role '|| role_drt;
        execute immediate 'grant CREATE SESSION to ' || role_drt;
        execute immediate 'grant ALTER SESSION to ' || role_drt;
        execute immediate 'grant SELECT ANY DICTIONARY to ' || role_drt;
        execute immediate 'grant SELECT ANY TABLE to ' || role_drt;
        if PROD then
            execute immediate 'grant ALTER USER to ' || role_drt;
        end if;
        if db_version > 9 then
            execute immediate 'grant EXECUTE ON DBMS_WORKLOAD_REPOSITORY to ' || role_drt;
        end if;
        dbms_output.put_line(' created');
    end;


/*
COMMENTED OUT - not touching any former DB Eng stuff
    -- PROD - 
    if PROD then
        -- add eng_dba into delete_accounts
        tmp_count := 0;
        for r in 1..eng_count loop
            tmp_count := tmp_count + 1;
            delete_accounts.extend;
            delete_accounts(delete_count+tmp_count) := eng_dba(r);
        end loop;
    --non-PROD
    else
        -- Check Eng role and create if it does not exist
        begin
            dbms_output.put('Role ' || role_eng);
            select 1 into tmp_count from dba_roles where role = role_eng;
            dbms_output.put_line(' already exists');
        exception when no_data_found then
            execute immediate 'create role '|| role_eng;
            execute immediate 'grant CREATE SESSION to ' || role_eng;
            execute immediate 'grant ALTER SESSION to ' || role_eng;
            execute immediate 'grant SELECT ANY DICTIONARY to ' || role_eng;
            execute immediate 'grant SELECT ANY TABLE to ' || role_eng;
            if db_version > 9 then
                execute immediate 'grant EXECUTE ON DBMS_WORKLOAD_REPOSITORY to ' || role_eng;
            end if;
            dbms_output.put_line(' created');
            -- blank line
            dbms_output.put(CHR(10));
         end;
    end if;
END COMMENT OUT
*/

    -- blank line
    dbms_output.put(CHR(10));


    -- delete users from delete list if they exists
    dbms_output.put_line('Check for users to delete');
    for u in 1..delete_accounts.count loop
    begin
        v_user := delete_accounts(u);
        -- Check if user exists
        begin
            select account_status into v_account_status from dba_users where username=v_user;
            dbms_output.put_line('Deleting ' || v_user);
            -- catch errors when droping users
            begin
                execute immediate 'drop user ' || v_user;
            exception when others then
                dbms_output.put_line('   ... user drop failed');
            end;
        exception when no_data_found then
            null;
        end;
    end;
    end loop;

    -- blank line
    dbms_output.put(CHR(10));



    -- loop trough drt dba users
    for u in 1..drt_dba.count loop 
    begin
        v_user := drt_dba(u);
        dbms_output.put('User ' || v_user);

        -- Check if user exists
	begin
            select account_status into v_account_status from dba_users where username=v_user;
            dbms_output.put_line('   ... exists');
            if v_account_status='LOCKED' then
                execute immediate 'alter user ' || v_user || ' identified by dsfhjdffj349545' || to_char(sysdate,'DDMMYYYYHH24MISS') || ' account unlock profile TD_ACF2_DEFAULT_PROFILE';
                execute immediate 'alter user ' || v_user || ' identified externally';
            end if;
	exception when no_data_found then
            dbms_output.put_line('   ... created');
            execute immediate 'create user ' || v_user || ' identified externally default tablespace users profile TD_ACF2_DEFAULT_PROFILE';
        end;


        -- User exists, revoke all existing privileges
        for r in (select privilege from dba_sys_privs where grantee=v_user) loop
            dbms_output.put_line('... revoke ' || r.privilege);
            execute immediate 'revoke ' || r.privilege || ' from ' || v_user;
        end loop; 
        for r in (select granted_role from dba_role_privs where grantee=v_user and granted_role<>role_drt) loop
            dbms_output.put_line('... revoke ' || r.granted_role);
            execute immediate 'revoke ' || r.granted_role || ' from ' || v_user;
        end loop; 
        for r in (select owner,table_name,privilege,grantable from dba_tab_privs where grantee=v_user) loop
            select count(*) into tmp_count from dba_tab_privs 
                where owner=r.owner and table_name=r.table_name and privilege=r.privilege and grantor=v_user;
            if r.grantable='YES' and tmp_count >0 then
               dbms_output.put_line('!!! GRANTABLE privilege ' || r.privilege || ' on ' || r.owner || '.' || r.table_name || ' - grant count:' || tmp_count);
            else
                dbms_output.put_line('... revoke ' || r.privilege || ' on ' || r.owner || '.' || r.table_name);
                if r.privilege = 'READ' or r.privilege='WRITE' then
                    execute immediate 'revoke ' || r.privilege || ' on directory ' || r.owner || '.' || r.table_name || ' from ' || v_user;
                else
                    execute immediate 'revoke ' || r.privilege || ' on ' || r.owner || '.' || r.table_name || ' from ' || v_user;
                end if;
            end if;
        end loop; 

        -- Grant drt role
        dbms_output.put_line('... grant ' || role_drt);
        execute immediate 'grant ' || role_drt || ' to ' || v_user;


	-- Check objects owned by the DBA
        tmp_count := 0;
        select count(*) into tmp_count from dba_objects where owner=v_user;
        if tmp_count>0 then
            dbms_output.put_line('!!! User objects - need manual cleanup:');
            for r in (select owner,object_type,object_name from dba_objects
                      where owner=v_user order by object_type, object_name) loop
                dbms_output.put_line('... ' || r.owner || '.' ||  r.object_name || '   ' || r.object_type);
            end loop;
        end if;

    end;
    end loop;


    -- blank line
    dbms_output.put(CHR(10));

/*
COMMENTED OUT - not touching any former DB Eng stuff
-- non-PROD
-- non-PROD
-- if non-PROD loop dbeng dba
if not(PROD) then
    -- loop trough eng dba users
    for u in 1..eng_dba.count loop 
    begin
        v_user := eng_dba(u);
        dbms_output.put('User ' || v_user);

        -- Check if user exists
	begin
            select account_status into v_account_status from dba_users where username=v_user;
            dbms_output.put_line('   ... fixing privileges');
            execute immediate 'alter user ' || v_user || ' profile TD_ACF2_DEFAULT_PROFILE';
	exception when no_data_found then
            dbms_output.put_line('   ... created');
            execute immediate 'create user ' || v_user || ' identified externally default tablespace users profile TD_ACF2_DEFAULT_PROFILE';
        end;


        -- User exists, revoke all existing privileges
        for r in (select privilege from dba_sys_privs where grantee=v_user) loop
            dbms_output.put_line('... revoke ' || r.privilege);
            execute immediate 'revoke ' || r.privilege || ' from ' || v_user;
        end loop; 
        for r in (select granted_role from dba_role_privs where grantee=v_user and granted_role<>role_eng) loop
            dbms_output.put_line('... revoke ' || r.granted_role);
            execute immediate 'revoke ' || r.granted_role || ' from ' || v_user;
        end loop; 
        for r in (select owner,table_name,privilege,grantable from dba_tab_privs where grantee=v_user) loop
            select count(*) into tmp_count from dba_tab_privs 
                where owner=r.owner and table_name=r.table_name and privilege=r.privilege and grantor=v_user;
            if r.grantable='YES' and tmp_count >0 then
               dbms_output.put_line('!!! GRANTABLE privilege ' || r.privilege || ' on ' || r.owner || '.' || r.table_name || ' - grant count:' || tmp_count);
            else
                dbms_output.put_line('... revoke ' || r.privilege || ' on ' || r.owner || '.' || r.table_name);
                if r.privilege = 'READ' or r.privilege='WRITE' then
                    execute immediate 'revoke ' || r.privilege || ' on directory ' || r.owner || '.' || r.table_name || ' from ' || v_user;
                else
                    execute immediate 'revoke ' || r.privilege || ' on ' || r.owner || '.' || r.table_name || ' from ' || v_user;
                end if;
            end if;
        end loop; 

        -- Grant eng role
        dbms_output.put_line('... grant ' || role_eng);
        execute immediate 'grant ' || role_eng || ' to ' || v_user;
    end;
    end loop;
end if;
END COMMENT OUT
*/


    -- blank line
    dbms_output.put(CHR(10));


    -- Show any other users with DBA role granted
    tmp_count := 0;
    select count(*) into tmp_count from dba_users
              where username not in ('SYS','SYSTEM') and
                    username in (select distinct grantee from dba_role_privs
                                 where granted_role='DBA');
    if tmp_count > 0 then
        dbms_output.put_line('Other IDs with DBA role granted: ' || to_char(tmp_count));
        for r in (select username,account_status from dba_users
                  where username not in ('SYS','SYSTEM') and
                        username in (select distinct grantee from dba_role_privs
                                     where granted_role='DBA')) loop
            dbms_output.put_line(r.username || ' ' || r.account_status);
        end loop;
    end if;


end;
/

prompt
prompt
prompt S2 roles:
select role from dba_roles where role like 'S2%';

prompt
prompt
prompt Operation DBAs:
select username,account_status,created,profile,decode(password,'EXTERNAL','EXTERNAL','PASSWORD') authent from dba_users
where username in (select grantee from dba_role_privs where granted_role='S2OPERATION')
and username not in ('SYS')
order by username;

prompt
prompt
prompt Engineering DBAs:
select username,account_status,created,profile,decode(password,'EXTERNAL','EXTERNAL','PASSWORD') authent from dba_users
where username in (select grantee from dba_role_privs where granted_role='S2ENGINEERING')
and username not in ('SYS')
order by username;

prompt
prompt
prompt L3 IDs:
select username,account_status,created,profile,decode(password,'EXTERNAL','EXTERNAL','PASSWORD') authent from dba_users
where username like 'S3ORA0%'
order by username;

spool off

!chmod 600 *.sql
!chmod 600 *.log

--!cat setup_l2_ids.log | mailx -s "PAT L2 account changes $ORACLE_SID@`hostname`" "CRISAC2@td.com,CUNLID2@td.com,DAIT2@td.com,LIH6@td.com,TANGY3@td.com,XUS4@td.com,XUY3@td.com,ZHUL2@td.com,SHAHA8@td.com, paulog2@td.com"
--!cat setup_l2_ids.log | mailx -s "PAT L2 account changes $ORACLE_SID@`hostname`" "RASHIM3@td.com,BACALS2@td.com,DOBREC2@td.com,KHANN6@td.com,PAULOG2@td.com,ZHENGS3@td.com"
