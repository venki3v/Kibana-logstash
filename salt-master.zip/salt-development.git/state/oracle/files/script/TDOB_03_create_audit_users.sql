spool create_audit_users.log
set echo on
set timing off
set serveroutput on

-- disable dropping user 
--drop user td_audit cascade;
--drop user td_audit_user cascade; 
 
--------------------------------------------------------
-- Create the Audit client user - this needs to run on 
-- the DB servers from which the data is gathered. This 
-- user can read the catalog, and makes views available
-- to the user that gagthers stats. Change this password
-- before installing in production - it can be anything. 
--------------------------------------------------------

DECLARE
user_already_exists EXCEPTION; 
PRAGMA EXCEPTION_INIT (user_already_exists, -1920); 
BEGIN
EXECUTE IMMEDIATE '
   create user td_audit
   identified by xla99r8zzy321
   temporary tablespace temp
   default tablespace USERS
   profile td_proxy_default_profile
   account lock
   ';

-- if user is created change password to random
EXECUTE IMMEDIATE 'alter user td_audit identified by ' ||
   dbms_random.string('A',2) || dbms_random.string('x',10) || '9r4';

EXCEPTION WHEN user_already_exists THEN
   EXECUTE IMMEDIATE 'alter user td_audit account lock';
END;
/

ALTER USER td_audit PROFILE TD_PROXY_DEFAULT_PROFILE;
grant connect,
      create view,
      create table,
      create procedure
 to td_audit;
                              
--------------------------------------------------------
-- Create the Audit client ID - this needs to run on 
-- the DB servers from which the data is gathered. All it 
-- can see is the views made available by Audit user. Do
-- not change this password without contacting owner of 
-- the Audit Gathering process. 
--------------------------------------------------------
 
DECLARE
user_already_exists EXCEPTION; 
PRAGMA EXCEPTION_INIT (user_already_exists, -1920); 
BEGIN
EXECUTE IMMEDIATE '
   create user td_audit_user
   identified by VALUES ''EA6E4E683D001E0C''
   temporary tablespace temp
   default tablespace USERS
   profile td_proxy_default_profile
   ';

EXCEPTION WHEN user_already_exists THEN
   NULL;
END;
/

grant connect,
      create synonym
 to td_audit_user;

ALTER USER td_audit_user PROFILE TD_PROXY_DEFAULT_PROFILE;
ALTER USER td_audit_user identified by VALUES 'EA6E4E683D001E0C';

grant select on dba_users to td_audit with grant option; 
grant select on dba_tab_privs to td_audit with grant option; 
grant select on dba_role_privs to td_audit with grant option; 
grant select on dba_stmt_audit_opts to td_audit with grant option; 
grant select on dba_priv_audit_opts to td_audit with grant option; 
grant select on dba_sys_privs to td_audit with grant option; 
grant select on dba_data_files to td_audit with grant option; 
grant select on dba_segments to td_audit with grant option;
grant select on GV_$parameter to td_audit with grant option;
grant select on dba_registry to td_audit with grant option;
grant select on dba_registry_history to td_audit with grant option;


-- added for DB monitoring
grant select on gv_$instance to td_audit with grant option;
grant select on v_$instance to td_audit with grant option;
grant select on dba_free_space to td_audit with grant option;
grant select on dba_temp_files to td_audit with grant option;
grant select on v_$parameter to td_audit with grant option;
grant select on gv_$sort_usage to td_audit with grant option;
grant select on v_$sort_usage to td_audit with grant option;
grant select on gv_$process to td_audit with grant option;
grant select on v_$process to td_audit with grant option;
grant select on gv_$session to td_audit with grant option;
grant select on v_$session to td_audit with grant option;
grant select on gv_$datafile to td_audit with grant option;
grant select on v_$datafile to td_audit with grant option;
grant select on gv_$tablespace to td_audit with grant option;
grant select on v_$tablespace to td_audit with grant option;
grant select on dba_tablespaces to td_audit with grant option;
grant select on v_$archived_log to td_audit with grant option;
grant select on gv_$managed_standby to td_audit with grant option;
grant select on v_$managed_standby to td_audit with grant option;



create or replace view  td_audit.user_view as
select 
 USERNAME,
 USER_ID,
 ACCOUNT_STATUS,
 LOCK_DATE,
 EXPIRY_DATE,
 DEFAULT_TABLESPACE,
 TEMPORARY_TABLESPACE,
 CREATED,
 PROFILE
from dba_users;

create or replace view td_audit.parm_view as 
select 
 INST_ID,
 NUM,
 NAME,
 TYPE,
 VALUE,
 ISDEFAULT,
 ISSES_MODIFIABLE,
 ISSYS_MODIFIABLE,
 ISMODIFIED,
 ISADJUSTED,
 DESCRIPTION,
 UPDATE_COMMENT
from sys.gv_$parameter;

create or replace view td_audit.aud_stmt_view as
select 
 USER_NAME,
 PROXY_NAME,
 AUDIT_OPTION,
 SUCCESS,
 FAILURE  
from dba_stmt_audit_opts;

create or replace view td_audit.aud_priv_view as
select 
 USER_NAME,
 PROXY_NAME,
 PRIVILEGE,
 SUCCESS,
 FAILURE  
from dba_priv_audit_opts;

create or replace view td_audit.datafile_view as
select 
 FILE_NAME,
 FILE_ID,
 TABLESPACE_NAME,
 BYTES,
 BLOCKS,
 STATUS,
 AUTOEXTENSIBLE,
 MAXBYTES,
 MAXBLOCKS,
 INCREMENT_BY
from dba_data_files;

create or replace view td_audit.segment_view as
select 
 OWNER,
 SEGMENT_NAME,
 PARTITION_NAME,
 SEGMENT_TYPE,
 TABLESPACE_NAME,
 HEADER_FILE,
 HEADER_BLOCK,
 BYTES,
 BLOCKS
from dba_segments;
 
create or replace view td_audit.role_priv_view as
 select
 GRANTEE,
 GRANTED_ROLE,
 ADMIN_OPTION,
 DEFAULT_ROLE
from dba_role_privs;

create or replace view td_audit.tab_priv_view as
select 
 GRANTEE,
 OWNER,
 TABLE_NAME,  
 GRANTOR,
 PRIVILEGE
from dba_tab_privs;

create or replace view td_audit.sys_priv_view as
select 
  GRANTEE,
  PRIVILEGE,
  ADMIN_OPTION
from dba_sys_privs;

create or replace view td_audit.registry_view as 
select
 COMP_ID,
 COMP_NAME,
 VERSION,
 STATUS,
 MODIFIED,
 CONTROL,
 SCHEMA,
 PROCEDURE,
 STARTUP,
 PARENT_ID
from dba_registry;
 
create or replace view td_audit.reghist_view as  
select
 ACTION_TIME,
 ACTION,
 NAMESPACE,
 VERSION,
 ID,
 COMMENTS
from dba_registry_history;

 


-- added for DB monitoring
create or replace view td_audit.gv_instance as
select * from sys.gv_$instance;

create or replace view td_audit.v_instance as
select * from sys.v_$instance;

create or replace view td_audit.v_dba_free_space as
select * from dba_free_space;

create or replace view td_audit.v_dba_temp_files as
select * from dba_temp_files;

create or replace view td_audit.v_parameter as
select * from sys.v_$parameter;

create or replace view td_audit.gv_sort_usage as
select * from sys.gv_$sort_usage;

create or replace view td_audit.v_sort_usage as
select * from sys.v_$sort_usage;

create or replace view td_audit.gv_process as
select * from sys.gv_$process;

create or replace view td_audit.v_process as
select * from sys.v_$process;

create or replace view td_audit.gv_session as
select * from sys.gv_$session;

create or replace view td_audit.v_session as
select * from sys.v_$session;

create or replace view td_audit.gv_datafile as
select * from sys.gv_$datafile;

create or replace view td_audit.v_datafile as
select * from sys.v_$datafile;

create or replace view td_audit.gv_tablespace as
select * from sys.gv_$tablespace;

create or replace view td_audit.v_tablespace as
select * from sys.v_$tablespace;

create or replace view td_audit.v_dba_tablespaces as
select * from dba_tablespaces;

create or replace view td_audit.v_archived_log as
select * from sys.v_$archived_log;

create or replace view td_audit.gv_managed_standby as
select * from sys.gv_$managed_standby;

create or replace view td_audit.v_managed_standby as
select * from sys.v_$managed_standby;



grant select on td_audit.sys_priv_view         to td_audit_user;
grant select on td_audit.tab_priv_view         to td_audit_user;
grant select on td_audit.role_priv_view        to td_audit_user;
grant select on td_audit.user_view             to td_audit_user;
grant select on td_audit.parm_view             to td_audit_user; 
grant select on td_audit.aud_priv_view         to td_audit_user;
grant select on td_audit.aud_stmt_view         to td_audit_user;
grant select on td_audit.datafile_view         to td_audit_user;
grant select on td_audit.segment_view          to td_audit_user;
grant select on td_audit.registry_view         to td_audit_user;
grant select on td_audit.reghist_view          to td_audit_user;

-- added for DB monitoring
grant select on td_audit.gv_instance           to td_audit_user;
grant select on td_audit.v_instance            to td_audit_user;
grant select on td_audit.v_dba_free_space      to td_audit_user;
grant select on td_audit.v_dba_temp_files      to td_audit_user;
grant select on td_audit.v_parameter           to td_audit_user;
grant select on td_audit.gv_sort_usage         to td_audit_user;
grant select on td_audit.v_sort_usage          to td_audit_user;
grant select on td_audit.gv_process            to td_audit_user;
grant select on td_audit.v_process             to td_audit_user;
grant select on td_audit.gv_session            to td_audit_user;
grant select on td_audit.v_session             to td_audit_user;
grant select on td_audit.gv_datafile           to td_audit_user;
grant select on td_audit.v_datafile            to td_audit_user;
grant select on td_audit.gv_tablespace         to td_audit_user;
grant select on td_audit.v_tablespace          to td_audit_user;
grant select on td_audit.v_dba_tablespaces     to td_audit_user;
grant select on td_audit.v_archived_log        to td_audit_user;
grant select on td_audit.gv_managed_standby    to td_audit_user;
grant select on td_audit.v_managed_standby     to td_audit_user;

create or replace synonym td_audit_user.sys_priv_view        for td_audit.sys_priv_view;
create or replace synonym td_audit_user.tab_priv_view        for td_audit.tab_priv_view;
create or replace synonym td_audit_user.role_priv_view       for td_audit.role_priv_view;
create or replace synonym td_audit_user.user_view            for td_audit.user_view;
create or replace synonym td_audit_user.parm_view            for td_audit.parm_view;
create or replace synonym td_audit_user.aud_priv_view        for td_audit.aud_priv_view;
create or replace synonym td_audit_user.aud_stmt_view        for td_audit.aud_stmt_view;
create or replace synonym td_audit_user.datafile_view        for td_audit.datafile_view;
create or replace synonym td_audit_user.segment_view         for td_audit.segment_view;
create or replace synonym td_audit_user.registry_view        for td_audit.registry_view;
create or replace synonym td_audit_user.reghist_view         for td_audit.reghist_view;


-- added for DB monitoring
create or replace synonym td_audit_user.gv_instance          for td_audit.gv_instance;
create or replace synonym td_audit_user.v_instance           for td_audit.v_instance;
create or replace synonym td_audit_user.v_dba_free_space     for td_audit.v_dba_free_space;
create or replace synonym td_audit_user.v_dba_temp_files     for td_audit.v_dba_temp_files;
create or replace synonym td_audit_user.v_dba_data_files     for td_audit.datafile_view;
create or replace synonym td_audit_user.gv_parameter         for td_audit.parm_view;
create or replace synonym td_audit_user.v_parameter          for td_audit.v_parameter;
create or replace synonym td_audit_user.gv_sort_usage        for td_audit.gv_sort_usage;
create or replace synonym td_audit_user.v_sort_usage         for td_audit.v_sort_usage;
create or replace synonym td_audit_user.gv_process           for td_audit.gv_process;
create or replace synonym td_audit_user.v_process            for td_audit.v_process;
create or replace synonym td_audit_user.gv_session           for td_audit.gv_session;
create or replace synonym td_audit_user.v_session            for td_audit.v_session;
create or replace synonym td_audit_user.gv_datafile          for td_audit.gv_datafile;
create or replace synonym td_audit_user.v_datafile           for td_audit.v_datafile;
create or replace synonym td_audit_user.gv_tablespace        for td_audit.gv_tablespace;
create or replace synonym td_audit_user.v_tablespace         for td_audit.v_tablespace;
create or replace synonym td_audit_user.v_dba_tablespaces    for td_audit.v_dba_tablespaces;
create or replace synonym td_audit_user.v_archived_log       for td_audit.v_archived_log;
create or replace synonym td_audit_user.gv_managed_standby   for td_audit.gv_managed_standby;
create or replace synonym td_audit_user.v_managed_standby    for td_audit.v_managed_standby;


--10g or higher

declare
l_version NUMBER(3);
l_errmsg VARCHAR2(100);
l_errnum NUMBER;
begin
select to_number(substr(version,0,instr(version,'.')-1))
into l_version
from product_component_version where product like 'Oracle%';
if l_version>=10 then
    dbms_output.put_line('10');
                                                                                              
EXECUTE IMMEDIATE('grant select on dba_feature_usage_statistics to td_audit with grant option');

EXECUTE IMMEDIATE('create or replace view td_audit.feature_view as  
select
 DBID,
 NAME,
 VERSION,
 DETECTED_USAGES,
 TOTAL_SAMPLES,  
 CURRENTLY_USED, 
 FIRST_USAGE_DATE,
 LAST_USAGE_DATE,
 AUX_COUNT,     
 substr(FEATURE_INFO,1,2048) FEATURE_INFO,
 LAST_SAMPLE_DATE,
 LAST_SAMPLE_PERIOD,
 SAMPLE_INTERVAL,
 DESCRIPTION
from dba_feature_usage_statistics');

EXECUTE IMMEDIATE('create or replace synonym td_audit_user.feature_view         for td_audit.feature_view');
EXECUTE IMMEDIATE('grant select on td_audit.feature_view          to td_audit_user');

end if;

--added for DB monitoring
FOR r IN
( 
select view_name, replace(view_name,'$','') new_name
from dba_views
where(view_name like 'V_$%' or view_name like 'GV_$%')
and
(
   view_name like '%$BACKUP%'
or view_name like '%$FLASH%'
or view_name like '%$%DEST%' 
or view_name like '%$RESTORE%'
or view_name like '%$DATABASE'
or view_name like '%$DATABASE_INCARNATION'
or view_name like '%$DATABASE_BLOCK_CORRUPTION'
or view_name like '%$ACTIVE%'
or view_name like '%$ASM%'
or view_name like '%$BLOCK_CHANGE%'
or view_name like '%$BUFFER_%'
or view_name like '%$%INTERCONNECTS%'
or view_name like '%$DATAGUARD%'
or view_name like '%$%ADVICE%'
or view_name like '%$%OPEN_CURSOR'
or view_name like '%$%PGASTAT'
or view_name like '%$%PWFILE_USERS'
or view_name like '%$%SGA%'
)
order by 1
)
LOOP
    BEGIN
        EXECUTE IMMEDIATE('grant select on ' || r.view_name || ' to td_audit with grant option');
        EXECUTE IMMEDIATE('create or replace view TD_AUDIT.' || r.new_name || ' as select * from SYS.' || r.view_name );
        EXECUTE IMMEDIATE('grant select on ' || 'TD_AUDIT.' || r.new_name || ' to td_audit_user');
        EXECUTE IMMEDIATE('create or replace synonym TD_AUDIT_USER.' || r.new_name || ' for TD_AUDIT.' || r.new_name);
    EXCEPTION WHEN OTHERS THEN
        l_errnum := SQLCODE;
        l_errmsg := SUBSTR(SQLERRM, 1, 100);
        dbms_output.put_line(to_char(l_errnum) || l_errmsg);
        dbms_output.put_line(r.view_name || ' ' || r.new_name);
    END;
END LOOP;


end;
/


spool off;

