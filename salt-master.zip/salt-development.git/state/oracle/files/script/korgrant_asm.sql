---------------------------------------------------------------------
-- $Header: /ctcvs/hclroot/src/kor/korgrant.sql,v 1.2 2003/11/10 16:19:42 mevan Exp $ monitor.sql
--
-- ***************************************************************
-- Licensed Materials - Property of IBM
-- 5724-B96
--
-- Copyright IBM Corp. 2005 All Rights Reserved
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp
-- ***************************************************************
--
-- Copyright (c) 1995 by Candle Corporation
-- NAME
--    korgrant.sql
-- FUNCTION
--   Grant access to all views used by Candle Command Center.
-- NOTES
--   This file must be run while logged-in as SYS.
--   Catalog.sql must have been run before this file is run.
--
--
-- MODIFIED
---------------------------------------------------------------------
--   Maintainence Log
--   @AL01 - 11/06/95 Date Created
--   @AL02 - 11/28/95 Removed the drop role candler because of serious bug
--                    with multiple oracle servers on same host, previous
--                    users losing the permissions due to drop role command
--   @TF01 - 03/26/07 Added setting temporary tablespace
--   @TF02 - 03/26/07 Added role-based privledges
--   @TF03 - 04/04/07 Removed unlimited tablespace and execute any
--                    procedure. These permissions are not needed.
--   @TF04 - 08/07/14 Tuning sql, add some privilege to agent user.
--------------------------------------------------------------------------
-- Usage Instructions
-- Change directory to where this file is
-- cd <directory path  name of this file>
-- Bringup  sqlplus
--    sqlplus
--    login : sys
--    password : <enter  password for user SYS>
-- Create the user ID using the following command
--    create user <user ID> identified by <password>
--    where <user ID> is the user ID that the Oracle Agent will use
--          <password> is the desired password for the user ID
--    For example: create user tivoli identified by secret;
-- Create the role using the following command
--    create role <role_name>
--    For example: create role tivoli_role;
-- Run this script
--    @korgrant.sql <user ID> <tivoli role> <temporary directory>
--
-- (1)         <user ID>         = ID of the Oracle user.  Must be created
--                                 prior to running this sql file.
--
--                                 Example value: tivoli
--
-- (2)         <user role>       = Name of the role for the required Oracle
--                                 Agent permisisons to be granted to. Must
--                                 be created prior to running this sql
--                                 file.
--
--                                 Example value: tivoli_role
--
-- (3)         <temporary dir>   = Name of the temporary directory where Oracle
--                                 Agent will write temporary files. Must
--                                 be created prior to running this sql
--                                 file.
--
--                                 Example value: /opt/IBM/ITM/tmp
--
-- Will output the log to the file korgrant.log in the current directory
--
--------------------------------------------------------------------------

set echo on;
-- spool ./korgrant.log

-- Create a directory called tivolior_temp and grant
-- read/write authority to it
create directory tivolior_temp as '&3';
GRANT read,WRITE ON directory tivolior_temp TO &2;

-- Create and associate a tablespace with the user.
-- Initial space is 250MB.

-- create tablespace tivoliorts datafile '&oradata_path/tivoliorts.dbf' size 250m autoextend on;

create tablespace tivoliorts datafile size 250m autoextend on next 50m maxsize unlimited;
alter user &1 default tablespace tivoliorts quota 250M on tivoliorts;
commit;

-- Create and associate a temporary tablespace with the user
-- Initial space is 100MB. 

-- create temporary tablespace tivoliortempts tempfile '&oradata_path/tivoliortempts.dbf' size 100M autoextend on;

create temporary tablespace tivoliortempts tempfile size 100M autoextend on next 50m maxsize unlimited;
alter user &1 temporary tablespace tivoliortempts;
COMMIT;

-- Create view on X$KCCFE

CREATE OR REPLACE VIEW TIVOLI_FSTATUS_VIEW AS
SELECT FENUM FILE#,
       DECODE(FE.FETSN,
              0,
              DECODE(BITAND(FE.FESTA, 2), 0, 'SYSOFF', 'SYSTEM'),
              DECODE(BITAND(FE.FESTA, 18),
                     0,
                     'OFFLINE',
                     2,
                     'ONLINE',
                     'RECOVER')) STATUS,
                     DECODE(HC.KTFBHCCVAL, 0, HC.KTFBHCSZ, NULL) BLOCKS
  FROM X$KCCFE FE, SYS.X$KTFBHC HC
 WHERE FE.INST_ID = USERENV('INSTANCE') AND FE.FENUM = HC.KTFBHCAFNO;


-- Create view for korfiles

CREATE OR REPLACE VIEW SYS.TIVOLI_KORFILES_VIEW AS
SELECT E.UTSNAME,
       E.UFILENAME,
       C.FILERID,
       E.FILESTAT,
       DECODE(D.STATUS, 'NOT ACTIVE', 'INACTIVE') BKUPSTAT,
       D.TIME BKUPSTATM,
       C.TSNFREEB,
       C.LFREEBLK * 1024 MAXBYTES,
       (C.SUMBYTES / E.RAWFILESIZE) * 10000 PFREESPC,
       C.LFREEBLK,
       (C.LFREEBLK * 1024 / E.RAWFILESIZE) * 10000 LPCTFREE,
       E.RAWFILESIZE / 1024 FILESIZE,
       E.RAWFILESIZE,
       A.FILEXTENTS,
       B.PHYRDS PHYREAD,
       B.PHYWRTS PHYWRITE
  FROM V$BACKUP D,
       (SELECT T1.FILE# FILE_ID,
               T1.NAME UFILENAME,
               T3.NAME UTSNAME,
               FE.STATUS FILESTAT,
               FE.BLOCKS * T3.BLOCKSIZE RAWFILESIZE
          FROM V$DBFILE                T1,
               SYS.FILE$               T2,
               SYS.TS$                 T3,
               SYS.TIVOLI_FSTATUS_VIEW FE
         WHERE T1.FILE# = T2.FILE#
           AND T2.TS# = T3.TS#
           AND T3.ONLINE$ <> 3
           AND T1.FILE# = FE.FILE#) E,
       (SELECT EXT.FILEID FILERID, COUNT(*) FILEXTENTS
          FROM SYS.DBA_LMT_USED_EXTENTS EXT
         GROUP BY FILEID
        UNION ALL
        SELECT FILEID FILERID, COUNT(*) FILEXTENTS
          FROM SYS.DBA_DMT_USED_EXTENTS EXT
         GROUP BY FILEID) A,
       V$FILESTAT B,
       (SELECT FILE_ID FILERID,
               SUM(BLOCKS) TSNFREEB,
               MAX(BYTES / 1024) LFREEBLK,
               SUM(BYTES) SUMBYTES
          FROM SYS.DBA_FREE_SPACE
         GROUP BY FILE_ID) C
 WHERE A.FILERID(+) = B.FILE#
   AND C.FILERID(+) = B.FILE#
   AND D.FILE# = B.FILE#
   AND E.FILE_ID = B.FILE#
 UNION ALL
SELECT T1.TABLESPACE_NAME UTSNAME,
       T1.FILE_NAME UFILENAME,
       T1.FILE_ID,
       T2.STATUS FILESTAT,
       'INACTIVE' BKUPSTAT,
       NULL BKUPSTATM,
       T1.BLOCKS - NVL(T3.USED_BLOCKS, 0) TSNFREEB,
       NULL MAXBYTES,
       (T1.BLOCKS - NVL(T3.USED_BLOCKS, 0)) / T1.BLOCKS *10000 PFREESPC,
       NULL LFREEBLK,
       NULL LPCTFREE,
       T1.BYTES / 1024 FILESIZE,
       T1.BYTES RAWFILESIZE,
       NVL(T3.TOTAL_EXTENTS, 0) FILEXTENTS,
       T5.PHYRDS PHYREAD,
       T5.PHYWRTS PHYWRITE
  FROM DBA_TEMP_FILES T1,
       V$TEMPFILE T2,
       (SELECT TABLESPACE_NAME,
               SEGMENT_FILE + 1 FILE_ID,
               EXTENT_SIZE,
               TOTAL_EXTENTS,
               TOTAL_BLOCKS,
               USED_EXTENTS,
               USED_BLOCKS
          FROM V$SORT_SEGMENT) T3,
       V$TEMPSTAT T5
 WHERE T1.FILE_ID = T2.FILE#
   AND T1.FILE_ID = T5.FILE#
   AND T3.TABLESPACE_NAME(+) = T1.TABLESPACE_NAME
   AND T3.FILE_ID(+) = T1.FILE_ID
 ORDER BY 3;

-- Serious bug @AL02 commented out
-- drop role candler;
-- create role &1;

------------------------------------------------
-- V$ grants first
------------------------------------------------
grant select on   V_$ACCESS         to &2;
grant select on   V_$ARCHIVE_DEST   to &2;
grant select on   V_$BACKUP         to &2;
grant select on   V_$BGPROCESS      to &2;
grant select on   V_$BUFFER_POOL_STATISTICS to &2;
grant select on   V_$DATABASE       to &2;
grant select on   V_$DATAFILE       to &2;
grant select on   V_$DBFILE         to &2;
grant select on   V_$DISPATCHER     to &2;
grant select on   V_$FILESTAT       to &2;
grant select on   V_$HS_AGENT       to &2;
grant select on   V_$HS_SESSION     to &2;
grant select on   V_$INSTANCE       to &2;
grant select on   V_$LATCH          to &2;
grant select on   V_$LIBRARYCACHE   to &2;
grant select on   V_$LICENSE        to &2;
grant select on   V_$LOCK           to &2;
grant select on   V_$LOCK_ACTIVITY  to &2;
grant select on   V_$LOCKED_OBJECT  to &2;
grant select on   V_$LOG            to &2;
grant select on   V_$MTS            to &2;
grant select on   V_$OPEN_CURSOR    to &2;
grant select on   V_$OPTION         to &2;
grant select on   V_$PARAMETER      to &2;
grant select on   V_$PGASTAT        to &2;
grant select on   V_$PROCESS        to &2;
grant select on   V_$PX_PROCESS_SYSSTAT to &2;
grant select on   V_$QUEUE          to &2;
grant select on   V_$ROLLNAME       to &2;
grant select on   V_$ROLLSTAT       to &2;
grant select on   V_$ROWCACHE       to &2;
grant select on   V_$SESSION        to &2;
grant select on   V_$SESSION_WAIT   to &2;
grant select on   V_$SESS_IO        to &2;
grant select on   V_$SGA            to &2;
grant select on   V_$SGA_DYNAMIC_COMPONENTS to &2;
grant select on   V_$SGASTAT        to &2;
grant select on   V_$SHARED_SERVER  to &2;
grant select on   V_$SHARED_SERVER_MONITOR  to &2;
grant select on   V_$SORT_USAGE     to &2;
grant select on   V_$SQLTEXT        to &2;
grant select on   V_$SQLTEXT_WITH_NEWLINES  to &2;
grant select on   V_$SYSSTAT        to &2;
grant select on   V_$SYSTEM_EVENT   to &2;
grant select on   V_$TABLESPACE     to &2;
grant select on   V_$TEMPFILE       to &2;
grant select on   V_$TEMP_EXTENT_MAP to &2;
grant select on   V_$THREAD         to &2;
grant select on   V_$TRANSACTION    to &2;
grant select on   V_$UNDOSTAT       to &2;
grant select on   V_$VERSION        to &2;
grant select on   V_$WAITSTAT       to &2;
grant select on   v_$datafile_header   to &2;
grant select on   v_$enqueue_lock      to &2;

------------------------------------------------
-- DBA_ required tables
------------------------------------------------
grant select on   SYS.DBA_CLUSTERS     to &2;
grant select on   SYS.DBA_DATA_FILES   to &2;
grant select on   SYS.DBA_DIRECTORIES  to &2;
grant select on   SYS.DBA_EXTENTS      to &2;
grant select on   SYS.DBA_FREE_SPACE   to &2;
grant select on   SYS.DBA_INDEXES      to &2;
grant select on   SYS.DBA_JOBS         to &2;
grant select on   SYS.DBA_LMT_USED_EXTENTS to &2;
grant select on   SYS.DBA_DMT_USED_EXTENTS to &2;
grant select on   SYS.DBA_QUEUES       to &2;
grant select on   SYS.DBA_QUEUE_SCHEDULES  to &2;
grant select on   SYS.DBA_SEGMENTS     to &2;
grant select on   SYS.DBA_TABLES       to &2;
grant select on   SYS.DBA_TABLESPACES  to &2;
grant select on   SYS.DBA_TEMP_FILES   to &2;
grant select on   SYS.DBA_VIEWS        to &2;
grant select on   SYS.DBA_SYNONYMS     to &2;
grant select on   SYS.fet$             to &2;
grant select on   SYS.file$            to &2;
grant select on   SYS.OBJ$             to &2;
grant select on   SYS.sys_dba_segs     to &2;
grant select on   SYS.SEG$             to &2;
grant select on   SYS.ts$              to &2;
grant select on   SYS.TIVOLI_FSTATUS_VIEW  to &2;
grant select on   SYS.TIVOLI_KORFILES_VIEW  to &2;
grant select on   SYS.UNDO$            to &2;
grant select on   SYS.uet$             to &2;
grant select on   SYS.GV_$AQ           to &2;

------------------------------------------------
-- Grant create session to the user
------------------------------------------------
grant connect               to &2;
grant create session        to &2;
grant restricted session    to &2;

------------------------------------------------
-- Grants needed to collect attributes that
-- use PL/SQL:
--   - Free Space Deficit   (Tablespace Segments)
--   - Table Chained Rows   (Table Summary)
--   - Cluster Chained Rows (Cluster Summary)
--   - Index Percent Used   (Index Summary)
------------------------------------------------
-- grant create PROCEDURE           to &2;
grant create TABLE               to &2;
-- @TF03 - removed unneeded permissions
-- grant execute any PROCEDURE      to &2;
-- grant unlimited tablespace       to &2;

------------------------------------------------
-- Grants needed to collect attributes that
-- use analyze cluster|table or
--     validate index:
--   - Table Chained Rows    (Table Summary)
--   - Cluster Chained Rows  (Cluster Summary)
--   - Index Percent Deleted (Index Summary)
------------------------------------------------
-- GRANT analyze ANY                TO &2;


------------------------------------------------
-- Grant role candler to the user
------------------------------------------------
-- @AL02 grant candler              to &1;

GRANT &2 TO &1;

-- spool off
set echo off;
------------------------------------------------

