---------------------------------------------------------------------
-- ***************************************************************
-- Licensed Materials - Property of IBM
-- 5724-V09
--   
-- Copyright IBM Corp. 2009 All Rights Reserved
-- US Government Users Restricted Rights - Use, duplication or
-- disclosure restricted by GSA ADP Schedule Contract with
-- IBM Corp
-- ***************************************************************
-- NAME
--    krzgrant.sql
-- FUNCTION
--    Grant access to all views used by Tivoli Monitoring Agent.
-- NOTES
--    This file must be run while logged-in as SYSDBA.
--    Catalog.sql must have been run before this file is run.
--
--------------------------------------------------------------------------
-- Usage Instructions
-- Change directory to where this file is
--    cd <directory path name of this file>
-- Bringup sqlplus 
--    sqlplus
--    login : sys
--    password : <enter  password for user SYS>
-- Create the user ID using the following command
--    create user <user ID> identified by <password>
--    where <user ID> is the user ID that the Oracle Monitoring Agent will use
--          <password> is the desired password for the user ID
--    For example: create user tivoli identified by password;
-- Run this script
--    @krzgrant.sql <user ID> <temporary directory>
--
-- (1)         <user ID>         = ID of the Oracle user.  Must be created 
--                                 prior to running this sql file.
--
--                                 Example value: tivoli
--
-- (2)         <temporary dir>   = Name of the temporary directory where sql
--                                 will output the log to the file krzagent.log.
--                                 Must be created prior to running this sql
--                                 file.
--
--                                 Example value: /opt/IBM/ITM/tmp
--
--------------------------------------------------------------------------

set echo on;
-- spool ./krzgrant.log

------------------------------------------------
-- V$ grants first
------------------------------------------------
grant select on   V_$PARAMETER         to &1;
grant select on   V_$SPPARAMETER       to &1;
grant select on   V_$VERSION           to &1;
grant select on   V_$ACTIVE_INSTANCES  to &1;
grant select on   V_$ASM_DISK          to &1;
grant select on   V_$ASM_DISK_STAT          to &1;
grant select on   V_$ASM_DISKGROUP          to &1;
grant select on   V_$ASM_DISKGROUP_STAT        to &1;
grant select on   V_$DATABASE                 to &1;
grant select on   V_$ASM_FILE                 to &1;
grant select on   V_$ASM_ALIAS                to &1;
grant select on   V_$TABLESPACE               to &1;
grant select on   V_$FILEMETRIC               to &1;
grant select on   V_$DATAFILE_HEADER        to &1;
grant select on   V_$FILESTAT               to &1;
grant select on   V_$LOCK_TYPE              to &1;
grant select on   V_$INSTANCE               to &1;
grant select on   V_$ASM_CLIENT                to &1;
------------------------------------------------
-- GV$ grants
------------------------------------------------
grant select on   GV_$SGA            to &1;
grant select on   GV_$SGASTAT     to &1;
grant select on   GV_$SGAINFO        to &1;
grant select on   GV_$ROWCACHE        to &1;
grant select on   GV_$LIBRARYCACHE   to &1;
grant select on   GV_$SYSSTAT        to &1;
grant select on   GV_$RESOURCE_LIMIT to &1;
grant select on   GV_$INSTANCE       to &1;
grant select on   GV_$SESSION        to &1;
grant select on   GV_$PROCESS        to &1;
grant select on   GV_$DLM_MISC       to &1;
grant select on   GV_$BUFFER_POOL_STATISTICS  to &1;
grant select on   GV_$SEGMENT_STATISTICS      to &1;
grant select on   GV_$CLUSTER_INTERCONNECTS   to &1;
grant select on   GV_$ENQUEUE_STAT            to &1;
grant select on   GV_$GES_BLOCKING_ENQUEUE    to &1;
grant select on   GV_$ASM_ALIAS             to &1;
grant select on   GV_$ASM_CLIENT         to &1;
grant select on   GV_$ASM_DISK              to &1;
grant select on   GV_$ASM_DISK_STAT         to &1;
grant select on   GV_$ASM_DISKGROUP         to &1;
grant select on   GV_$ASM_DISKGROUP_STAT    to &1;
grant select on   GV_$ASM_FILE              to &1;
grant select on   GV_$ASM_TEMPLATE          to &1;
grant select on   GV_$ASM_OPERATION         to &1;
grant select on   GV_$PARAMETER          to &1;
grant select on   GV_$SYSTEM_PARAMETER   to &1;
grant select on   GV_$SERVICES           to &1;
grant select on   GV_$SYSMETRIC_HISTORY   to &1;
grant select on   GV_$SYSMETRIC_SUMMARY   to &1;
grant select on   GV_$SYSMETRIC           to &1;
grant select on   GV_$LOCK                to &1;
grant select on   GV_$LOCKED_OBJECT       to &1;
grant select on   GV_$LOG                 to &1;
grant select on   GV_$ARCHIVE_DEST        to &1;
grant select on   GV_$SORT_SEGMENT        to &1;
grant select on   GV_$SESS_IO        to &1;
grant select on   GV_$LATCH               to &1;
grant select on   GV_$LATCH_CHILDREN      to &1;
grant select on   GV_$ROLLSTAT      to &1;
grant select on   GV_$UNDOSTAT      to &1;
grant select on   GV_$OSSTAT              to &1;
grant select on   GV_$DATAFILE_HEADER     to &1;
grant select on   GV_$FILESTAT            to &1;
grant select on   GV_$FILEMETRIC          to &1;
grant select on   GV_$SESSION_WAIT          to &1;

-- prompt If Oracle Database 10g or above 10g is being used, 
-- prompt please ignore the error on granting V_$MTS of following.
-- grant select on   V_$MTS         to &1;

------------------------------------------------
-- DBA_ required tables
------------------------------------------------
grant select on   SYS.DBA_CLUSTERS     to &1;
grant select on   SYS.DBA_DATA_FILES   to &1;
grant select on   SYS.DBA_DIRECTORIES  to &1;
grant select on   SYS.DBA_EXTENTS      to &1;
grant select on   SYS.DBA_FREE_SPACE   to &1;
grant select on   SYS.DBA_INDEXES      to &1;
grant select on   SYS.DBA_JOBS         to &1;
grant select on   SYS.DBA_LMT_USED_EXTENTS to &1;
grant select on   SYS.DBA_DMT_USED_EXTENTS to &1;
grant select on   SYS.DBA_QUEUES           to &1;
grant select on   SYS.DBA_QUEUE_SCHEDULES  to &1;
grant select on   SYS.DBA_SEGMENTS     to &1;
grant select on   SYS.DBA_TABLES       to &1;
grant select on   SYS.DBA_TABLESPACES  to &1;
grant select on   SYS.DBA_TEMP_FILES   to &1;
grant select on   SYS.DBA_VIEWS        to &1;
grant select on   SYS.DBA_SYNONYMS     to &1;
grant select on   SYS.DBA_HIST_SYSMETRIC_SUMMARY     to &1;
grant select on   SYS.fet$             to &1;
grant select on   SYS.file$            to &1;
grant select on   SYS.OBJ$             to &1;
grant select on   SYS.sys_dba_segs     to &1;
grant select on   SYS.SEG$             to &1;
grant select on   SYS.ts$              to &1;
grant select on   SYS.UNDO$            to &1;
grant select on   SYS.uet$             to &1;
grant select on   SYS.GV_$AQ           to &1;

------------------------------------------------
-- Grant create session to the user
------------------------------------------------
grant connect               to &1;
grant create session        to &1;

-- spool off
set echo off;
------------------------------------------------

