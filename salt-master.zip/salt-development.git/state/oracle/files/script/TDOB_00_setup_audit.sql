spool setup_audit.log
set echo on

select name,to_char(sysdate,'yyyy-mm-dd hh24:mi:ss') from v$database; 

alter system set audit_sys_operations=true scope=spfile;
alter system set audit_trail=OS scope=spfile;
alter system set audit_syslog_level='local1.info' scope=spfile;

@@TDOB_01_enable_audit.sql
--@@TDOB_02_create_appdetective_user.sql  
@@TDOB_03_create_audit_users.sql        
@@TDOB_04_change_default_passwords.sql  
@@TDOB_05_create_s3.sql
@@TDOB_06_setup_l2_ids_pat.sql
@@TDOB_07_setup_cmdb_user.sql
@@TDOB_08_create_guardium_user.sql

spool off;

