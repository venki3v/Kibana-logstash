--
-- Script Name: TDOB_config_script_DB_Standalone_12.1.0.2.sql
--
-- Author : Ling Zhu
-- History: 2015.03.01
--
--

alter system set aq_tm_processes=1                    scope=both    sid='*';
alter system set control_file_record_keep_time = 35   scope=both    sid='*';
alter system set db_domain='TDBANK.CA'                scope=spfile  sid='*';
alter system set standby_file_management = auto       scope=both    sid='*';
alter system set open_cursors =1000                   scope=both    sid='*';

-- setup audit
alter system set global_names = true                  scope=spfile  sid='*';
alter system set OS_ROLES = false                     scope=spfile  sid='*';
alter system set os_authent_prefix =''                scope=spfile  sid='*';
alter system set remote_login_passwordfile=exclusive  scope=spfile  sid='*';
alter system set remote_os_roles = false              scope=spfile  sid='*';
alter system set O7_DICTIONARY_ACCESSIBILITY = false  scope=spfile  sid='*';
alter system set audit_sys_operations = true          scope=spfile  sid='*';
alter system set audit_trail = OS                     scope=spfile  sid='*';
alter system set "_TRACE_FILES_PUBLIC" =FALSE         scope=spfile  sid='*';
alter system set audit_syslog_level='LOCAL1.INFO'     scope=spfile  sid='*';
alter system set audit_file_dest='/oracle_audit'      scope=spfile  sid='*';

-- setup memory 
-- alter system set SGA_MAX_SIZE = 2G                    scope=spfile  sid='*';
-- alter system set SGA_TARGET   = 2G                    scope=spfile  sid='*';
-- alter system set PGA_AGGREGATE_TARGET=2G              scope=spfile  sid='*';
-- alter system set db_recovery_file_dest_size=5G        scope=spfile  sid='*';

