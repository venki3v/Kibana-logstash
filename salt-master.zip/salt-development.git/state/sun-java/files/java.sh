export JAVA_HOME={{ java_home }}
export PATH=$JAVA_HOME/bin:$PATH
