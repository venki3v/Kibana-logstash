import logging
import re
import salt.exceptions

log = logging.getLogger(__name__)

def __virtual__():
    return 'qip'


def record(name, hostname, domain_name, subnet, organization,
           qip_api, qip_username, qip_password, description='',
           cname=''):
    """
    Maintain a DNS record in QIP
    """
    ret = {'name': name,
           'changes': {},
           'result': None,
           'comment': ''}

    ip_address = name
    fqdn = "{0}.{1}".format(hostname, domain_name)

    # Validate IP Address is valid
    pattern = re.compile("^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")
    valid_ip = re.search(pattern, ip_address)
    if not valid_ip:
        raise salt.exceptions.SaltInvocationError(
            'Argument "name" is not a valid IP Address.')    

    # Find DNS record
    result, record = __salt__['qip.lookup'](organization, qip_api,
                                            qip_username, qip_password,
                                            ip_address, fqdn)

    log.debug('FIND DNS RECORD- RESULT: {0}'.format(result))
    log.debug('FIND DNS RECORD- RECORD: {0}'.format(record))

#
#    # Check if domain not found error
#    if result['errorKey'] == 'RULE_DOMAIN_NOT_FOUND':
#       # Create domain??
#       # NOTE: domains only get pushed to the DNS server for host
#       #       resolution every 2 hours on the hour mark or if
#       #       someone logs inot the QIP console and pushes the zone
#       # Did domain create succesfully?
#        if not result['successMsg']:
#           ret['result'] = False
#           ret['comment'] = result.__str__()
#           return ret
#

    # Check if EXACT record exists already
    if record.get('ip_address') == name and record.get('fqdn') == fqdn:
        ret['result'] = True
        ret['comment'] = "QIP record is in the correct state."
        return ret

    elif record.get('ip_address') == name and record.get('fqdn') != fqdn:
        result = __salt__['qip.delete'](ip_address, organization, qip_api,
                                        qip_username, qip_password)

        log.debug('DELETE DNS RECORD- RESULT: {0}'.format(result))

        # Was deleting stale record successful?
        if not result['successMsg']:
           ret['result'] = False
           ret['comment'] = result.__str__()
           return ret

    # Update or create DNS record
    result = __salt__['qip.update'](ip_address, hostname, subnet,  
                                    domain_name, organization, qip_api,         
                                    qip_username, qip_password, description,
                                    cname)

    log.debug('UPDATE OR CREATE DNS RECORD- RESULT: {0}'.format(result))

    # Adding or updating record failed
    if not result['successMsg']:
        ret['result'] = False
        ret['comment'] = result.__str__()
        return ret

    ret['result'] = True
    ret['comment'] = result.__str__()
    ret['changes'] = {'old': 'QIP record did not exist.',
                      'new': 'QIP record created.'}
    return ret
