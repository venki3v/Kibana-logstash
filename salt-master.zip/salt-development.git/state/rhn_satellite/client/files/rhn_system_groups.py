#!/usr/bin/python

import xmlrpclib
import socket

client = xmlrpclib.Server('{{ satellite_url }}', verbose=0)
key = client.auth.login('{{satellite_user}}', '{{satellite_pw}}')

env = '{{ grains.get('environment')|upper }}'
lob = '{{ grains.get('lob')|upper }}'
hn = socket.gethostname()
fqdn = socket.getfqdn()

if lob in ['PLATFORM', 'COREDEV' ]:
	systemgroup = 'ENG'
else:
	systemgroup = env

list = client.system.getId(key, hn )

if not list:
	list = client.system.getId(key, fqdn )

groupid = client.systemgroup.getDetails(key, systemgroup).get('id')

for system in list:
	if hn in system.get('name'):
		systemid = system.get('id')

client.system.setGroupMembership(key, systemid, groupid, 1)
