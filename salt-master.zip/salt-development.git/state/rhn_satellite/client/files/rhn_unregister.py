#!/usr/bin/python

import xmlrpclib

systemid = file('{{ systemid_file }}').read()
client = xmlrpclib.Server('{{ satellite_url }}', verbose=0)
client.system.deleteSystem(systemid)
