Alcatel-Lucent VitalQIP "Dynamic" DNS
=====================================

Description:
~~~~~~~~~~~~
VitalQIP (QIP) Domain Name System (DNS) provides IP Address Management.
With the introduction of version 8.0, VitalQIP provides a RESTful SOAP 
interface for managing objects protected by WSS Security.

This formula manages QIP records through the SOAP interface by 
creating, updating or deleting records with the Salt state qip.record

Notes:
~~~~~~
1. This script assumes that the requested domain has previously been
   created and had the subnet requested associated to the domain.
   Module functionality to create the zone and/or the subnet plus
   link the subnet to the zone are provided through SaltStack 
   module as part of this formula.

QIP Module functionality:
~~~~~~~~~~~~~~~~~~~~~~~~

add_zone
--------
Creates a new zone record within QIP (e.g, ian.test.zone1.cloud-pilot.td.com)
Any level of nesting or subdomains may be defined at any time.

Example: salt-call qip.add_zone \ 
                        <Zone Name> \
                        <primary_dns_server1 P 0;[[secondary_dns_server1 S 0;[secondary_dns_server2 S 0;[...]];][primary_dns_server2 P 0;[secondary_dns_server3 S 0;[...]];]...] \
                        <Organization> \
                        <SOAP Endpoint URL> \
                        <Username> \
                        <Password>A

e.g., sudo salt-call qip.add_zone zone_add_test2.cloud-pilot.td.com 'csvqp02.tdbank.ca' 'TD Bank Organization' 'http://49.27.102.65:8080/ws/services/VQIPWebService' 'admin_user' 'th3passw0rd'

add_subnet
----------
Creates a new subnet within QIP.  A subnet within QIP can have any subnet mask
(aka, be of any size) but it has to be a subset of whatever objects you are
trying to place within that subnet.

Note: All Subnets within QIP should already be defined!  I do not condone
      the running of this state (nor do I even know if it works...)

Example: salt-call qip.add_subnet \
                        <Subnet Address> \
                        <Subnet Mask> \
                        <Network Address> \
                        <Organization> \
                        <SOAP endpoint URL> \
                        <Username> \
                        <Password>

add_zone_to_subnet
------------------
Adds an existing, defined IP subnet to a defined Zone.
Note: QIP requires that a zone be associated with a subnet to allow
      any records within that subnet to be specified under the zone.
      for instance, QIP would reject addition of an object having
      address 10.157.8.11 if the subnet 10.157.0.0/16 is not associated
      to the zone requested (e.g, cloud-lb1.cloud.td.com)

Example: salt-call qip.add_zone_to_subnet \
                        <IP Subnet> \
                        <Zone Name> \
                        <Organization> \
                        <SOAP endpoint URL> \
                        <Username> \
                        <Password>

e.g., sudo salt-call qip.add_zone_to_subnet 10.157.0.0 pat.rc.cloud-pilot.td.com 'TD Bank Organization' 'http://49.27.102.65:8080/ws/services/VQIPWebService' 'admin_user' 'th3passw0rd'

get_zone
--------
Retrieves information pertaining to an existing QIP zone.  
(Note: no parsing attempts made.  Output is not human friendly.)

Example: salt-call qip.get_zone \
                        <Zone Name> \
                        <Organization> \
                        <SOAP API URL> \
                        <Username> \
                        <Password>

get_subnet
----------
Retrieves information pertaining to an existing QIP subnet.
(Note: no parsing attempts made.  Output is not human friendly.)

Example: salt-call qip.get_zone \
                        <IP Subnet> \
                        <Organization> \
                        <SOAP API URL> \
                        <Username> \

Dependencies:
~~~~~~~~~~~~~
Python 2.6+ Libraries

Supported Operating Systems:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- RedHat
- Windows

Key contacts:
~~~~~~~~~~~~~
- Salt Formula:  Sinclair, Ian J <ian.j.sinclair@td.com>
                 Currah, Ryan <ryan.currah@td.com>
- Operational:   Pecora, Stefano <stefano.pecora@td.com>
- QIP Technical: Carcoana, Stefan <stefan.carcoana@td.com>
