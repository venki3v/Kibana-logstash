#!/bin/sh
#set -x


#----------------------------------------------------------------------------------------------------------------
# Globals
#
DISPLAY_MESSAGES=${DISPLAY_MESSAGES:-shell}
TD_ENVIRONMENT=${TD_ENVIRONMENT:-AD_DEV}
TD_REPOSITORY_HOME=${TD_REPOSITORY_HOME:-http://10.111.161.93}
WAS_UPDATES_HOME=${WAS_UPDATES_HOME:-/WASupdates}
OS=$(uname)
WHOAMI=$(whoami)
 
IM_VERSION=${IM_VERSION:-1.8.0}
IM_PACKAGE_PATTERN=com.ibm.cic.agent
IM_MEDIA_BASE=${IM_MEDIA_BASE:-media_ibmim}
if [[ ${OS} == "AIX" ]]
then
        IM_MEDIA_BASE=${IM_MEDIA_BASE}_aix
fi
if [[ ${IM_VERSION} == "1.8.0" ]]
then
        IM_MEDIA=${IM_MEDIA:-${IM_MEDIA_BASE}_180}
fi
IM_HOME=${IM_HOME:-/usr/opt/InstallationManager}
IM_DATA_HOME=${IM_DATA_HOME:-/usr/opt/InstallationManagerData}
IMCL=${IM_HOME}/eclipse/tools/imcl
IM_SHARED_HOME=${IM_SHARED_HOME:-/usr/opt/IMShared}
 
WEBAS_HOME=${WEBAS_HOME:-/webAS}
TD_LIB_HOME=${TD_LIB_HOME:-/usr/opt/tdlib}
 
IHS_VERSION=${IHS_VERSION:-8.5.5}
if [[ ${IHS_VERSION} == "8.0" ]]
then
        IHS_FIXPACK=${IHS_FIXPACK:-9}
        IHS_PACKAGE_PATTERN=com.ibm.websphere.IHS.v80
        IHS_HOME=${IHS_HOME:-/usr/opt/HTTPServer8}
        IHS_INSTALL_RESPONSE_FILE=${IHS_INSTALL_RESPONSE_FILE:-install_ihs_800${IHS_FIXPACK}.xml}
elif [[ ${IHS_VERSION} == "8.5.5" ]]
then
        IHS_FIXPACK=${IHS_FIXPACK:-4}
        IHS_PACKAGE_PATTERN=com.ibm.websphere.IHS.v85
        IHS_HOME=${IHS_HOME:-/usr/opt/HTTPServer855}
        IHS_INSTALL_RESPONSE_FILE=${IHS_INSTALL_RESPONSE_FILE:-install_ihs_855${IHS_FIXPACK}.xml}
fi
IHS_LOG_HOME=${IHS_LOG_HOME:-/td/logs/httpd}

PLG_VERSION=${PLG_VERSION:-8.5.5}
if [[ ${PLG_VERSION} == "8.0" ]]
then
        PLG_FIXPACK=${PLG_FIXPACK:-9}
        PLG_PACKAGE_PATTERN=com.ibm.websphere.PLG.v80
        PLG_HOME=${PLG_HOME:-/usr/opt/WebSphere8/Plugins}
        PLG_INSTALL_RESPONSE_FILE=${PLG_INSTALL_RESPONSE_FILE:-install_plg_800${PLG_FIXPACK}.xml}
elif [[ ${PLG_VERSION} == "8.5.5" ]]
then
        PLG_FIXPACK=${PLG_FIXPACK:-4}
        PLG_PACKAGE_PATTERN=com.ibm.websphere.PLG.v85
        PLG_HOME=${PLG_HOME:-/usr/opt/WebSphere855/Plugins}
        PLG_INSTALL_RESPONSE_FILE=${PLG_INSTALL_RESPONSE_FILE:-install_plg_855${PLG_FIXPACK}.xml}
fi
 
WAS_VERSION=${WAS_VERSION:-8.5.5}
if [[ ${WAS_VERSION} == "7.0" ]]
then
        WAS_HOME=${WAS_HOME:-/usr/opt/WebSphere7/AppServer}
        WAS_LOG_HOME=${WAS_LOG_HOME:-/td/logs/WebSphere/v7}
        WAS_STARTING_PORT=${WAS_STARTING_PORT:-17000}
elif [[ ${WAS_VERSION} == "8.0" ]]
then
        WAS_FIXPACK=${WAS_FIXPACK:-9}
        WAS_PACKAGE_PATTERN=com.ibm.websphere.ND.v80
        WEB2MOBILE_PACKAGE_PATTERN=com.ibm.websphere.WEB2MOBILE.v11
        WXSCLIENT_PACKAGE_PATTERN=com.ibm.websphere.WXSCLIENT.was8.v85
        WAS_HOME=${WAS_HOME:-/usr/opt/WebSphere8/AppServer}
        WAS_LOG_HOME=${WAS_LOG_HOME:-/td/logs/WebSphere/v8}
        WAS_STARTING_PORT=${WAS_STARTING_PORT:-18000}
        WAS_INSTALL_RESPONSE_FILE=${WAS_INSTALL_RESPONSE_FILE:-install_was_800${WAS_FIXPACK}.xml}
elif [[ ${WAS_VERSION} == "8.5.5" ]]
then
        WAS_FIXPACK=${WAS_FIXPACK:-4}
        WAS_PACKAGE_PATTERN=com.ibm.websphere.ND.v85
        IBMJAVA70_PACKAGE_PATTERN=com.ibm.websphere.IBMJAVA.v70
        IBMJAVA71_PACKAGE_PATTERN=com.ibm.websphere.IBMJAVA.v71
        WAS_HOME=${WAS_HOME:-/usr/opt/WebSphere855/AppServer}
        WAS_LOG_HOME=${WAS_LOG_HOME:-/td/logs/WebSphere/v855}
        WAS_STARTING_PORT=${WAS_STARTING_PORT:-19000}
        WAS_INSTALL_RESPONSE_FILE=${WAS_INSTALL_RESPONSE_FILE:-install_was_855${WAS_FIXPACK}.xml}
fi
DUMP_HOME=${DUMP_HOME:-/td/logs/dump}
WAS_BIN_HOME=${WAS_BIN_HOME:-${WAS_HOME}/bin}
WAS_PROFILE_HOME=${WAS_PROFILE_HOME:-${WAS_HOME}/profiles}
WAS_PROFILE_TEMPLATES_HOME=${WAS_PROFILE_TEMPLATES_HOME:-${WAS_HOME}/profileTemplates}
TD_MGMT_MW_HOME=${TD_MGMT_HOME:-/td/mgmt/middleware}
MW_TOOLBOX_HOME=${MW_TOOLBOX_HOME:-${TD_MGMT_MW_HOME}/bin}
WAS_CONTROL_WRAPPER=${WAS_CONTROL_WRAPPER:-${MW_TOOLBOX_HOME}/was_control.sh}
WAS_CONTROL_HOME=${WAS_CONTROL_HOME:-${TD_MGMT_MW_HOME}/wascontrol}
DMGR_HTTPS_PORT=${DMGR_HTTPS_PORT:-$((${WAS_STARTING_PORT}+1))}
DMGR_SOAP_PORT=${DMGR_SOAP_PORT:-$((${WAS_STARTING_PORT}+3))}
LOCALHOST_LONG_NAME=${LOCALHOST_LONG_NAME:-$(hostname)}
LOCALHOST_SHORT_NAME=${LOCALHOST_SHORT_NAME:-$(hostname -s)}
WAS_CELL_NAME=${WAS_CELL_NAME:-${LOCALHOST_SHORT_NAME}_Cell}
DMGR_NODE_NAME=${DMGR_NODE_NAME:-${LOCALHOST_SHORT_NAME}_CellManager}
DMGR_HOST_NAME=${DMGR_HOST_NAME:-${LOCALHOST_LONG_NAME}}
DMGR_PROFILE_NAME=${DMGR_PROFILE_NAME:-${DMGR_NODE_NAME}}
MANAGED_NODE_NAME=${MANAGED_NODE_NAME:-${LOCALHOST_SHORT_NAME}_node}
MANAGED_HOST_NAME=${MANAGED_HOST_NAME:-${LOCALHOST_LONG_NAME}}
MANAGED_PROFILE_NAME=${MANAGED_PROFILE_NAME:-${MANAGED_NODE_NAME}}
NODE_STARTING_PORT=${NODE_STARTING_PORT:-$((${WAS_STARTING_PORT}+25))}
UNMANAGED_NODE_NAME=${UNMANAGED_NODE_NAME:-${LOCALHOST_SHORT_NAME}_web}
UNMANAGED_HOST_NAME=${UNMANAGED_HOST_NAME:-${LOCALHOST_LONG_NAME}}
UNMANAGED_OS_TYPE=$(echo ${UNMANAGED_OS_TYPE:-${OS}} | tr '[:upper:]' '[:lower:]')
BASIC_IHS_INSTANCE_NAME=ihs_${LOCALHOST_SHORT_NAME}
 
 
#---------------------------------------------------
# prepare string with slashes to be used in sed
#
function escape_slashes {
	RETURN=$(echo "$1" | sed 's/\//\\\//g')
	echo ${RETURN}
	}
 
 
#---------------------------------------------------
# stop websphere
#
function stop_websphere {
	for WAS_PID in $(ps -ef | grep WebSphere | grep java | awk '{print $2}')
	do
		echo "Killing ${WAS_PID}"
		kill -9 ${WAS_PID}
	done
	}
 
 
#---------------------------------------------------
# disable/enable security
#
function websphere_security {
	if [[ $1 == "disable" ]]
	then
		${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME}/bin/wsadmin.sh -conntype NONE -c 'securityoff'
	elif [[ $1 == "enable" ]]
	then
		${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME}/bin/wsadmin.sh -c 'set s [$AdminConfig getid /Cell:/Security:/];set attrib [list [list enabled true]];$AdminConfig modify $s $attrib;$AdminConfig save'
	fi
	}


#----------------------------------------------------------------------------------------------------------------
# update IHS binaries
# verified = YES
#
if [[ -n ${APPLY_IHS_8554_MAINTENANCE} ]]
then
	set -x
	IHS_INSTALL_RESPONSE_FILE=install_ihs_8554.xml
	IHS_IMCL_VARIABLES="im_shared_home=${IM_SHARED_HOME},td_repository_home=${TD_REPOSITORY_HOME},ihs_home=${IHS_HOME}"
	echo APPLY_IHS_8554_MAINTENANCE=${APPLY_IHS_8554_MAINTENANCE}
	# TO DO - stop and track all running processes before stopping and the restart after maintenance
	cd ${WAS_UPDATES_HOME}
	wget ${TD_REPOSITORY_HOME}/input_files/${IHS_INSTALL_RESPONSE_FILE}
	sudo su - wasadm "-c ${IM_HOME}/eclipse/tools/imcl \
		-acceptLicense \
		-input ${WAS_UPDATES_HOME}/${IHS_INSTALL_RESPONSE_FILE} \
		-variables ${IHS_IMCL_VARIABLES}"
	rm -f ${IHS_INSTALL_RESPONSE_FILE}
	# TO DO - restart IHS processes
	set +x
fi


#----------------------------------------------------------------------------------------------------------------
# update PLG binaries
# verified = YES
#
if [[ -n ${APPLY_PLG_8554_MAINTENANCE} ]]
then
	set -x
	PLG_INSTALL_RESPONSE_FILE=install_plg_8554.xml
	PLG_IMCL_VARIABLES="im_shared_home=${IM_SHARED_HOME},td_repository_home=${TD_REPOSITORY_HOME},plugin_home=${PLG_HOME}"
	echo APPLY_PLG_8554_MAINTENANCE=${APPLY_PLG_8554_MAINTENANCE}
	# TO DO - stop and track all running processes before stopping and the restart after maintenance
	if [[ ! -d ${PLG_HOME} ]]
	then
		mkdir ${PLG_HOME}
		chown wasadm.wasadm ${PLG_HOME}
	fi
	cd ${WAS_UPDATES_HOME}
	wget ${TD_REPOSITORY_HOME}/input_files/${PLG_INSTALL_RESPONSE_FILE}
	sudo su - wasadm "-c ${IM_HOME}/eclipse/tools/imcl \
		-acceptLicense \
		-input ${WAS_UPDATES_HOME}/${PLG_INSTALL_RESPONSE_FILE} \
		-variables ${PLG_IMCL_VARIABLES}"
	rm -f ${PLG_INSTALL_RESPONSE_FILE}
	# TO DO - restart IHS processes
	set +x
fi


#----------------------------------------------------------------------------------------------------------------
# update WAS binaries
# verified = YES
#
if [[ -n ${APPLY_WAS_8554_MAINTENANCE} ]]
then
	set -x
	WAS_INSTALL_RESPONSE_FILE=install_was_8554.xml
	WAS_IMCL_VARIABLES="im_shared_home=${IM_SHARED_HOME},td_repository_home=${TD_REPOSITORY_HOME},was_home=${WAS_HOME}"
	echo APPLY_WAS_8554_MAINTENANCE=${APPLY_WAS_8554_MAINTENANCE}
	stop_websphere
	cd ${WAS_UPDATES_HOME}
	wget ${TD_REPOSITORY_HOME}/input_files/${WAS_INSTALL_RESPONSE_FILE}
	sudo su - wasadm "-c ${IM_HOME}/eclipse/tools/imcl \
		-acceptLicense \
		-input ${WAS_UPDATES_HOME}/${WAS_INSTALL_RESPONSE_FILE} \
		-variables ${WAS_IMCL_VARIABLES}"
	rm -f ${WAS_INSTALL_RESPONSE_FILE}
	service websphere_dmgr_was.init start
	service websphere_nodeagent_was.init start
	set +x
fi


#----------------------------------------------------------------------------------------------------------------
# create basic IHS configuration
# verified = NO
#
if [[ -n ${CREATE_BASIC_IHS_INSTANCE} ]]
then
	set -x
	if [[ ! -f ${IHS_HOME}/conf/${BASIC_IHS_INSTANCE_NAME}_httpd.conf ]]
	then
		echo CREATE_BASIC_IHS_INSTANCE=${CREATE_BASIC_IHS_INSTANCE}
		stop_websphere
		websphere_security disable
		service websphere_dmgr_was.init start
		WAS_IHS_CONFIG_FILE=/tmp/${BASIC_IHS_INSTANCE_NAME}.properties
		echo "WebServer.name=${BASIC_IHS_INSTANCE_NAME}" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.node=${UNMANAGED_NODE_NAME}" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.webserverInstallRoot=${IHS_HOME}" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.pluginProperties.PluginInstallRoot=${PLG_HOME}" >> ${WAS_IHS_CONFIG_FILE}
		echo "" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.configurationFilename=${IHS_HOME}/conf/${BASIC_IHS_INSTANCE_NAME}_httpd.conf" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.pluginProperties.LogFilename=${IHS_LOG_HOME}/${BASIC_IHS_INSTANCE_NAME}_http_plugin.log" >> ${WAS_IHS_CONFIG_FILE}
		echo "" >> ${WAS_IHS_CONFIG_FILE}
		${WAS_CONTROL_WRAPPER} -auto createWebServer ${WAS_IHS_CONFIG_FILE}
		rm -f ${WAS_IHS_CONFIG_FILE}
		websphere_security enable
		stop_websphere
		service websphere_dmgr_was.init start
		service websphere_nodeagent_was.init start
		mkdir -p ${PLG_HOME}/config/${BASIC_IHS_INSTANCE_NAME}
		chown wasadm.wasadm ${PLG_HOME}/config/${BASIC_IHS_INSTANCE_NAME}
		cd ${PLG_HOME}/config/${BASIC_IHS_INSTANCE_NAME}
		# MAJOR TO DO - figure out transfer of plugin to remote web servers
		cp -p ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME}/config/cells/${WAS_CELL_NAME}/nodes/${UNMANAGED_NODE_NAME}/servers/${BASIC_IHS_INSTANCE_NAME}/plugin-* .
		cd ${IHS_HOME}/conf
		mkdir -p ${DUMP_HOME}/${BASIC_IHS_INSTANCE_NAME}
		cat < httpd.conf \
			| sed -e 's/\(\(^PidFile\) .*\)/#\1\n\2 logs\/'${BASIC_IHS_INSTANCE_NAME}'.pid/g' \
			| sed -e 's/\(\(^Timeout\) .*\)/#\1\n\2 3/g' \
			| sed -e 's/\(^ThreadLimit .*\)/#\1/g' \
			| sed -e 's/\(^ServerLimit .*\)/#\1/g' \
			| sed -e 's/\(^StartServers .*\)/#\1/g' \
			| sed -e 's/\(^MaxClients .*\)/#\1/g' \
			| sed -e 's/\(^MinSpareThreads .*\)/#\1/g' \
			| sed -e 's/\(^MaxSpareThreads .*\)/#\1/g' \
			| sed -e 's/\(^ThreadsPerChild .*\)/#\1/g' \
			| sed -e 's/\(^MaxRequestsPerChild .*\)/#\1\n\tThreadLimit\t\t100\n\tServerLimit\t\t  1\n\tStartServers\t\t  1\n\tMaxClients\t\t100\n\tMinSpareThreads\t\t100\n\tMaxSpareThreads\t\t100\n\tThreadsPerChild\t\t100\n\tMaxRequestsPerChild\t  0/g' \
			| sed -e 's/\(^Listen 80\)/#\1/g' \
			| sed -e 's/\(^LoadModule status_module.*\)/#\1/g' \
			| sed -e 's/\(\(^ErrorLog\) logs\/error_log\)/#\1\n\2 '$(escape_slashes ${IHS_LOG_HOME})'\/'${BASIC_IHS_INSTANCE_NAME}'_error_log/g' \
			| sed -e 's/\(^LogFormat.*agent\)/\1\n\n\n#------------------------------------------------------------\n# TDBG logging formats\n#\nLogFormat \"\%h \%l \%u \%t \\\"\%r\\\" \%>s \%b \\\"\%\{Referer\}i\\\" \\\"\%\{User-Agent\}i\\\" \\\"\%\{Cookie}i\\\"\" extended\nLogFormat \"\%h \%l \%u \%t \\\"\%r\\\" \%>s \%b \%D\" perf\nLogFormat \"\%h \%l \%u \%t \%\{SSL_CIPHER\}e \%\{SSL_CIPHER_USEKEYSIZE\}e \%\{SSL_PROTOCOL\}e \\\"\%r\\\" \%>s \%b\" cipher\nSetEnvIf X-Forwarded-For \^\$ not_forwarded\nLogFormat \"\%\{X-Forwarded-For\}i \%l \%u \%t \\\"\%r\\\" \%>s \%b\" x_forwarded_for_common\nLogFormat \"\%\{X-Forwarded-For\}i \%l \%u \%t \\\"\%r\\\" \%>s \%b \\\"\%\{Referer\}i\\\" \\\"\%\{User-Agent\}i\\\" \\\"\%\{Cookie\}i\\\"\" x_forwarded_for_extended\n/g' \
			| sed -e 's/\(\(^CustomLog\) logs\/access_log \(.*\)\)/#\1\n\2 '$(escape_slashes ${IHS_LOG_HOME})'\/'${BASIC_IHS_INSTANCE_NAME}'_custom_log \3/g' \
			| sed -e 's/\(^#\(AddServerHeader Off\)\)/\1\n\2/g' \
			| sed -e 's/\(\(^ServerSignature\) .*\)/#\1\n\2 Off/g' \
			| sed -e 's/\(^#\(CoreDumpDirectory\) .*\)/\1\n\2 '$(escape_slashes ${DUMP_HOME})'\/'${BASIC_IHS_INSTANCE_NAME}'/g' \
			| sed -e 's/\(\(^ReportInterval\) .*\)/#\1\n\2 60/g' \
			> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "#-------------------------------------" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "# WebSphere PLG Config" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "#" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "LoadModule was_ap22_module ${PLG_HOME}/bin/64bits/mod_was_ap22_http.so" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "WebSpherePluginConfig ${PLG_HOME}/config/${BASIC_IHS_INSTANCE_NAME}/plugin-cfg.xml" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "#-------------------------------------" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "# Global SSL Config" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "#" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "LoadModule ibm_ssl_module modules/mod_ibm_ssl.so" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "SSLDisable" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "KeyFile ${WEBAS_HOME}/config/ssl/${BASIC_IHS_INSTANCE_NAME}.kdb" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "SSLCacheEnable" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "SSLCachePortFileName ${IHS_LOG_HOME}/${BASIC_IHS_INSTANCE_NAME}_siddfile" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "SSLV3Timeout 100" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "#-------------------------------------" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "# Load TD virtual host configuration files" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "#" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "Include conf/${BASIC_IHS_INSTANCE_NAME}_vhosts/*.conf" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
			echo "" >> ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
		chown wasadm.wasadm ${BASIC_IHS_INSTANCE_NAME}_httpd.conf
		# TO DO - find better random password
		KEY_PASS=$(date +%s)
		if [[ ! -d ${WEBAS_HOME}/config/ssl ]]
		then
			mkdir -p ${WEBAS_HOME}/config/ssl
		fi
		${IHS_HOME}/bin/gskcmd -keydb -create -db ${WEBAS_HOME}/config/ssl/${BASIC_IHS_INSTANCE_NAME}.kdb -pw ${KEY_PASS} -type kdb -expire 7300 -stash -populate
		SAN_HOST=$(hostname | sed -e 's/dev/dynamic/g')
		if [[ -n ${SAN_HOST} && ${LOCALHOST_LONG_NAME} != ${SAN_HOST} ]]
		then
			${IHS_HOME}/bin/gskcmd -cert -create -db ${WEBAS_HOME}/config/ssl/${BASIC_IHS_INSTANCE_NAME}.kdb -pw ${KEY_PASS} -type kdb -label ${LOCALHOST_LONG_NAME}_self -dn "CN=${LOCALHOST_LONG_NAME}, OU=ITS, O=TD Bank Group, L=Toronto, ST=ON, C=CA" -expire 7300 -size 2048 -default_cert yes -san_dnsname ${SAN_HOST}
		else
			${IHS_HOME}/bin/gskcmd -cert -create -db ${WEBAS_HOME}/config/ssl/${BASIC_IHS_INSTANCE_NAME}.kdb -pw ${KEY_PASS} -type kdb -label ${LOCALHOST_LONG_NAME}_self -dn "CN=${LOCALHOST_LONG_NAME}, OU=ITS, O=TD Bank Group, L=Toronto, ST=ON, C=CA" -expire 7300 -size 2048 -default_cert yes
		fi
	else
		echo CREATE_BASIC_IHS_INSTANCE=basic IHS instance already created
	fi 
	if [[ ! -d ${IHS_HOME}/conf/${BASIC_IHS_INSTANCE_NAME}_vhosts ]]
	then
		cd ${IHS_HOME}/conf
		mkdir ${BASIC_IHS_INSTANCE_NAME}_vhosts
		BOOTSTRAP_IP=$(hostname -i)
		PORT80_HOST_FILE=${BASIC_IHS_INSTANCE_NAME}_vhosts/${BOOTSTRAP_IP}_80.conf
		echo "Listen ${BOOTSTRAP_IP}:80" >> ${PORT80_HOST_FILE}
		echo "NameVirtualHost ${BOOTSTRAP_IP}:80" >> ${PORT80_HOST_FILE}
		echo "" >> ${PORT80_HOST_FILE}
		echo "<VirtualHost ${BOOTSTRAP_IP}:80>" >> ${PORT80_HOST_FILE}
		echo "  ServerName ${LOCALHOST_LONG_NAME}:80" >> ${PORT80_HOST_FILE}
		echo "  ErrorLog  \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_80_error_log 50M\"" >> ${PORT80_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_80_access_log 50M\" x_forwarded_for_common env=!not_forwarded" >> ${PORT80_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_80_direct_access_log 50M\" common env=not_forwarded" >> ${PORT80_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_80_perf_log 50M\" perf" >> ${PORT80_HOST_FILE}
		echo "</VirtualHost>" >> ${PORT80_HOST_FILE}
		echo "" >> ${PORT80_HOST_FILE}
		echo "<VirtualHost ${BOOTSTRAP_IP}:80>" >> ${PORT80_HOST_FILE}
		echo "  ServerName ${SAN_HOST}:80" >> ${PORT80_HOST_FILE}
		echo "  ErrorLog  \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_80_error_log 50M\"" >> ${PORT80_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_80_access_log 50M\" x_forwarded_for_common env=!not_forwarded" >> ${PORT80_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_80_direct_access_log 50M\" common env=not_forwarded" >> ${PORT80_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_80_perf_log 50M\" perf" >> ${PORT80_HOST_FILE}
		echo "</VirtualHost>" >> ${PORT80_HOST_FILE}
		PORT443_HOST_FILE=${BASIC_IHS_INSTANCE_NAME}_vhosts/${BOOTSTRAP_IP}_443.conf
		echo "Listen ${BOOTSTRAP_IP}:443" >> ${PORT443_HOST_FILE}
		echo "NameVirtualHost ${BOOTSTRAP_IP}:443" >> ${PORT443_HOST_FILE}
		echo "" >> ${PORT443_HOST_FILE}
		echo "<VirtualHost ${BOOTSTRAP_IP}:443>" >> ${PORT443_HOST_FILE}
		echo "  ServerName ${LOCALHOST_LONG_NAME}:443" >> ${PORT443_HOST_FILE}
		echo "  ErrorLog  \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_443_error_log 50M\"" >> ${PORT443_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_443_access_log 50M\" x_forwarded_for_common env=!not_forwarded" >> ${PORT443_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_443_direct_access_log 50M\" common env=not_forwarded" >> ${PORT443_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_443_perf_log 50M\" perf" >> ${PORT443_HOST_FILE}
		echo "  SSLServerCert ${LOCALHOST_LONG_NAME}_self" >> ${PORT443_HOST_FILE}
		echo "  Include conf/vh_ssl.conf" >> ${PORT443_HOST_FILE}
		echo "</VirtualHost>" >> ${PORT443_HOST_FILE}
		echo "" >> ${PORT443_HOST_FILE}
		echo "<VirtualHost ${BOOTSTRAP_IP}:443>" >> ${PORT443_HOST_FILE}
		echo "  ServerName ${SAN_HOST}:443" >> ${PORT443_HOST_FILE}
		echo "  ErrorLog  \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_443_error_log 50M\"" >> ${PORT443_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_443_access_log 50M\" x_forwarded_for_common env=!not_forwarded" >> ${PORT443_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_443_direct_access_log 50M\" common env=not_forwarded" >> ${PORT443_HOST_FILE}
		echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_443_perf_log 50M\" perf" >> ${PORT443_HOST_FILE}
		echo "  SSLServerCert ${LOCALHOST_LONG_NAME}_self" >> ${PORT443_HOST_FILE}
		echo "  Include conf/vh_ssl.conf" >> ${PORT443_HOST_FILE}
		echo "</VirtualHost>" >> ${PORT443_HOST_FILE}
		chown -R wasadm.wasadm ${BASIC_IHS_INSTANCE_NAME}_vhosts
		rm -f vh_ssl.conf
		wget ${TD_REPOSITORY_HOME}/source_media/vh_ssl.conf
		chown wasadm.wasadm vh_ssl.conf
	else
		echo CREATE_BASIC_IHS_INSTANCE=basic IHS vhosts already created
	fi
	set +x
fi


#----------------------------------------------------------------------------------------------------------------
# update WAS_Control
# verified = YES
#
if [[ -n ${APPLY_LATEST_WAS_CONTROL} ]]
then
	set -x
	echo APPLY_LATEST_WAS_CONTROL=${APPLY_LATEST_WAS_CONTROL}
	cd ${TD_MGMT_MW_HOME}
	rm -fr wascontrol
	wget ${TD_REPOSITORY_HOME}/source_media/wascontrol.tar
	tar -xf wascontrol.tar
	cat < /dev/null > ${WAS_CONTROL_WRAPPER}
	echo "sudo su - wasadm \"-c ${WAS_CONTROL_HOME}/bin/was_control.sh \\" >> ${WAS_CONTROL_WRAPPER}
	echo "-was_platform distributed \\" >> ${WAS_CONTROL_WRAPPER}
	echo "-was_location ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME} \\" >> ${WAS_CONTROL_WRAPPER}
	echo "-was_version ${WAS_VERSION} \\" >> ${WAS_CONTROL_WRAPPER}
	echo "-host localhost \\" >> ${WAS_CONTROL_WRAPPER}
	echo "-port ${DMGR_SOAP_PORT} \\" >> ${WAS_CONTROL_WRAPPER}
	echo "\$*\"" >> ${WAS_CONTROL_WRAPPER}
	rm -fr wascontrol/etc/install
	chown wasadm.wasadm ${WAS_CONTROL_WRAPPER}
	chmod 755 ${WAS_CONTROL_WRAPPER}
	rm -fr wascontrol.tar
	set +x
fi


#----------------------------------------------------------------------------------------------------------------
# update LDAP user filter
# verified = YES
#
if [[ -n ${APPLY_LDAP_USER_SEARCH_FILTER} ]]
then
	set -x
	cd ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME}/config/cells/${WAS_CELL_NAME}
	grep -q userPrincipalName security.xml
	if [[ $? -ne 0 ]]
	then
		echo APPLY_LDAP_USER_SEARCH_FILTER=${APPLY_LDAP_USER_SEARCH_FILTER}
		NEW_USER_FILTER="\(\&amp\;\(\|\(sAMAccountName=\%v\)\(userPrincipalName=\%v\)\)\(objectcategory=user\)\)"
		stop_websphere
		cp -p security.xml security.xml_pre_maint_ldap_user_filter
		cat < security.xml_pre_maint_ldap_user_filter | sed 's/\(.*userFilter=\"\).*\(\" krbUserFilter.*\)/\1'${NEW_USER_FILTER}'\2/g' > security.xml
		service websphere_dmgr_was.init start
		service websphere_nodeagent_was.init start
	else
		echo APPLY_LDAP_USER_SEARCH_FILTER=already applied
	fi
	set +x
fi


#----------------------------------------------------------------------------------------------------------------
# add dev MQ certs
# verified = YES
#
if [[ -n ${APPLY_DEV_MQ_CERTS} ]]
then
	set -x
	if [[ ! -f ${WAS_HOME}/td_mq_dev_certs_applied ]]
	then
		echo APPLY_DEV_MQ_CERTS=${APPLY_DEV_MQ_CERTS}
		cd /tmp
		wget ${TD_REPOSITORY_HOME}/source_media/mq_ssl.zip
		unzip mq_ssl.zip
		cd mq_ssl
		KEYTOOL=${WAS_HOME}/java/bin/keytool
		CELL_DEFAULT_TRUST_STORE=${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME}/config/cells/${WAS_CELL_NAME}/trust.p12
		for i in $(ls *.cer)
		do
			${KEYTOOL} -import -noprompt -keystore ${CELL_DEFAULT_TRUST_STORE} -storepass This_is_PROD_123 -storetype PKCS12 -alias $i -file $i
		done
		cd ../
		rm -fr mq_ssl*
		touch ${WAS_HOME}/td_mq_dev_certs_applied
	else
		echo APPLY_DEV_MQ_CERTS=certs already applied
	fi
	set +x
fi

