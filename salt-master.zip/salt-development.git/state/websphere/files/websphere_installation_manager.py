#!/usr/bin/python

import subprocess
import socket
import sys
import getopt
import os
import httplib

# Static
LOCAL_HOST_LONG_NAME = socket.gethostname()
LOCAL_HOST_SHORT_NAME = LOCAL_HOST_LONG_NAME.split('.')[0]

# Required inputs
ACTION = None
HTTPREPO = None

# Default inputs
WAS_BINARY = '/usr/opt/WebSphere855/AppServer/bin/wasservice.sh'  # test state against this binary
WAS_STARTING_PORT = 19000
WAS_UPDATES_HOME = '/WASupdates'
WAS_SHARED_HOME = '/usr/opt/IMWASShared'
WAS_HOME = '/usr/opt/WebSphere855/AppServer'
WAS_BIN_HOME = '{0}/bin'.format(WAS_HOME)
WAS_PROFILE_HOME = '{0}/profiles'.format(WAS_HOME)
WAS_PROFILE_TEMPLATES_HOME = '{0}/profileTemplates'.format(WAS_HOME)
WAS_LOG_HOME = '/td/logs/WebSphere'
WAS_CELL_NAME = '{0}_Cell'.format(LOCAL_HOST_SHORT_NAME)
WAS_USER = 'wasadm'
WAS_GROUP = 'wasadm'
WAS_INSTALL_RESPONSE_FILE = 'was8550_basic_linux_network_install_response_file.xml'
WAS_UPDATE_RESPONSE_FILE = 'was8550_basic_linux_network_update_response_file.xml'

DMGR_HTTPS_PORT = WAS_STARTING_PORT + 1
DMGR_SOAP_PORT = WAS_STARTING_PORT + 3
DMGR_HOST_NAME = LOCAL_HOST_LONG_NAME

IM_MEDIA = 'media_ibmim'
IM_HOME = '/usr/opt/InstallationManager'
IM_DATA_HOME = '/usr/opt/InstallationManagerData'
IM_LOG_HOME = '/td/logs/InstallationManager'

IHS_VERSION = '8.5.5'
IHS_SHARED_HOME = '/usr/opt/IMIHSShared'
IHS_LOG_HOME = '/td/logs/httpd'


def main():
    """
    Main function parses passed in arguments and executes install or uninstall workflow
    """
    try:
        opts, args = getopt.getopt(sys.argv[1:], 'h', ['help', 'install', 'uninstall', 'httprepo='])
    except getopt.GetoptError as err:
        _print_error(str(err))  # will print something like "option -a not recognized"
        sys.exit(2)

    if not opts:
        _print_error('No arguments inputted.')
        sys.exit(2)

    for o, a in opts:
        if o == '--install':
            set_action('install')
        elif o == '--uninstall':
            set_action('uninstall')
        elif o == '--httprepo':
            set_httprepo(a)
        elif o in ("-h", "--help"):
            _usage()
            sys.exit()
        else:
            assert False, "unhandled option"

    if ACTION == 'install' and not HTTPREPO:
        _print_error('--install requires the --httprepo argument.')
        sys.exit(2)
    elif not ACTION:
        _print_error('Requires an action argument.')
        sys.exit(2)

    pre_execution_checks()  # error out if checks do not pass

    if ACTION == 'install':
        install_state()  # check if installed and exit if yes
        install()  # install websphere
    elif ACTION == 'uninstall':
        uninstall_state()  # check if installed and exit if no
        uninstall()  # uninstall websphere
    return


def pre_execution_checks():
    """
    Before running any functions make sure we will be
    able to execute them.
    """
    if not os.geteuid() == 0:
        print 'This script must be ran as the root user!'
        sys.exit(2)
    return


def install_state():
    """
    Check the installed state of Websphere.
    If it is installed exit with no changes made.
    """
    if os.path.isfile(WAS_BINARY):
        print ''
        print 'changed=no comment="Websphere Application Sever is already installed."'
        sys.exit(0)
    return


def uninstall_state():
    """
    Check the installed state of Websphere.
    If it is NOT installed exit with no changes made.
    """
    if not os.path.isfile(WAS_BINARY):
        print ''
        print 'changed=no comment="Websphere Application Sever is not installed."'
        sys.exit(0)
    return


def install():
    def check_return_code(ret_code, error_message):
        """
        :param ret_code: The return code from the sub process module
        :param error_message: Error message as a String

        Check the return if anything other than 0 print error message to screen and error out
        """
        if not ret_code == 0:
            _print_error(error_message, print_usage=False)
            sys.exit(2)
        return

    def install_ibm_installation_manager():
        ret_code = subprocess.call(['su',
                                    '-',
                                    '{0}'.format(WAS_USER),
                                    '"-c cd {0};curl {1}/{2}.tar 2>/dev/null | tar -xf -"'.format(WAS_UPDATES_HOME,
                                                                                                  HTTPREPO,
                                                                                                  IM_MEDIA)])
        check_return_code(ret_code, 'Failed to download and extract IBM Installation Manager.')

        ret_code = subprocess.call(['su',
                                    '-',
                                    '{0}'.format(WAS_USER),
                                    '"-c {0}/{1}/userinstc '
                                    '-acceptLicense '
                                    '-dataLocation {2} '
                                    '-installationDirectory {3} '
                                    '-log {4}/im_install_log.xml '
                                    '1>/dev/null"'.format(WAS_UPDATES_HOME,
                                                          IM_MEDIA,
                                                          IM_DATA_HOME,
                                                          IM_HOME,
                                                          IM_LOG_HOME)])
        check_return_code(ret_code, 'Failed to install IBM Installation Manager.')

        ret_code = subprocess.call(['chown',
                                    '-R',
                                    '{0}.{1}'.format(WAS_USER, WAS_GROUP),
                                    '{0}'.format(IM_HOME)])
        check_return_code(ret_code, 'Failed to set permissions on IBM Installation Manager.')

        subprocess.call(['rm', '-fr', '{0}/{1}'.format(WAS_UPDATES_HOME, IM_HOME)])
        return

    def install_websphere():
        ret_code = subprocess.call(['su',
                                    '-',
                                    '{0}'.format(WAS_USER),
                                    '"-c {0}/eclipse/tools/imcl '
                                    '-acceptLicense '
                                    '-input {1} '
                                    '-log {2}/was_binaries_installation.log '
                                    '1>/dev/null"'.format(IM_HOME, WAS_INSTALL_RESPONSE_FILE, WAS_LOG_HOME)])
        check_return_code(ret_code, 'Failed to install Websphere Application Server.')
        return

    def install_patches():
        ret_code = subprocess.call(['su',
                                    '-',
                                    '{0}',
                                    '"-c {0}/eclipse/tools/imcl '
                                    '-acceptLicense '
                                    '-input {1} '
                                    '-log {2}/was_binaries_update.log '
                                    '1>/dev/null"'.format(IM_HOME,
                                                          WAS_UPDATE_RESPONSE_FILE,
                                                          WAS_LOG_HOME)])
        check_return_code(ret_code, 'Failed to apply patches for Websphere Application Server.')
        return

    def install_init_scripts():
        return

    def add_websphere_to_services():
        """
        Adds the websphere to startup service
        """
        return

    def start_websphere():
        """
        Starts the websphere service
        """
        return

    # Start install workflow
    install_ibm_installation_manager()
    install_websphere()
    install_patches()
    install_init_scripts()
    add_websphere_to_services()
    start_websphere()

    _print_state(changed='yes', comment='Websphere Application Server successfully installed.')
    sys.exit(0)


def uninstall():
    def stop_websphere():
        """
        Shutdown the websphere service
        """
        return

    def remove_websphere_from_services():
        """
        Removes websphere from the startup service
        """
        return

    def uninstall_ibm_installation_manager():
        """
        Delete all instances of IBM Installation Manager
        """
        subprocess.call(['rm', '-fr', '{0}/*'.format(IM_HOME), '2>/dev/null'])
        subprocess.call(['rm', '-fr', '{0}/*'.format(IM_DATA_HOME), '2>/dev/null'])
        subprocess.call(['rm', '-fr', '{0}/.settings'.format(IM_DATA_HOME), '2>/dev/null'])
        subprocess.call(['rm', '-fr', '{0}/*'.format(IM_LOG_HOME), '2>/dev/null'])
        return

    def uninstall_websphere():
        subprocess.call(['rm', '-fr', '{0}/*'.format(WAS_HOME), '2>/dev/null'])
        subprocess.call(['su',
                         '-',
                         '{0}'.format(WAS_USER),
                         'rm',
                         '-fr',
                         '{0}/*'.format(WAS_SHARED_HOME),
                         '2>/dev/null'])
        subprocess.call(['rm', '-fr', '{0}/*'.format(WAS_LOG_HOME), '2>/dev/null'])
        return

    stop_websphere()
    remove_websphere_from_services()
    uninstall_ibm_installation_manager()
    uninstall_websphere()

    _print_state(changed='yes', comment='Websphere Application Server successfully uninstalled.')
    sys.exit(0)


def set_action(action):
    """
    :param action: Should be a string of 'install' or 'uninstall'
    :return: Sets the global var of ACTION or exits script in error

    Use this function to set the ACTION global variable
    """
    global ACTION
    if ACTION:
        _print_error('Cannot use arguments install and uninstall at the same time.')
        sys.exit(2)
    else:
        if action == 'install':
            ACTION = 'install'
        elif action == 'uninstall':
            ACTION = 'uninstall'
        else:
            _print_error('Script action should be "install" or "uninstall" the action {0} is unknown.'.format(action))
            sys.exit(2)
    return


def set_httprepo(httprepo=''):
    """
    :param httprepo: An valid url that points to the HTTP Websphere repo
    :return: Checks that selected repo is reachable or exits script in error

    Use this function to set the HTTPREPO global variable
    """
    global HTTPREPO
    httprepo = httprepo.rstrip('/')
    try:
        c = httplib.HTTPConnection(httprepo.replace('http://', ''))
        c.request("HEAD", '')
        status = c.getresponse().status
    except httplib.InvalidURL:
        _print_error('Bad httprepo url: {0}'.format(httprepo))
        sys.exit(2)
    if not status == 200:
        _print_error('The selected http repository is not responding to requests, error code: {0}'.format(status))
        sys.exit(2)
    else:
        HTTPREPO = httprepo
    return


def _usage():
    """
    Print the script usage to stdout
    """
    print 'Websphere Installation Manager Script'
    print '====================================='
    print ''
    print 'DESCRIPTION:'
    print 'This script utilizes IBM Installation Manager to install Websphere Application Server ' \
          'with the latest updates.'
    print 'This is a stateful script meant to be utilized by saltstack with the "statful" option set to true.'
    print ''
    print 'EXECUTION REQUIREMENTS:'
    print 'This script must be ran as the root user!'
    print 'Tested on RHEL and CentOS.'
    print ''
    print 'REQUIRED ARGUMENTS:'
    print '--install        Installs Websphere application server with the latest patches.'
    print '--uninstall      Uninstalls Websphere application server and all directories.'
    print '--httprepo=[url] Remote repository for IBM Installation Manager to retrieve instruction set and binaries.'
    print ''
    print 'OPTIONAL ARGUMENTS:'
    print '-h   Prints the usage information.'
    return


def _print_error(error_message, print_usage=True):
    """
    :param error_message: The error message a String
    :param print_usage: Print the usage of the script boolean True(Default) or False

    Print an error message to stdout
    """
    print ''
    print 'ERROR: {0}'.format(error_message)
    print ''
    if print_usage:
        _usage()
    return


def _print_state(changed, comment):
    """
    :param changed: Changed should be a String of 'yes' or 'no'
    :param comment: A comment about the state

    Print the state to stdout
    """
    print ''
    print 'changed={0} comment"{1}"'.format(changed, comment)
    return


if __name__ == "__main__":
    main()