def get():
    """
    Generates the RHN Satellite Client activation key based on 
    subscriptions created in the rhn_satellite pillar sls file
    and returns a string comma separated list of keys
    """
    subscriptions = __salt__['pillar.get']('rhn_satellite:client:subscriptions', [])
    roles = __salt__['grains.get']('roles', [])
    os =  __salt__['grains.get']('os', '')
    
    activation_keys = []
    
    if subscriptions:
        for subscription in subscriptions:
            if subscription['roles'] == 'ANY':
                activation_keys.append(subscription['activation_key'])
            else:
                for subscription_role in subscription['roles']:
                    if subscription['activation_key'] not in activation_keys and subscription_role in roles:
                        activation_keys.append(subscription['activation_key'])
    if activation_keys:
        return ",".join(activation_keys)
    else:
        raise NoSubscriptionMatch("No rhn satellite subscription matched!")

class NoSubscriptionMatch(Exception):
    pass
