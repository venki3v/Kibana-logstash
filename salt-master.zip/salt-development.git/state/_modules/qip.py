import re
from urlparse import urlparse

def __virtual__():
    return 'qip'


def _send_request(content, req_type, organization, qip_api, qip_username, qip_password):
    """
    Internal function to send a SOAP XML Request to QIP
    """
    from httplib import HTTPConnection

    api = urlparse(qip_api)

    header = """
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:oas="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd" xmlns:ws="http://alcatel-lucent.com/qip/nb/ws">
  <soapenv:Header>
    <oas:Security>
      <oas:UsernameToken xmlns:wsu="http://docs.oasisopen.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsdhttp://...">
        <oas:Username>{qip_username}</oas:Username>
        <oas:Password Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-usernametoken-profile-1.0#PasswordText">{qip_password}</oas:Password>
      </oas:UsernameToken>
    </oas:Security>
  </soapenv:Header>
  <soapenv:Body>""".format(**locals())

    req_header = """
    <ws:{req_type} xmlns:ws="http://alcatel-lucent.com/qip/nb/ws" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:type="ws:{req_type}">
      <ws:commonParam>
        <ws:organization>{organization}</ws:organization>
      </ws:commonParam>""".format(**locals())

    req_footer = """  
    </ws:{req_type}>""".format(**locals())

    footer = """
  </soapenv:Body>
</soapenv:Envelope>"""

    request_content = header + req_header + content + req_footer + footer

    #print "---- Request:"
    #print request_content

    request = HTTPConnection(api.netloc)
    request.putrequest("POST", api.path)
    request.putheader("Accept", "application/soap+xml, application/dime, multipart/related, text/*")
    request.putheader("Content-Type", "text/xml; charset=utf-8")
    request.putheader("Cache-Control", "no-cache")
    request.putheader("Pragma", "no-cache")
    request.putheader("SOAPAction", api.geturl())
    request.putheader("Content-Length", str(len(request_content)))
    request.endheaders()
    request.send(request_content)
    response = request.getresponse().read()

    #print
    #print "----- Response:"
    #print response

    result = {'faultcode': '', 'faultstring': '', 
              'errorMsg': '', 'errorKey':'', 'successMsg': ''}

    if 'errorKey' in response:
        regex = 'faultcode>(?P<faultcode>.*?)</.*?faultcode>.*?'
        regex += 'faultstring>(?P<faultstring>.*?)</.*?faultstring>.*?'
        regex += 'errorMsg>(?P<errorMsg>.*?)</.*?errorMsg>.*?'
        regex += 'errorKey>(?P<errorKey>.*?)</.*?errorKey>'
        compiled_regex = re.compile(ur'{0}'.format(regex), re.DOTALL)
        results = re.search(compiled_regex, response)
        result['faultcode'] = results.group('faultcode')
        result['faultstring'] = results.group('faultstring') 
        result['errorMsg'] = results.group('errorMsg')
        result['errorKey'] = results.group('errorKey')
    elif 'faultcode' in response:
        regex = 'faultcode>(?P<faultcode>.*?)</.*?faultcode>.*?'
        regex += 'faultstring>(?P<faultstring>.*?)</.*?faultstring>.*?'
        compiled_regex = re.compile(ur'{0}'.format(regex), re.DOTALL)
        results = re.search(compiled_regex, response)
        result['faultcode'] = results.group('faultcode')
        result['faultstring'] = results.group('faultstring')
    elif 'SUCCESS' in response:
        result['successMsg'] = response
    else:
        raise exception

    return result


def lookup(organization, qip_api, qip_username, qip_password, ip_address=None, hostname=None):
    """
    Lookup DNS record in QIP
    """
    if ip_address and hostname:
        search_params = "<ws:objectAddr>{ip_address}</ws:objectAddr><ws:objectName>{hostname}</ws:objectName>".format(**locals())
    elif ip_address:
        search_params = "<ws:objectAddr>{ip_address}</ws:objectAddr><ws:objectName />".format(**locals())
    elif hostname:
        search_params = "<ws:objectAddr /><ws:objectName>{hostname}</ws:objectName>".format(**locals())
    else:
        return False, "Bad lookup parameters no IP Address or Hostname specified."

    #search_params = "<ws:objectAddr /><ws:objectName>{hostname}</ws:objectName>".format(**locals())

    content = """
      <ws:reqObject xsi:type="ws:V4_ADDR_REC">
        {search_params}
      </ws:reqObject>""".format(**locals())


    response = _send_request(content, 'SearchRequest', organization, qip_api, qip_username, qip_password)

    record = {'ip_address':'', 'hostname':'',
              'domain':'', 'fqdn':''}

    if response and response.get('successMsg'):
        regex  = 'objectAddr>(?P<ip_addr>.*?)</.*?objectAddr>.*?'
        regex += 'objectName>(?P<hostname>.*?)</.*?objectName>.*?'
        regex += 'domainName>(?P<domain>.*?)</.*?domainName'
        compiled_regex = re.compile(ur'{0}'.format(regex), re.DOTALL)
        results = re.search(compiled_regex, response.get('successMsg'))
        record['ip_address'] = results.group('ip_addr')
        record['hostname'] = results.group('hostname')
        record['domain'] = results.group('domain')
        record['fqdn'] = "{0}.{1}".format(results.group('hostname'), results.group('domain'))
    return response, record


def delete(ip_address, organization, qip_api, qip_username, qip_password):
    """
    Deletes any potential existing records in QIP
     for the records associated with this IP Address
    """
    content = """
      <ws:reqObject xsi:type="ws:V4_ADDR_REC">
        <ws:objectAddr>{ip_address}</ws:objectAddr>
      </ws:reqObject>""".format(**locals())
    return _send_request(content, 'DeleteRequest', organization, qip_api, qip_username, qip_password)


def update(ip_address, hostname, subnet, domain_name, organization, 
           qip_api, qip_username, qip_password, description='', cname='',
           a_ttl=-1, ptr_ttl=-1, publish_a='Always', publish_ptr='Always'):
    """
    Updates any potential existing records in QIP
     or adds a new record for the fqdn and IP given
    """
    from time import strftime

    todays_date = strftime('%Y-%m-%d')

    content = """
      <ws:reqObject xsi:type="ws:V4_ADDR_REC">
        <ws:objectAddr>{ip_address}</ws:objectAddr>
        <ws:subnetAddr>{subnet}</ws:subnetAddr>
        <ws:objectName>{hostname}</ws:objectName>
        <ws:objectClass>Server</ws:objectClass>
        <ws:domainName>{domain_name}</ws:domainName>
        <ws:objectDesc>{description}</ws:objectDesc>
        <ws:contactId>0</ws:contactId>
        <ws:dynamicConfig>Static</ws:dynamicConfig>
        <ws:nameService>A,PTR</ws:nameService>
        <ws:tombstoned>0</ws:tombstoned>
        <ws:externalComment>Insert</ws:externalComment>
        <ws:externalTimestamp>{todays_date}</ws:externalTimestamp>
        <ws:manual_flag>0</ws:manual_flag>
        <ws:nodeId>0</ws:nodeId>
        <ws:aTTL>{a_ttl}</ws:aTTL>
        <ws:ptrTTL>{ptr_ttl}</ws:ptrTTL>
        <ws:publishA>{publish_a}</ws:publishA>
        <ws:publishPTR>{publish_ptr}</ws:publishPTR>
      </ws:reqObject>""".format(**locals())
    result = _send_request(content, 'AddRequest', organization, qip_api, qip_username, qip_password)

    if result and result.get('successMsg') and cname != '':
        content = """
            <ws:reqObject xsi:type="ws:RR_REC">
                <ws:owner>{cname}</ws:owner>
                <ws:classType>IN</ws:classType>
                <ws:rrType>CNAME</ws:rrType>
                <ws:data1>{hostname}.{domain_name}</ws:data1>
                <ws:publishing>ALWAYS</ws:publishing>
                <ws:ttl>600</ws:ttl>
                <ws:infraType>OBJECT</ws:infraType>
                <ws:infraAddr>{ip_address}</ws:infraAddr>
            </ws:reqObject>""".format(**locals())
        result = _send_request(content, 'AddRequest', organization, qip_api, qip_username, qip_password)

    return result if result else False


def add_zone(domain_name, dns_servers, organization, qip_api, qip_username, qip_password,
             default_ttl=600, expire_time=604800, contact_email='cloud@td.com',
             negative_cache_ttl=600, refresh_time=21600, retry_time=3600):
    """
    Creates a new zone within QIP.

    Notes:
    - Requires authorization to create zones!
    - A defect fixed in VitalQIP 8.1 requires specifying all of the dnsZoneOPtionsList in the request!
    - the input dns_servers is a semi-colon delimited list of PRIMARY DNS Servers.  At this time we do not know
      how to add secondary DNS servers to the list.  Stefan is looking into this w/ the vendor...
    """

    content = """
    <ws:reqObject xsi:type="ws:DNS_ZONE_REC"> 
      <ws:name>{domain_name}</ws:name>
      <ws:dnsServer>{dns_servers};</ws:dnsServer>
      <ws:defaultTtl>{default_ttl}</ws:defaultTtl>
      <ws:email>{contact_email}</ws:email>
      <ws:expireTime>{expire_time}</ws:expireTime>
      <ws:negativeCacheTtl>{negative_cache_ttl}</ws:negativeCacheTtl>
      <ws:refreshTime>{refresh_time}</ws:refreshTime>
      <ws:retryTime>{retry_time}</ws:retryTime>
      <ws:dnsZoneOptionList>
        <ws:groupOption>
          <ws:name>Extensions</ws:name>
          <ws:option>
            <ws:name>Postfix of zone db file</ws:name>
            <ws:value>1</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>Prefix of zone db file</ws:name>
            <ws:value>1</ws:value>
          </ws:option>
        </ws:groupOption>
        <ws:groupOption>
          <ws:name>ALU DNS 6.0 Options</ws:name>
            <ws:option>
            <ws:name>allow-query</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-notify</ws:name>
            <ws:value>Use Server Value</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-update</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>zone block of named.conf</ws:name>
            <ws:value>1</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>notify</ws:name>
            <ws:value>No</ws:value>
            <ws:subOption>
              <ws:name>also-notify</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>Import External Updates</ws:name>
            <ws:value>False</ws:value>
            <ws:subOption>
              <ws:name>TXT (Text)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>SRV (Server Resource Record)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>A (Host IPV4)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>PTR (Pointer)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>CNAME(Canonical Name)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>AAAA (Host IPV6)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>forwarders</ws:name>
            <ws:value> </ws:value>
            <ws:subOption>
              <ws:name>forward</ws:name>
              <ws:value>Use Server Value</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>DNSSEC enabled zone</ws:name>
            <ws:value>False</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>allow-transfer</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
        </ws:groupOption>
        <ws:groupOption>
          <ws:name>LUCENT DNS 5.X Options</ws:name>
          <ws:option>
            <ws:name>allow-query</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-notify</ws:name>
            <ws:value>Use Server Value</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-update</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>forwarders</ws:name>
            <ws:value>1</ws:value>
            <ws:subOption>
              <ws:name>forward</ws:name>
              <ws:value>Use Server Value</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>zone block of named.conf</ws:name>
            <ws:value>1</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>notify</ws:name>
            <ws:value>No</ws:value>
            <ws:subOption>
              <ws:name>also-notify</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>Import External Updates</ws:name>
            <ws:value>False</ws:value>
            <ws:subOption>
              <ws:name>TXT (Text)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>SRV (Server Resource Record)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>A (Host IPV4)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>PTR(Pointer)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>AAAA (Host IPV6)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>CNAME (Canonical Name)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>DNSSEC enabled zone</ws:name>
            <ws:value>False</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>allow-transfer</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
        </ws:groupOption>
        <ws:groupOption>
          <ws:name>BIND-8.X Options</ws:name>
          <ws:option>
            <ws:name>allow-query</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-update</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>zone block of named.conf</ws:name>
            <ws:value>1</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>notify</ws:name>
            <ws:value>No</ws:value>
            <ws:subOption>
              <ws:name>also-notify</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-transfer</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>check-names</ws:name>
            <ws:value>Warn</ws:value>
          </ws:option>
        </ws:groupOption>
        <ws:groupOption>
          <ws:name>LUCENT DNS 4.X Options</ws:name>
          <ws:option>
            <ws:name>allow-query</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-notify</ws:name>
            <ws:value>Use Server Value</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-update</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>forwarders</ws:name>
            <ws:value>1</ws:value>
            <ws:subOption>
              <ws:name>forward</ws:name>
              <ws:value>Use Server Value</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>Import External Updates</ws:name>
            <ws:value>False</ws:value>
            <ws:subOption>
              <ws:name>TXT (Text)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>SRV (Server Resource Record)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>A (Host IPV4)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>PTR (Pointer)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>AAAA (Host IPV6)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>CNAME (Canonical Name)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>zone block of named.conf</ws:name>
            <ws:value>1</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>notify</ws:name>
            <ws:value>No</ws:value>
            <ws:subOption>
              <ws:name>also-notify</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>DNSSEC enabled zone</ws:name>
            <ws:value>False</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>allow-transfer</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
        </ws:groupOption>
        <ws:groupOption>
          <ws:name>LUCENT DNS 3.X Options</ws:name>
          <ws:option>
            <ws:name>allow-query</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-update</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>zone block of named.conf</ws:name>
            <ws:value>1</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>Import External Updates</ws:name>
            <ws:value>False</ws:value>
            <ws:subOption>
              <ws:name>TXT (Text)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>SRV (Server Resource Record)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>A (Host IPV4)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>PTR (Pointer)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>AAAA (Host IPV6)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>CNAME (Canonical Name)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>notify</ws:name>
            <ws:value>No</ws:value>
            <ws:subOption>
              <ws:name>also-notify</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-transfer</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>check-names</ws:name>
            <ws:value>Warn</ws:value>
          </ws:option>
        </ws:groupOption>
        <ws:groupOption>
          <ws:name>WINDOWS 2000 DNS Options</ws:name>
          <ws:option>
            <ws:name>no-refresh-interval</ws:name>
            <ws:value>0</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>zone-options</ws:name>
            <ws:value>1</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>allow-update</ws:name>
            <ws:value>No</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>notify</ws:name>
            <ws:value>No</ws:value>
            <ws:subOption>
              <ws:name>List</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-transfer</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>List</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>refresh-interval</ws:name>
            <ws:value>0</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>aging</ws:name>
            <ws:value>False</ws:value>
          </ws:option>
        </ws:groupOption>
        <ws:groupOption>
          <ws:name>BIND-9.X Options</ws:name>
          <ws:option>
            <ws:name>allow-query</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-notify</ws:name>
            <ws:value>Use Server Value</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-update</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>forwarders</ws:name>
            <ws:value>1</ws:value>
            <ws:subOption>
              <ws:name>forward</ws:name>
              <ws:value>Use Server Value</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>zone block of named.conf</ws:name>
            <ws:value>1</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>notify</ws:name>
            <ws:value>No</ws:value>
            <ws:subOption>
              <ws:name>also-notify</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>DNSSEC enabled zone</ws:name>
            <ws:value>False</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>allow-transfer</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
        </ws:groupOption>
        <ws:groupOption>
          <ws:name>ALU DNS 6.1 Options</ws:name>
          <ws:option>
            <ws:name>allow-query</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-notify</ws:name>
            <ws:value>Use Server Value</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>allow-update</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>forwarders</ws:name>
            <ws:value>1</ws:value>
            <ws:subOption>
              <ws:name>forward</ws:name>
              <ws:value>Use Server Value</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>zone block of named.conf</ws:name>
            <ws:value>1</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>notify</ws:name>
            <ws:value>No</ws:value>
            <ws:subOption>
              <ws:name>also-notify</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>Import External Updates</ws:name>
            <ws:value>False</ws:value>
            <ws:subOption>
              <ws:name>TXT (Text)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>SRV (Server Resource Record)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>A (Host IPV4)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>PTR (Pointer)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>CNAME(Canonical Name)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>AAAA (Host IPV6)</ws:name>
              <ws:value>False</ws:value>
            </ws:subOption>
          </ws:option>
          <ws:option>
            <ws:name>DNSSEC enabled zone</ws:name>
            <ws:value>False</ws:value>
          </ws:option>
          <ws:option>
            <ws:name>allow-transfer</ws:name>
            <ws:value>Any</ws:value>
            <ws:subOption>
              <ws:name>other</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
            <ws:subOption>
              <ws:name>ACL Templates</ws:name>
              <ws:value>1</ws:value>
            </ws:subOption>
          </ws:option>
        </ws:groupOption>

      </ws:dnsZoneOptionList> 
    </ws:reqObject>""".format(**locals())

    return _send_request(content, 'AddRequest', organization, qip_api, qip_username, qip_password)

def add_subnet(subnet_address, subnet_mask, network_address, organization, qip_api, qip_username, qip_password):
    """
    Creates a new subnet within QIP.
    """

    content = """
    <ws:reqObject xsi:type="ws:V4_SUBNET_REC"> 
      <ws:subnetAddress>{subnet_address}</ws:subnetAddress>
      <ws:subnetMask>{subnet_mask}</ws:subnetMask>
      <ws:networkAddress>{network_address}</ws:networkAddress>
    </ws:reqObject>""".format(**locals())

    return _send_request(content, 'AddRequest', organization, qip_api, qip_username, qip_password)


def get_zone(zone, organization, qip_api, qip_username, qip_password):
    """
    Retrieves information pertaining a QIP zone
    """
    content = """
      <ws:reqObject xsi:type="ws:DNS_ZONE_REC">
        <ws:name>{zone}</ws:name>
      </ws:reqObject>""".format(**locals())

    response = _send_request(content, 'GetRequest', organization, qip_api, qip_username, qip_password)

    record = {'zone_name': zone}

    if response.get('errorKey') == 'ZONE_NOT_FOUND':
        return False, "Zone {0} does not exist.  Needs created?".format(zone)

    return response, record

def get_subnet(ip_subnet, organization, qip_api, qip_username, qip_password):
    """
    Retrieves information pertaining 
    """
    content = """
      <ws:reqObject xsi:type="ws:V4_SUBNET_REC">
        <ws:subnetAddress>{ip_subnet}</ws:subnetAddress>
      </ws:reqObject>""".format(**locals())

    response = _send_request(content, 'GetRequest', organization, qip_api, qip_username, qip_password)

    record = {'subnet_addr':'', 'subnet_mask':'',
              'network_addr':'', 'subnet_name':'',
              'domains': []}

    if 'SUCCESS' in response.get('successMsg'):
        regex  = 'subnetAddress>(?P<subnet_addr>.*?)</.*?subnetAddress>.*?'
        regex += 'subnetMask>(?P<subnet_mask>.*?)</.*?subnetMask.*?'
        regex += 'networkAddress>(?P<network_addr>.*?)</.*?networkAddress>.*?'
        regex += '(?:subnetName>(?P<subnet_name>.*?)</.*?subnetName>|).*?'
        regex += '(?:domains>(?P<domains>.*?</.*?domains>)|)'
        compiled_regex = re.compile(ur'{0}'.format(regex), re.DOTALL)
        results = re.search(compiled_regex, response.get('successMsg'))
        record['subnet_addr'] = results.group('subnet_addr')
        record['subnet_mask'] = results.group('subnet_mask')
        record['network_addr'] = results.group('network_addr')
        record['subnet_name'] = results.group('subnet_name')
    
        if results.group('domains'):    
            domain_names_regex = 'name>(?P<domain_name>.*?)</.*?name>'
            compiled_regex = re.compile(ur'{0}'.format(domain_names_regex))
            record['domains'] = re.findall(compiled_regex, results.group('domains'))

    return response, record


def add_zone_to_subnet(ip_subnet, zone, organization, qip_api, qip_username, qip_password):
    """
    Adds an IP Subnet to an existing Zone in QIP
    Note: This is required in QIP to add any IPs under a zone if not already registered
    Note: There is no way to 'append' an additional subnet to an existing zone, you have to
          find 
    """

    # Check to make sure the zone exists..
    # iJS: this cant be done until we can get the zone w/o exception...
    #response, existing = get_zone(zone, organization, qip_api, qip_username, qip_password)
    #if not response or 'SUCCESS' not in response:
        #add_zone(zone, organization, qip_api, qip_username, qip_password)

    response, existing = get_subnet(ip_subnet, organization, qip_api, qip_username, qip_password)

    if not existing.get('subnet_mask'):
        return False, "Subnet {ip_subnet} does not exist.  Perhaps it is a subset of an existing superset?".format(**locals())
    elif zone in existing.get('domains'):
        return False, "Zone {zone} already exists in subnet {ip_subnet}".format(**locals())

    subnet_addr = existing.get('subnet_addr')
    subnet_mask = existing.get('subnet_mask')
    subnet_name = existing.get('subnet_name')

    content = """
      <ws:reqObject xsi:type="ws:V4_SUBNET_REC">
        <ws:subnetAddress>{subnet_addr}</ws:subnetAddress>
        <ws:subnetMask>{subnet_mask}</ws:subnetMask>
        <ws:networkAddress>{ip_subnet}</ws:networkAddress>
        <ws:subnetName>{subnet_name}</ws:subnetName>
        <ws:domains>
          <ws:name>{zone}</ws:name>""".format(**locals())

    for domain in existing.get('domains'): 
        content += """
          <ws:name>{0}</ws:name>""".format(domain)

    content += """
        </ws:domains>
      </ws:reqObject>
      <ws:key xsi:type="ws:V4_SUBNET_KEY">
        <ws:update>false</ws:update>
      </ws:key>""".format(**locals())

    return _send_request(content, 'UpdateRequest', organization, qip_api, qip_username, qip_password)
