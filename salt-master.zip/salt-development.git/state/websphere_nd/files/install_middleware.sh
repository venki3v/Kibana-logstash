#!/bin/sh
#set -x


#------------------------------------------------
# TO DOs:
#
# MAJOR TO DO - remove contents of target directories prior to installation.  See following link:
#             - http://www-01.ibm.com/support/knowledgecenter/SSAW57_8.5.5/com.ibm.websphere.installation.nd.doc/ae/tins_aixsetup.html?cp=SSAW57_8.5.5%2F1-5-0-4-0
# TO DO - register services so that servie.running can check id WAS is running
# TO DO - re-order error codes
# MINOR TO DO - find out WHY is IM creating root ownwed files and fix
	# echo "-Dosgi.locking=none" >> ${IM_HOME}/eclipse/silent-install.ini


#------------------------------------------------
# constants - if override is required set as ENV variable - DO NOT OVERRIDE HERE
#
DISPLAY_MESSAGES=${DISPLAY_MESSAGES:-shell}
TD_ENVIRONMENT=${TD_ENVIRONMENT:-AD_DEV}
TD_REPOSITORY_HOME=${TD_REPOSITORY_HOME:-http://10.112.213.57/nexus/content/repositories/WebsphereND}
TD_REPOSITORY_WAS_CONTROL_HOME=${TD_REPOSITORY_WAS_CONTROL_HOME:-${TD_REPOSITORY_HOME}}
WAS_UPDATES_HOME=${WAS_UPDATES_HOME:-/WASupdates}
OS=$(uname)
WHOAMI=$(whoami)

IM_VERSION=${IM_VERSION:-1.8.0}
IM_PACKAGE_PATTERN=com.ibm.cic.agent
IM_MEDIA_BASE=${IM_MEDIA_BASE:-media_ibmim}
if [[ ${OS} == "AIX" ]]
then
	IM_MEDIA_BASE=${IM_MEDIA_BASE}_aix
fi
if [[ ${IM_VERSION} == "1.8.0" ]]
then
	IM_MEDIA=${IM_MEDIA:-${IM_MEDIA_BASE}_180}
fi
IM_HOME=${IM_HOME:-/usr/opt/InstallationManager}
IM_DATA_HOME=${IM_DATA_HOME:-/usr/opt/InstallationManagerData}
IMCL=${IM_HOME}/eclipse/tools/imcl
IM_SHARED_HOME=${IM_SHARED_HOME:-/usr/opt/IMShared}

APPLICATION_HOME=${APPLICATION_HOME:-/webAS}
TD_LIB_HOME=${TD_LIB_HOME:-/usr/opt/tdlib}

IHS_VERSION=${IHS_VERSION:-8.5.5}
if [[ ${IHS_VERSION} == "8.0" ]]
then
	IHS_FIXPACK=${IHS_FIXPACK:-11}
	IHS_PACKAGE_PATTERN=com.ibm.websphere.IHS.v80
	IHS_HOME=${IHS_HOME:-/usr/opt/HTTPServer8}
	IHS_INSTALL_RESPONSE_FILE=${IHS_INSTALL_RESPONSE_FILE:-install_ihs_800${IHS_FIXPACK}.xml}
elif [[ ${IHS_VERSION} == "8.5.5" ]]
then
	IHS_FIXPACK=${IHS_FIXPACK:-6}
	IHS_PACKAGE_PATTERN=com.ibm.websphere.IHS.v85
	IHS_HOME=${IHS_HOME:-/usr/opt/HTTPServer855}
	IHS_INSTALL_RESPONSE_FILE=${IHS_INSTALL_RESPONSE_FILE:-install_ihs_855${IHS_FIXPACK}.xml}
fi

PLG_VERSION=${PLG_VERSION:-8.5.5}
if [[ ${PLG_VERSION} == "8.0" ]]
then
	PLG_FIXPACK=${PLG_FIXPACK:-11}
	PLG_PACKAGE_PATTERN=com.ibm.websphere.PLG.v80
	PLG_HOME=${PLG_HOME:-/usr/opt/WebSphere8/Plugins}
	PLG_INSTALL_RESPONSE_FILE=${PLG_INSTALL_RESPONSE_FILE:-install_plg_800${PLG_FIXPACK}.xml}
elif [[ ${PLG_VERSION} == "8.5.5" ]]
then
	PLG_FIXPACK=${PLG_FIXPACK:-6}
	PLG_PACKAGE_PATTERN=com.ibm.websphere.PLG.v85
	PLG_HOME=${PLG_HOME:-/usr/opt/WebSphere855/Plugins}
	PLG_INSTALL_RESPONSE_FILE=${PLG_INSTALL_RESPONSE_FILE:-install_plg_855${PLG_FIXPACK}.xml}
fi

WAS_VERSION=${WAS_VERSION:-8.5.5}
if [[ ${WAS_VERSION} == "7.0" ]]
then
	WAS_HOME=${WAS_HOME:-/usr/opt/WebSphere7/AppServer}
	WAS_LOG_HOME=${WAS_LOG_HOME:-/td/logs/WebSphere/v7}
	WAS_STARTING_PORT=${WAS_STARTING_PORT:-17000}
elif [[ ${WAS_VERSION} == "8.0" ]]
then
	WAS_FIXPACK=${WAS_FIXPACK:-11}
	WAS_PACKAGE_PATTERN=com.ibm.websphere.ND.v80
	WEB2MOBILE_PACKAGE_PATTERN=com.ibm.websphere.WEB2MOBILE.v11
	if [[ ${WAS_FIXPACK} -le 9 ]]
	then
		WXSCLIENT_PACKAGE_PATTERN=com.ibm.websphere.WXSCLIENT.was8.v85
	else
		WXSCLIENT_PACKAGE_PATTERN=com.ibm.websphere.WXSCLIENT.was8.v86
	fi
	WAS_HOME=${WAS_HOME:-/usr/opt/WebSphere8/AppServer}
	WAS_LOG_HOME=${WAS_LOG_HOME:-/td/logs/WebSphere/v8}
	WAS_STARTING_PORT=${WAS_STARTING_PORT:-18000}
	WAS_INSTALL_RESPONSE_FILE=${WAS_INSTALL_RESPONSE_FILE:-install_was_800${WAS_FIXPACK}.xml}
elif [[ ${WAS_VERSION} == "8.5.5" ]]
then
	WAS_FIXPACK=${WAS_FIXPACK:-6}
	WAS_PACKAGE_PATTERN=com.ibm.websphere.ND.v85
	IBMJAVA70_PACKAGE_PATTERN=com.ibm.websphere.IBMJAVA.v70
	IBMJAVA71_PACKAGE_PATTERN=com.ibm.websphere.IBMJAVA.v71
	WEB2MOBILE_PACKAGE_PATTERN=com.ibm.websphere.W2MTK.v11
	WXSCLIENT_PACKAGE_PATTERN=com.ibm.websphere.WXSCLIENT.was8.v86
	WAS_HOME=${WAS_HOME:-/usr/opt/WebSphere855/AppServer}
	WAS_LOG_HOME=${WAS_LOG_HOME:-/td/logs/WebSphere/v855}
	WAS_STARTING_PORT=${WAS_STARTING_PORT:-19000}
	WAS_INSTALL_RESPONSE_FILE=${WAS_INSTALL_RESPONSE_FILE:-install_was_855${WAS_FIXPACK}.xml}
fi

DUMP_HOME=${DUMP_HOME:-/td/logs/dump}
WAS_TEMP_HOME=${WAS_TEMP_HOME:-/td/wasTemp}
WEB_LOG_HOME=${WEB_LOG_HOME:-/td/logs/WebLogs}
WAS_BIN_HOME=${WAS_BIN_HOME:-${WAS_HOME}/bin}
WAS_PROFILE_HOME=${WAS_PROFILE_HOME:-${WAS_HOME}/profiles}
WAS_PROFILE_TEMPLATES_HOME=${WAS_PROFILE_TEMPLATES_HOME:-${WAS_HOME}/profileTemplates}
TD_MGMT_MW_HOME=${TD_MGMT_HOME:-/td/mgmt/middleware}
MW_TOOLBOX_HOME=${MW_TOOLBOX_HOME:-${TD_MGMT_MW_HOME}/bin}
WAS_CONTROL_WRAPPER=${WAS_CONTROL_WRAPPER:-${MW_TOOLBOX_HOME}/was_control.sh}
WAS_CONTROL_HOME=${WAS_CONTROL_HOME:-${TD_MGMT_MW_HOME}/wascontrol}
DMGR_HTTPS_PORT=${DMGR_HTTPS_PORT:-$((${WAS_STARTING_PORT}+1))}
DMGR_SOAP_PORT=${DMGR_SOAP_PORT:-$((${WAS_STARTING_PORT}+3))}
LOCALHOST_LONG_NAME=${LOCALHOST_LONG_NAME:-$(hostname)}
LOCALHOST_SHORT_NAME=${LOCALHOST_SHORT_NAME:-$(hostname -s)}
WAS_CELL_NAME=${WAS_CELL_NAME:-${LOCALHOST_SHORT_NAME}_Cell}
DMGR_NODE_NAME=${DMGR_NODE_NAME:-${LOCALHOST_SHORT_NAME}_CellManager}
DMGR_HOST_NAME=${DMGR_HOST_NAME:-${LOCALHOST_LONG_NAME}}
DMGR_PROFILE_NAME=${DMGR_PROFILE_NAME:-${DMGR_NODE_NAME}}
MANAGED_NODE_NAME=${MANAGED_NODE_NAME:-${LOCALHOST_SHORT_NAME}_node}
MANAGED_HOST_NAME=${MANAGED_HOST_NAME:-${LOCALHOST_LONG_NAME}}
MANAGED_PROFILE_NAME=${MANAGED_PROFILE_NAME:-${MANAGED_NODE_NAME}}
MANAGED_JMX_PORT=${MANAGED_JMX_PORT:-8880}
NODE_STARTING_PORT=${NODE_STARTING_PORT:-$((${WAS_STARTING_PORT}+25))}
UNMANAGED_NODE_NAME=${UNMANAGED_NODE_NAME:-${LOCALHOST_SHORT_NAME}_web}
UNMANAGED_HOST_NAME=${UNMANAGED_HOST_NAME:-${LOCALHOST_LONG_NAME}}
UNMANAGED_OS_TYPE=$(echo ${UNMANAGED_OS_TYPE:-${OS}} | tr '[:upper:]' '[:lower:]')
IHS_LOG_HOME=${IHS_LOG_HOME:-/td/logs/httpd}
IHS_INSTANCE_NAME=${IHS_INSTANCE_NAME:-ihs_${LOCALHOST_SHORT_NAME}}
IHS_ADMIN_PORT=${IHS_ADMIN_PORT:-8008}
IHS_ADMIN_CONF=admin.conf


#---------------------------------------------------
# prepare string with slashes to be used in sed
#
function escape_slashes {
        RETURN=$(echo "$1" | sed 's/\//\\\//g')
        echo ${RETURN}
        }


#------------------------------------------------
# commander function
# TO DO - add header to log to make stand out
#
function commander {
	#set -x
	COMMAND=$1
	COMMAND_MESSAGE=$2
	#echo
	#echo "Running Command \"${COMMAND_MESSAGE}\""
	#echo "Command Syntax: \"${COMMAND}\""
	if [[ ${WHOAMI} == "root" ]]
	then
		echo ${COMMAND} >> /tmp/command_root.out
		echo >> /tmp/command_root.out
		su - wasadm "-c umask 027;${COMMAND}"
	elif [[ ${WHOAMI} == "wasadm" ]]
	then
		echo ${COMMAND} >> /tmp/command_wasadm.out
		echo >> /tmp/command_wasadm.out
		sh -c "umask 027;${COMMAND}"
		#umask 027;${COMMAND}
	else
		standard_error_handler 2 "Must be wasadm or root user."
	fi
	if [[ $? -ne 0 ]]
	then
		standard_error_handler 3 "Issue encountered running \"${COMMAND_MESSAGE}\" command."
	fi
	}


#------------------------------------------------
# standard out handler
#
function standard_output_handler {
	#set -x
	#set +x
	OUTPUT_MESSAGE=$1
	CR=$2
	if [[ -n ${DISPLAY_MESSAGES} ]]
	then
		if [[ ${CR} == "cr" ]]
		then
			#echo ${OUTPUT_MESSAGE}
			echo "$1"
		elif [[ ${CR} == "nocr" ]]
		then
			if [[ ${OS} == "AIX" ]]
			then
				echo "${OUTPUT_MESSAGE}\c"
			elif [[ ${OS} == "Linux" ]]
			then
				echo -n ${OUTPUT_MESSAGE}
			fi
		fi
	fi
	#set -x
	}


#------------------------------------------------
# standard error handler
#
function standard_error_handler {
	#set -x
	ERROR_CODE=$1
	ERROR_MESSAGE=$2
	standard_output_handler "" cr
	standard_output_handler "" cr
	echo "ERROR ${ERROR_CODE}: ${ERROR_MESSAGE}" 1>&2
	if [[ ${DISPLAY_MESSAGES} == "shell" ]]
	then
		standard_output_handler "" cr
	fi
	standard_output_handler "" cr
	if [[ ${DISPLAY_MESSAGES} == "salt" ]]
	then
		standard_output_handler "changed=no comment='ERROR ${ERROR_CODE}: ${ERROR_MESSAGE}'" cr
	fi
	exit ${ERROR_CODE}
	}


#------------------------------------------------
# Prompt for input
#
function user_input {
	#set -x
	MESSAGE=$1
	standard_output_handler "" cr
	standard_output_handler "ACTION_USER_INPUT:" cr
	while true
	do
		read -p "- ${MESSAGE}: " yn
		case ${yn}
		in
			*) break;;
		esac
	done
	}


#------------------------------------------------
# wsadmin wrapper function
#
function run_was_control {
	#set -x
	WAS_CONTROL_FUNCTION=$1
	WAS_CONTROL_ARGS=$2
	standard_output_handler "" cr
	standard_output_handler "	ACTION_WAS_CONTROL_COMMAND:" cr
	standard_output_handler "	-  Function: ${WAS_CONTROL_FUNCTION}" cr
	standard_output_handler "	- Arguments: ${WAS_CONTROL_ARGS}" cr
	commander "${WAS_CONTROL_HOME}/bin/was_control.sh \
	-auto \
	-was_platform distributed \
	-was_location ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME} \
	-was_version ${WAS_VERSION} \
	-host ${DMGR_HOST_NAME} \
	-port ${DMGR_SOAP_PORT} \
	${WAS_CONTROL_FUNCTION} ${WAS_CONTROL_ARGS}" \
	"WAS Control"
	}


#------------------------------------------------
# wsadmin wrapper function
#
function run_wsadmin {
	#set -x
	WSADMIN_LANG=$1
	WSADMIN_SCRIPT_FILE=$2
	WSADMIN_ARGS=$3
	standard_output_handler "" cr
	standard_output_handler "	ACTION_WSADMIN_COMMAND:" cr
	standard_output_handler "	-  Language: ${WSADMIN_LANG}" cr
	standard_output_handler "	-    Script: ${WSADMIN_SCRIPT_FILE}" cr
	standard_output_handler "	- Arguments: ${WSADMIN_ARGS}" cr
	commander "${WAS_CONTROL_HOME}/bin/was_control.sh \
	-auto \
	-was_location ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME} \
	-was_version ${WAS_VERSION} \
	-host ${DMGR_HOST_NAME} \
	-port ${DMGR_SOAP_PORT} \
	run${WSADMIN_LANG}Script ${WSADMIN_SCRIPT_FILE} ${WSADMIN_ARGS}" \
	"WSAdmin"
	standard_output_handler "" cr
	}


#------------------------------------------------
# Install IM
#
function install_im {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_IM_INSTALL:" cr
	# TO DO - use package_installed function
	if [[ -x ${IMCL} ]]
	then
		IM_VERSION_ACTUAL=$(commander "${IMCL} version" "IMCL version command" | grep ^Version | awk '{print $2}')
		if [[ $(echo ${IM_VERSION_ACTUAL} | tr -d '.') -lt $(echo ${IM_VERSION} | tr -d '.') ]]
		then
			standard_output_handler "- Installation Manager requires an update." cr
		else
			standard_output_handler "- IBM Installation Manager already at the desired version.  Skipping Installation." cr
		fi
	else
		standard_output_handler "- Installation Manager not installed." cr
		#------------------------------------------------
		# Retrieve and expand IM media
		#
		standard_output_handler "- Retrieving IBM Installation Manager media..." nocr
		commander "wget -q ${TD_REPOSITORY_HOME}/source_media/${IM_MEDIA}.tar -O - | tar -xf - -C ${WAS_UPDATES_HOME} 2>/dev/null" "wget IM media"
		if [[ $? -ne 0 ]]
		then
			standard_error_handler 2 "Issue retrieving Installation Manager media."
		fi
		standard_output_handler "Done." cr
		#------------------------------------------------
		# Remove IM_HOME and IM_SHARED_HOME lost+found
		#
		if [[ -d ${IM_HOME}/lost+found ]]
		then
			standard_output_handler "- Removing IM lost+found directory..." nocr
			commander "rm -fr ${IM_HOME}/lost+found" "Remove IM HOME Lost and Found"
			standard_output_handler "Done." cr
		fi
		if [[ -d ${IM_SHARED_HOME}/lost+found ]]
		then
			standard_output_handler "- Removing IM Shared lost+found directory..." nocr
			commander "rm -fr ${IM_SHARED_HOME}/lost+found" "Remove IM SHARED HOME Lost and Found"
			standard_output_handler "Done." cr
		fi
		#------------------------------------------------
		# Install the Installation Manager
		#
		standard_output_handler "- Installing IBM Installation Manager..." cr
		commander "${WAS_UPDATES_HOME}/${IM_MEDIA}/userinstc \
			-acceptLicense \
			-dataLocation ${IM_DATA_HOME} \
			-installationDirectory ${IM_HOME}" \
			"Install IM"
		#------------------------------------------------
		# Cleanup Installation Manager non-wasadm (i.e. root) owned files
		# TO DO - figure why this is happening and fix
		#
		standard_output_handler "- Overriding IBM Installation Manager file ownership/permissions issue..." nocr
		if [[ ${WHOAMI} == "root" ]]
		then
			chown -R wasadm.wasadm ${IM_HOME}
		fi
		standard_output_handler "Done." cr
		#------------------------------------------------
		# remove temporary installation files
		#
		if [[ -n ${IM_MEDIA} && -d ${WAS_UPDATES_HOME}/${IM_MEDIA} ]]
		then
			standard_output_handler "- Removing temporary installation files..." nocr
			commander "rm -fr ${WAS_UPDATES_HOME}/${IM_MEDIA}" "Remove IM MEDIA"
			standard_output_handler "Done." cr
		fi
		#------------------------------------------------
		# Set STATE VARIABLE
		#
		export $(echo STATE_package_${IM_PACKAGE_PATTERN} | tr '.' '_')=installed
	fi
	}


#------------------------------------------------
# uninstall IM
# TO DO - complete function
#
function uninstall_im {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_IM_UNINSTALL:" cr
	# TO DO - shutdown any running IM processes
	# TO DO - remove all installed packages first in S
	if [[ -x ${IMCL} ]]
	then
		INSTALL_PACKAGES=$(commander "${IMCL} listInstalledPackages" "IMCL list packages" | grep -v ${IM_PACKAGE_PATTERN})
		if [[ $? -ne 0 ]]
		then
			# TO DO - figure out how to do proper uninstall. see link:
			#         http://www-01.ibm.com/support/knowledgecenter/SSDV2W_1.8.0/com.ibm.cic.agent.ui.doc/topics/t_uninstall_im.html
			delete_files IM
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export $(echo STATE_package_${IM_PACKAGE_PATTERN} | tr '.' '_')=uninstalled
		else
			standard_error_handler 20 "Packages are still present.  Please uninstall packages prior to uninstalling Install Manager"
		fi
	else
		# TO DO - handle if IMCL not available
		standard_output_handler "- IM already removed." cr
	fi
	}


#------------------------------------------------
# package installer function
#
function install_package {
	#set -x
	PACKAGE_TYPE=$1
	INPUT_FILE=$2
	if [[ -z ${PACKAGE_TYPE} ]] || [[ -z ${INPUT_FILE} ]]
	then
		standard_error_handler 4 "- Invalid package input information"
	fi
	standard_output_handler "" cr
	standard_output_handler "ACTION_PACKAGE_INSTALL:" cr
	standard_output_handler "- ${PACKAGE_TYPE}" cr
	#------------------------------------------------
	# Check if IMCL is available
	#
	if [[ ! -x ${IMCL} ]]
	then
		standard_error_handler 5 "IBM Installation Manager not installed.  Please install IM first and try again."
	fi
	#------------------------------------------------
	# Retrieve input file and check if valid non-zero content
	#
	standard_output_handler "- Retrieving input file from ${TD_REPOSITORY_HOME}/input_files/${INPUT_FILE}..." nocr
	commander "cd ${WAS_UPDATES_HOME};wget -q ${TD_REPOSITORY_HOME}/input_files/${INPUT_FILE}" "wget package installation media"
	if [[ ! -s ${WAS_UPDATES_HOME}/${INPUT_FILE} ]]
	then
		standard_error_handler 6 "Input file ${WAS_UPDATES_HOME}/${INPUT_FILE} is invalid."
	fi
	standard_output_handler "Done." cr
	#------------------------------------------------
	# Check if the package type is already installed and get version number (set to 0 if not installed)
	#
	INSTALLED_PACKAGES=$(commander "${IMCL} listInstalledPackages" "IMCL list packages")
	INSTALLED_VERSION=0
	for INSTALLED_PACKAGE in ${INSTALLED_PACKAGES}
	do
		FIND=$(echo ${INSTALLED_PACKAGE} | grep ^${PACKAGE_TYPE})
		if [[ $? -eq 0 ]]
		then
			INSTALLED_VERSION=$(echo ${INSTALLED_PACKAGE} | cut -f2- -d_ | tr -d "_.")
			break
		fi
	done
	if [[ -z ${INSTALLED_VERSION} ]]
	then
		INSTALLED_VERSION=0
	fi
	#------------------------------------------------
	# Check for new version - this loop is needed if multiple versions are in the input file
	#
	NEW_PACKAGE_VERSIONS=$(cat < ${WAS_UPDATES_HOME}/${INPUT_FILE} | grep offering | grep ${PACKAGE_TYPE} | sed -e 's/.*version=\(.*\) features.*/\1/g' | tr -d "_.'")
	NEW_VERSION=0
	for NEW_PACKAGE_VERSION in ${NEW_PACKAGE_VERSIONS}
	do
		if [[ ${NEW_PACKAGE_VERSION} -ge ${NEW_VERSION} ]]
		then
			NEW_VERSION=${NEW_PACKAGE_VERSION}
			break
		fi
	done
	if [[ ${INSTALLED_VERSION} -lt ${NEW_VERSION} ]]
	then
		standard_output_handler "- Package ${PACKAGE_TYPE} installation required." cr
		#------------------------------------------------
		# Remove lost+founds
		#
		if [[ ${PACKAGE_TYPE} == ${IHS_PACKAGE_PATTERN} && -d ${IHS_HOME}/lost+found ]]
		then
			standard_output_handler "- Removing IHS lost+found directory..." nocr
			commander "rm -fr ${IHS_HOME}/lost+found" "Remove IHS HOME Lost and Found"
			standard_output_handler "Done." cr
		elif [[ ${PACKAGE_TYPE} == ${PLG_PACKAGE_PATTERN} && -d $(dirname ${PLG_HOME})/lost+found ]]
		then
			standard_output_handler "- Removing PLG lost+found directory..." nocr
			commander "rm -fr $(dirname ${PLG_HOME})/lost+found" "Remove PLG HOME Lost and Found"
			standard_output_handler "Done." cr
		elif [[ ${PACKAGE_TYPE} == ${WAS_PACKAGE_PATTERN} && -d $(dirname ${WAS_HOME})/lost+found ]]
		then
			standard_output_handler "- Removing WAS lost+found directory..." nocr
			commander "rm -fr $(dirname ${WAS_HOME})/lost+found" "Remove WAS HOME Lost and Found"
			standard_output_handler "Done." cr
		fi
		#------------------------------------------------
		# Install new package
		#
		if [[ ${PACKAGE_TYPE} == ${IHS_PACKAGE_PATTERN} ]]
		then
			IMCL_VARIABLES="im_shared_home=${IM_SHARED_HOME},td_repository_home=${TD_REPOSITORY_HOME},ihs_home=${IHS_HOME}"
		elif [[ ${PACKAGE_TYPE} == ${PLG_PACKAGE_PATTERN} ]]
		then
			IMCL_VARIABLES="im_shared_home=${IM_SHARED_HOME},td_repository_home=${TD_REPOSITORY_HOME},plugin_home=${PLG_HOME}"
		elif [[ ${PACKAGE_TYPE} == ${WAS_PACKAGE_PATTERN} ]]
		then
			IMCL_VARIABLES="im_shared_home=${IM_SHARED_HOME},td_repository_home=${TD_REPOSITORY_HOME},was_home=${WAS_HOME}"
		fi
		standard_output_handler "- Installing ${PACKAGE_TYPE}..." cr
		commander "${IMCL} \
			-acceptLicense \
			-input ${WAS_UPDATES_HOME}/${INPUT_FILE} \
			-variables ${IMCL_VARIABLES}" \
			"Install package"
		#------------------------------------------------
		# Set STATE VARIABLE
		#
		export $(echo STATE_package_${PACKAGE_TYPE} | tr '.' '_')=installed
	else
		standard_output_handler "- Package already at or above desired version or is not required.  Skipping installation." cr
	fi
	#------------------------------------------------
	# Remove input file
	#
	if [[ -f ${WAS_UPDATES_HOME}/${INPUT_FILE} ]]
	then
		standard_output_handler "- Removing input file..." nocr
		commander "rm -f ${WAS_UPDATES_HOME}/${INPUT_FILE}" "Remove input file"
		standard_output_handler "Done." cr
	fi
	}


#------------------------------------------------
# package uninstaller function
#
function uninstall_package {
	#set -x
	PACKAGE_TYPE=$1
	standard_output_handler "" cr
	standard_output_handler "ACTION_PACKAGE_UNINSTALL:" cr
	standard_output_handler "- ${PACKAGE_TYPE}" cr
	if [[ -z ${PACKAGE_TYPE} ]]
	then
		standard_error_handler 4 "Invalid package information or not defined for this version of WAS"
	fi
	#------------------------------------------------
	# Check if IMCL is available
	#
	if [[ ! -x ${IMCL} ]]
	then
		standard_error_handler 5 "IBM Installation Manager not installed.  Please install IM first and try again."
	fi
	#------------------------------------------------
	# Check if installed first
	# TO DO - how to handle state??
	#
	if [[ ${PACKAGE_TYPE} != "ALL" ]]
	then
		standard_output_handler "- Checking IBM Installation Manager..." nocr
		PACKAGE_INSTALLED=$(commander "${IMCL} listInstalledPackages" "IMCL list installed packages" | grep ${PACKAGE_TYPE})
		if [[ $? -ne 0 ]]
		then
			standard_output_handler "package ${PACKAGE_TYPE} is not installed." cr
			return
		else
			standard_output_handler "package ${PACKAGE_TYPE} is installed." cr
		fi
	fi
	#------------------------------------------------
	# uninstall component(s)
	# TO DO - make more robust
	#
	if [[ ${PACKAGE_TYPE} == "ALL" ]]
	then
		standard_output_handler "- Uninstalling all software components installed by IBM Installation Manager..." cr
		commander "${IMCL} uninstallAll" "IMCL uninstall all" "IMCL uninstall all"
		if [[ $? -eq 0 ]]
		then
			standard_output_handler "Done." cr
			delete_files WAS
			delete_files IHS
			delete_files PLG
		else
			standard_error_handler 6 "Error encountered during IMCL package uninstallation."
		fi
	else
		standard_output_handler "- Uninstalling ${PACKAGE_TYPE}..." cr
		commander "${IMCL} uninstall ${PACKAGE_TYPE}" "IMCL uninstall package"
		if [[ $? -eq 0 ]]
		then
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export $( echo STATE_package_${PACKAGE_TYPE} | tr '.' '_')=uninstalled
		else
			standard_error_handler 6 "Error encountered during IMCL package uninstallation."
		fi
	fi
	}


#------------------------------------------------
# Install td libs
# TO DO - fix symlink issue in tar file expansion
#
function install_td_libs {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_TD_LIBS_INSTALL:" cr
	standard_output_handler "- Installing TD drivers and libraries..." nocr
	commander "wget -q ${TD_REPOSITORY_HOME}/source_media/tdlib.tar -O - | tar -xf - -C ${TD_LIB_HOME} 2>/dev/null" "wget TD libs"
	standard_output_handler "Done." cr
	#------------------------------------------------
	# Set STATE VARIABLE
	#
	export STATE_td_libs=installed
	#set +x
	}


#------------------------------------------------
# Install WAS Control
#
function install_was_control {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_CONTROL_INSTALL:" cr
	standard_output_handler "- Retrieving WAS Control from ${TD_REPOSITORY_HOME}/source_files/wascontrol.tar..." nocr
	commander "wget -q ${TD_REPOSITORY_WAS_CONTROL_HOME}/source_media/wascontrol.tar -O - | tar -xf - -C ${TD_MGMT_MW_HOME} 2>/dev/null" "wget WAS Control"
	if [[ ! -d $(dirname ${WAS_CONTROL_WRAPPER}) ]]
	then
		mkdir -p $(dirname ${WAS_CONTROL_WRAPPER})
		if [[ ${WHOAMI} == "root" ]]
		then
			chown wasadm.wasadm $(dirname ${WAS_CONTROL_WRAPPER})
		fi
	fi
	cat < /dev/null > ${WAS_CONTROL_WRAPPER}
	echo "sudo su - wasadm \"-c ${WAS_CONTROL_HOME}/bin/was_control.sh \\" >> ${WAS_CONTROL_WRAPPER}
	echo "-was_platform distributed \\" >> ${WAS_CONTROL_WRAPPER}
	echo "-was_location ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME} \\" >> ${WAS_CONTROL_WRAPPER}
	echo "-was_version ${WAS_VERSION} \\" >> ${WAS_CONTROL_WRAPPER}
	echo "-host localhost \\" >> ${WAS_CONTROL_WRAPPER}
	echo "-port ${DMGR_SOAP_PORT} \\" >> ${WAS_CONTROL_WRAPPER}
	echo "\$*\"" >> ${WAS_CONTROL_WRAPPER}
	if [[ ${WHOAMI} == "root" ]]
	then
		chown wasadm.wasadm ${WAS_CONTROL_WRAPPER}
	fi
	chmod 755 ${WAS_CONTROL_WRAPPER}
	standard_output_handler "Done." cr
	WAS_CONTROL_VERSION=$(commander "${WAS_CONTROL_HOME}/bin/was_control.sh version" "WAS Control version" | awk '{print $3}')
	standard_output_handler "- WAS_Control version ${WAS_CONTROL_VERSION} installed." cr
	export STATE_was_control=${WAS_CONTROL_VERSION}
	echo
	}


#------------------------------------------------
# create dmgr profile
#
function create_dmgr_profile {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_CREATE_DMGR_PROFILE:" cr
	if [[ -x ${WAS_BIN_HOME}/manageprofiles.sh ]]
	then
		#------------------------------------------------
		# Check if DMGR profile already created
		#
		DMGR_PROFILE_EXISTS=$(commander "${WAS_BIN_HOME}/manageprofiles.sh -listProfiles" "list profiles" | grep _CellManager)
		if [[ $? -ne 0 ]]
		then
			#------------------------------------------------
			# Create dmgr profile
			# TO DO - Use following URL for explanation of all manageprofiles options:
			# http://www-01.ibm.com/support/knowledgecenter/SSWLGF_8.0.0/com.ibm.sr.doc/rwsr_manageprofiles_parms_dp.html
			#
			standard_output_handler "- Creating Deployment Manager profile..." cr
			commander "${WAS_BIN_HOME}/manageprofiles.sh -create \
				-templatePath ${WAS_PROFILE_TEMPLATES_HOME}/management \
				-profileName ${DMGR_PROFILE_NAME} \
				-profilePath ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME} \
				-isDefault true \
				-startingPort ${WAS_STARTING_PORT} \
				-cellName ${WAS_CELL_NAME} \
				-nodeName ${DMGR_NODE_NAME} \
				-hostName ${DMGR_HOST_NAME} \
				-personalCertValidityPeriod 15 \
				-personalCertDN \"CN=${DMGR_NODE_NAME},OU=ITS,O=TD Bank Group,L=Toronto,ST=ON,C=CA\" \
				-signingCertValidityPeriod 25 \
				-signingCertDN \"CN=${WAS_CELL_NAME} Root,OU=ITS,O=TD Bank Group,L=Toronto,ST=ON,C=CA\"" \
				"Create DMGR profile"
			chmod 700 ${WAS_PROFILE_HOME}
			standard_output_handler "Done." cr
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_dmgr=profile_created
		else
			SALT_MESSAGE="Deployment Manager profile already exists."
			standard_output_handler "- Deployment Manager profile already exists." cr
		fi
	else
		standard_error_handler 2 "WAS not installed."
	fi
	#set +x
	}


#------------------------------------------------
# Delete DMGR profile
#
function delete_dmgr_profile {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_DELETE_DMGR_PROFILE:" cr
	if [[ -x ${WAS_BIN_HOME}/manageprofiles.sh ]]
	then
		#------------------------------------------------
		# Check if DMGR profile already created
		#
		DMGR_PROFILE_EXISTS=$(commander "${WAS_BIN_HOME}/manageprofiles.sh -listProfiles" "list profiles" | grep _CellManager)
		if [[ $? -eq 0 ]]
		then
			DMGR_PROFILE_PATH=$(commander "${WAS_BIN_HOME}/manageprofiles.sh -getPath -profileName ${DMGR_PROFILE_NAME}" "get profile path")
			standard_output_handler "- Deleting Deployment Manager profile..." cr
			su - wasadm "-c ${WAS_BIN_HOME}/manageprofiles.sh -delete -profileName ${DMGR_PROFILE_NAME}" 1>/dev/null 2>/dev/null
			if [[ -d ${DMGR_PROFILE_PATH} ]]
			then
				commander "rm -fr ${DMGR_PROFILE_PATH}" "Remove profile directory"
			fi
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_dmgr=profile_deleted
		else
			SALT_MESSAGE="Deployment Manager profile does not exist."
			standard_output_handler "- Deployment Manager profile does not exist." cr
		fi
	else
		SALT_MESSAGE="WAS not installed."
		standard_output_handler "- WAS not installed." cr
	fi
	#set +x
	}


#------------------------------------------------
# Create service if running in Linux
# TO DO - handle error when creating service
#
function create_dmgr_service {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_CREATE_DMGR_SERVICE:" cr
	if [[ ${OS} == "Linux" && ${WHOAMI} == "root" ]]
	then
		#------------------------------------------------
		# Check if DMGR profile exists
		#
		DMGR_PROFILE_EXISTS=$(commander "${WAS_BIN_HOME}/manageprofiles.sh -listProfiles" "list profiles" | grep _CellManager)
                if [[ $? -ne 0 ]]
		then
			standard_error_handler 11 "Deployment Manager profile does not exist."
		fi
		#------------------------------------------------
		# Check if DMGR service already created
		#
		DMGR_SERVICE=$(chkconfig --list websphere_dmgr_was.init 1>/dev/null 2>/dev/null)
		if [[ $? -ne 0 ]]
		then
			standard_output_handler "- Creating Deployment Manager service..." cr
			${WAS_BIN_HOME}/wasservice.sh \
				-add websphere_dmgr \
				-serverName dmgr \
				-profilePath ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME} \
				-userid wasadm \
				1>/dev/null 2>/dev/null
			if [[ $? -eq 0 ]]
			then
				#------------------------------------------------
				# Alter profile file ownership
				#
				standard_output_handler "- Updating Deployment Manager profile file ownership..." nocr
				if [[ ${WHOAMI} == "root" ]]
				then
					chown -R wasadm.wasadm ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME}
				fi
				standard_output_handler "Done." cr
				#------------------------------------------------
				# Set STATE VARIABLE
				#
				export STATE_was_dmgr=service_created
			fi
		else
			SALT_MESSAGE="Linux service for Deployment Manager already exists."
			standard_output_handler "- Linux service for Deployment Manager already exists." cr
		fi
	elif [[ ${OS} == "AIX" ]]
	then
		standard_output_handler "- AIX WAS services not supported at this time." cr
	else
		standard_output_handler "- Non root user cannot create service" cr
	fi
	set +x
	}


#------------------------------------------------
# Delete service if running in Linux
# TO DO - delete profile folder
#
function delete_dmgr_service {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_DELETE_DMGR_SERVICE:" cr
	if [[ ${OS} == "Linux" && ${WHOAMI} == "root" ]]
	then
		#------------------------------------------------
		# Check if DMGR service already created
		#
		DMGR_SERVICE=$(chkconfig --list websphere_dmgr_was.init 1>/dev/null 2>/dev/null)
		if [[ $? -eq 0 ]]
		then
			standard_output_handler "- Deleting Deployment Manager service..." nocr
			${WAS_BIN_HOME}/wasservice.sh \
				-remove websphere_dmgr \
				1>/dev/null 2>/dev/null
			standard_output_handler "Done." cr
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_dmgr=service_deleted
		else
			SALT_MESSAGE="Linux service for Deployment Manager does not exist."
			standard_output_handler "- Linux service for Deployment Manager does not exist." cr
		fi
	elif [[ ${OS} == "AIX" ]]
	then
		standard_output_handler "- AIX WAS services not supported at this time." cr
	fi
	}


#------------------------------------------------
# Start Deployment Manager
# TO DO - handle error if service cannot be started
#
function start_dmgr {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_START_DMGR:" cr
	DMGR_PROCESS=$(ps -fu wasadm | grep ${WAS_HOME} | grep dmgr | grep -v grep)
	if [[ $? -ne 0 ]]
	then
		standard_output_handler "- Starting Deployment Manager..." cr
		if [[ ${OS} == "Linux" && ${WHOAMI} == "root" ]]
		then
			DMGR_SERVICE=$(chkconfig --list websphere_dmgr_was.init 1>/dev/null 2>/dev/null)
			if [[ $? -eq 0 ]]
			then
				service websphere_dmgr_was.init start 1>/dev/null 2>/dev/null
			else
				commander "${WAS_BIN_HOME}/startManager.sh" "Start DMGR"
			fi
		else
			commander "${WAS_BIN_HOME}/startManager.sh" "Start DMGR"
		fi
		if [[ $? -eq 0 ]]
		then
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_dmgr=started
		else
			standard_error_handler 3 "Issue starting Deployment Manager."
		fi
	else
		standard_output_handler "- Deployment Manager already started." cr
	fi
	}


#------------------------------------------------
# Stop Deployment Manager
# TO DO - handle if error when stopping Linux service and if service exists
#
function stop_dmgr {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_STOP_DMGR:" cr
	DMGR_PROCESS=$(ps -fu wasadm | grep ${WAS_HOME} | grep dmgr | grep -v grep | awk '{print $2}')
	if [[ -n ${DMGR_PROCESS} ]]
	then
		standard_output_handler "- Stopping Deployment Manager..." nocr
		if [[ ${OS} == "Linux" && ${WHOAMI} == "root" ]]
		then
			DMGR_SERVICE=$(chkconfig --list websphere_dmgr_was.init 1>/dev/null 2>/dev/null)
			if [[ $? -eq 0 ]]
			then
				# MAJOR TO DO - handle stop of services when WAS security is enabled"
				#service websphere_dmgr_was.init stop 1>/dev/null 2>/dev/null
				commander "kill -9 ${DMGR_PROCESS}" "Kill -9"
			else
				commander "kill -9 ${DMGR_PROCESS}" "Kill -9"
			fi
		else
			commander "kill -9 ${DMGR_PROCESS}" "Kill -9"
		fi
		if [[ $? -eq 0 ]]
		then
			standard_output_handler "Done." cr
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_dmgr=stopped
		else
			standard_error_handler 3 "Issue stopping Deployment Manager."
		fi
	else
		SALT_MESSAGE="Deployment Manager already stopped."
		standard_output_handler "- Deployment Manager already stopped." cr
	fi
	}


#------------------------------------------------
# create managed node profile
#
function create_managed_node_profile {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_CREATE_MANAGED_NODE_PROFILE:" cr
	if [[ -x ${WAS_BIN_HOME}/manageprofiles.sh ]]
	then
		#------------------------------------------------
		# Check if NODE already created
		#
		NODE_EXISTS=$(commander "${WAS_BIN_HOME}/manageprofiles.sh -listProfiles" "List profiles" | grep _node)
		if [[ $? -ne 0 ]]
		then
			#------------------------------------------------
			# Create nodeagent profile
			#
			standard_output_handler "- Creating Managed Node profile..." cr
			commander "${WAS_BIN_HOME}/manageprofiles.sh -create \
				-templatePath ${WAS_PROFILE_TEMPLATES_HOME}/managed \
				-profileName ${MANAGED_PROFILE_NAME} \
				-profilePath ${WAS_PROFILE_HOME}/${MANAGED_PROFILE_NAME} \
				-nodeName ${MANAGED_NODE_NAME} \
				-hostName ${MANAGED_HOST_NAME} \
				-personalCertValidityPeriod 15 \
				-personalCertDN \"CN=${MANAGED_NODE_NAME},OU=ITS,O=TD Bank Group,L=Toronto,ST=ON,C=CA\" \
				-signingCertValidityPeriod 25 \
				-signingCertDN \"CN=${MANAGED_NODE_NAME} Root,OU=ITS,O=TD Bank Group,L=Toronto,ST=ON,C=CA\"" \
				"Create Managed node"
			chmod 700 ${WAS_PROFILE_HOME}
			standard_output_handler "Done." cr
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_managed_node=profile_created
		else
			standard_output_handler "- Node Agent profile already exists." cr
		fi
	else
		standard_error_handler 2 "WAS not installed."
	fi
	}


#------------------------------------------------
# Delete MANAGED NODE profile
# TO DO - complete function
#
function delete_managed_node_profile {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_DELETE_MANAGED_NODE_PROFILE:" cr
	if [[ -x ${WAS_BIN_HOME}/manageprofiles.sh ]]
	then
		#------------------------------------------------
		# Check if MANAGED NODE profile already created
		#
		MANAGED_NODE_PROFILE_EXISTS=$(commander "${WAS_BIN_HOME}/manageprofiles.sh -listProfiles" "list profiles" | grep _node)
		if [[ $? -eq 0 ]]
		then
			MANAGED_NODE_PROFILE_PATH=$(commander "${WAS_BIN_HOME}/manageprofiles.sh -getPath -profileName ${MANAGED_PROFILE_NAME}" "get profile path")
			standard_output_handler "- Deleting Node Agent profile..." cr
			su - wasadm "-c ${WAS_BIN_HOME}/manageprofiles.sh -delete -profileName ${MANAGED_PROFILE_NAME}" 1>/dev/null 2>/dev/null
			if [[ -d ${MANAGED_NODE_PROFILE_PATH} ]]
			then
				commander "rm -fr ${MANAGED_NODE_PROFILE_PATH}" "Remove profile directory"
			fi
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_managed_node=profile_deleted
		else
			SALT_MESSAGE="Managed Node profile does not exist."
			standard_output_handler "- Managed Node profile does not exist." cr
		fi
	else
		SALT_MESSAGE="WAS not installed."
		standard_output_handler "- WAS not installed." cr
	fi
	#set +x
	}


#------------------------------------------------
# Create node agent service
# TO DO - handle error when creating service
#
function create_nodeagent_service {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_CREATE_NODEAGENT_SERVICE:" cr
	if [[ ${OS} == "Linux" && ${WHOAMI} == "root" ]]
	then
		#------------------------------------------------
		# Check if NODEAGENT service already created
		#
		NODEAGENT_SERVICE=$(chkconfig --list websphere_nodeagent_was.init 1>/dev/null 2>/dev/null)
		if [[ $? -ne 0 ]]
		then
			standard_output_handler "- Creating Node Agent service..." nocr
			${WAS_BIN_HOME}/wasservice.sh \
				-add websphere_nodeagent \
				-serverName nodeagent \
				-profilePath ${WAS_PROFILE_HOME}/${MANAGED_PROFILE_NAME} \
				-userid wasadm \
				1>/dev/null 2>/dev/null
			standard_output_handler "Done." cr
			#------------------------------------------------
			# Alter profile file ownership
			#
			standard_output_handler "- Updating Node Agent profile file ownership..." nocr
			if [[ ${WHOAMI} == "root" ]]
			then
				chown -R wasadm.wasadm ${WAS_PROFILE_HOME}/${MANAGED_PROFILE_NAME}
			fi
			standard_output_handler "Done." cr
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_managed_node=service_created
		else
			standard_output_handler "- Linux service for Node Agent already exists." cr
		fi
	elif [[ ${OS} == "AIX" ]]
	then
		standard_output_handler "- AIX WAS services not supported at this time." cr
	else
		standard_output_handler "- Non root user cannot create service" cr
	fi
	}


#------------------------------------------------
# Delete Node Agent service
# TO DO - handle error when creating service
#
function delete_nodeagent_service {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_DELETE_NODEAGENT_SERVICE:" cr
	if [[ ${OS} == "Linux" && ${WHOAMI} == "root" ]]
	then
		#------------------------------------------------
		# Check if NODEAGENT service already created
		#
		NODEAGENT_SERVICE=$(chkconfig --list websphere_nodeagent_was.init 1>/dev/null 2>/dev/null)
		if [[ $? -eq 0 ]]
		then
			standard_output_handler "- Deleting Node Agent service..." nocr
			${WAS_BIN_HOME}/wasservice.sh \
				-remove websphere_nodeagent \
				1>/dev/null 2>/dev/null
			standard_output_handler "Done." cr
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_managed_node=service_deleted
		else
			SALT_MESSAGE="Linux service for Node Agent does not exists."
			standard_output_handler "- Linux service for Node Agent does not exist." cr
		fi
	elif [[ ${OS} == "AIX" ]]
	then
		standard_output_handler "- AIX WAS service not supported at this time." cr
	fi
	}


#------------------------------------------------
# Federate Node Agent
#
function federate_node {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_FEDERATE_NODE:" cr
	MANAGED_NODE_PROFILE_PATH=$(commander "${WAS_BIN_HOME}/manageprofiles.sh -getPath -profileName ${MANAGED_PROFILE_NAME}" "get profile path")
	if [[ -d ${MANAGED_NODE_PROFILE_PATH}/config/cells/${WAS_CELL_NAME} ]]
	then
		standard_output_handler "- Node Agent already federated." cr
	else
		standard_output_handler "- Federating Node Agent to WAS Cell..." cr
		# TO DO - figure out why "line 1" error is occuring
		commander "${MANAGED_NODE_PROFILE_PATH}/bin/addNode.sh ${DMGR_HOST_NAME} ${DMGR_SOAP_PORT} \
			-startingport ${NODE_STARTING_PORT}" \
			"Add node"
		standard_output_handler "Done." cr
		standard_output_handler "- Sleeping for 60 seconds to allow cell to settle down..." nocr
		sleep 60
		standard_output_handler "Done." cr
		#------------------------------------------------
		# Set STATE VARIABLE
		#
		export STATE_was_managed_node=federated
	fi
	}


#------------------------------------------------
# remove node
# TO DO - use jython / WAS Control ro remove node
# TO DO - ensure there is tate support
#
function remove_node {
	#set -x
	NODE_NAME=$1
	}


#------------------------------------------------
# Start Node Agent
# TO DO - impm,ent log for cheking if nodeagent already running and insert service cmds here
#
function start_nodeagent {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_START_NODEAGENT:" cr
	NODEAGENT_PROCESS=$(ps -fu wasadm | grep ${WAS_HOME} | grep nodeagent | grep -v grep)
	if [[ $? -ne 0 ]]
	then
		standard_output_handler "- Starting Node Agent..." cr
		MANAGED_NODE_PROFILE_PATH=$(commander "${WAS_BIN_HOME}/manageprofiles.sh -getPath -profileName ${MANAGED_PROFILE_NAME}" "get profile path")
		if [[ ${OS} == "Linux" && ${WHOAMI} == "root" ]]
		then
			NODEAGENT_SERVICE=$(chkconfig --list websphere_nodeagent_was.init 1>/dev/null 2>/dev/null)
			if [[ $? -eq 0 ]]
			then
				service websphere_nodeagent_was.init start 1>/dev/null 2>/dev/null
			else
				commander "${MANAGED_NODE_PROFILE_PATH}/bin/startNode.sh" "Start Node"
			fi
		else
			commander "${MANAGED_NODE_PROFILE_PATH}/bin/startNode.sh" "Start Node"
		fi
		if [[ $? -eq 0 ]]
		then
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_managed_node=started
		else
			standard_error_handler 3 "Issue starting Node Agent."
		fi
	else
		standard_output_handler "- Node Agent already started." cr
	fi
	}


#------------------------------------------------
# Stop Node Agent
#
function stop_nodeagent {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_STOP_NODEAGENT:" cr
	NODEAGENT_PROCESS=$(ps -fu wasadm | grep ${WAS_HOME} | grep nodeagent | grep -v grep | awk '{print $2}')
	if [[ -n ${NODEAGENT_PROCESS} ]]
	then
		standard_output_handler "- Stopping Node Agent..." nocr
		if [[ ${OS} == "Linux" && ${WHOAMI} == "root" ]]
		then
			NODEAGENT_SERVICE=$(chkconfig --list websphere_nodeagent_was.init 1>/dev/null 2>/dev/null)
			if [[ $? -eq 0 ]]
			then
				# MAJOR TO DO - handle stop of services when WAS security is enabled"
				#service websphere_nodeagent_was.init stop 1>/dev/null 2>/dev/null
				commander "kill -9 ${NODEAGENT_PROCESS}" "Kill -9"
			else
				commander "kill -9 ${NODEAGENT_PROCESS}" "Kill -9"
			fi
		else
			commander "kill -9 ${NODEAGENT_PROCESS}" "Kill -9"
		fi
		if [[ $? -eq 0 ]]
		then
			standard_output_handler "Done." cr
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			SALT_MESSAGE="Node Agent stopped."
			export STATE_was_managed_node=stopped
		else
			standard_error_handler 3 "Issue stopping Node Agent."
		fi
	else
		SALT_MESSAGE="Node Agent already stopped."
		standard_output_handler "- Node Agent already stopped." cr
	fi
	}


#------------------------------------------------
# Create stand-alone profile
#
function create_stand_alone_profile {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_CREATE_STAND_ALONE_PROFILE:" cr
	if [[ -x ${WAS_BIN_HOME}/manageprofiles.sh ]]
	then
		#------------------------------------------------
		# Check if NODE profile already created
		#
		STAND_ALONE_EXISTS=$(commander "${WAS_BIN_HOME}/manageprofiles.sh -listProfiles" "List profiles" | grep _node)
		if [[ $? -ne 0 ]]
		then
			#------------------------------------------------
			# Create nodeagent profile
			#
			standard_output_handler "- Creating Stand Alone profile..." cr
			commander "${WAS_BIN_HOME}/manageprofiles.sh -create \
				-templatePath ${WAS_PROFILE_TEMPLATES_HOME}/default \
				-profileName ${MANAGED_PROFILE_NAME} \
				-profilePath ${WAS_PROFILE_HOME}/${MANAGED_PROFILE_NAME} \
				-nodeName ${MANAGED_NODE_NAME} \
				-hostName ${MANAGED_HOST_NAME} \
				-personalCertValidityPeriod 15 \
				-personalCertDN \"CN=${MANAGED_NODE_NAME},OU=ITS,O=TD Bank Group,L=Toronto,ST=ON,C=CA\" \
				-signingCertValidityPeriod 25 \
				-signingCertDN \"CN=${MANAGED_NODE_NAME} Root,OU=ITS,O=TD Bank Group,L=Toronto,ST=ON,C=CA\"" \
				"Create Managed node"
			chmod 700 ${WAS_PROFILE_HOME}
			standard_output_handler "Done." cr
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_managed_node=profile_created
		else
			standard_output_handler "- Stand Alone profile already exists." cr
		fi
	else
		standard_error_handler 2 "WAS not installed."
	fi
	}


#------------------------------------------------
# Start server1 (stand alone profile)
#
function start_server1 {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_START_SERVER1" cr
	SERVER1_PROCESS=$(ps -fu wasadm | grep ${WAS_HOME} | grep server1 | grep -v grep)
	if [[ $? -ne 0 ]]
	then
		standard_output_handler "- Starting server1..." cr
		STAND_ALONE_PROFILE_PATH=$(commander "${WAS_BIN_HOME}/manageprofiles.sh -getPath -profileName ${MANAGED_PROFILE_NAME}" "get profile path")
		commander "${STAND_ALONE_PROFILE_PATH}/bin/startServer.sh server1" "Start server1"
		if [[ $? -eq 0 ]]
		then
			#------------------------------------------------
			# Set STATE VARIABLE
			#
			export STATE_was_managed_node=started
		else
			standard_error_handler 3 "Issue starting server1."
		fi
	else
		standard_output_handler "- server1 already started." cr
	fi
	}


#------------------------------------------------
# Add Managed (Node Agent) Node
#
function add_managed_node {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_ADD_MANAGED_NODE:" cr
	standard_output_handler "-       Managed Node Host Name: ${MANAGED_HOST_NAME}" cr
	standard_output_handler "-        Managed Node JMX Port: ${MANAGED_JMX_PORT}" cr
	standard_output_handler "-            Managed Node Name: ${MANAGED_NODE_NAME}" cr
	standard_output_handler "-   Managed Node Starting Port: ${NODE_STARTING_PORT}" cr
	standard_output_handler "- Deployment Manager Host Name: ${DMGR_HOST_NAME}" cr
	standard_output_handler "- Deployment Manager SOAP Port: ${DMGR_SOAP_PORT}" cr
	#------------------------------------------------
	# ensure that WAS is installaed and profile is available
	#
	if [[ ! -x ${WAS_BIN_HOME}/wsadmin.sh ]]
	then
		standard_error_handler 6 "WAS binaries not installed."
	fi
	if [[ ! -d ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME}/config/cells/${WAS_CELL_NAME}/nodes/${MANAGED_NODE_NAME} ]]
	then
		commander "${WAS_HOME}/bin/wsadmin.sh \
			-host ${MANAGED_HOST_NAME} \
			-port ${MANAGED_JMX_PORT} \
			-f ${WAS_CONTROL_HOME}/jython/add_managed_node.py ${DMGR_HOST_NAME} ${DMGR_SOAP_PORT} ${NODE_STARTING_PORT}" \
			"WSAdmin"
		MAX_ADD_NODE_WAIT_TIME=120
		WAIT_TIME=0
		while [[ $(grep ASND0002I ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME}/logs/dmgr/SystemOut.log | grep ${MANAGED_NODE_NAME}) == "" ]]
		do
			echo "Waiting for 'Node started' message..."
			sleep 5
			WAIT_TIME=$((${WAIT_TIME}+5))
			if [[ ${WAIT_TIME} -gt ${MAX_ADD_NODE_WAIT_TIME} ]]
			then
				standard_error_handler 20 "Add Node command took longer than ${MAX_ADD_NODE_WAIT_TIME}"
			fi
		done
		#------------------------------------------------
		# Set STATE VARIABLE
		#
		export STATE_was_managed_node=added
	else
		SALT_MESSAGE="Managed node already exists."
		standard_output_handler "- Managed node already exists." cr
	fi
	}


#------------------------------------------------
# Create IHS instance on file system
#
function create_ihs_admin_server {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_IHS_CREATE_ADMIN_SERVER:" cr
	cd ${IHS_HOME}/conf
	$(grep -q ${IHS_ADMIN_PORT} ${IHS_ADMIN_CONF})
	if [[ $? -ne 0 ]]
	then
		standard_output_handler "- Creating/Configurring IHS Admin Server..." nocr
		cat < ${IHS_ADMIN_CONF}.default \
			| sed -e 's/\(\(^Listen\) .*\)/#\1\n\2 '${IHS_ADMIN_PORT}'/g' \
			| sed -e 's/\(^   AuthName .*\)/#\1/g' \
			| sed -e 's/\(^   AuthType .*\)/#\1/g' \
			| sed -e 's/\(^   AuthBasicProvider .*\)/#\1/g' \
			| sed -e 's/\(^   AuthUserFile .*\)/#\1/g' \
			| sed -e 's/\(^   require valid-user\)/#\1/g' \
			| sed -e 's/\(\(^LogLevel\) .*\)/#\1\n\2 debug/g' \
			| sed -e 's/\(\(^ErrorLog\) logs\(\/admin_error_log\)\)/#\1\n\2 '$(escape_slashes ${IHS_LOG_HOME})'\3/g' \
			| sed -e 's/\(\(^CustomLog\) logs\(\/admin_access_log .*\)\)/#\1\n\2 '$(escape_slashes ${IHS_LOG_HOME})'\3/g' \
			| sed -e 's/\(\(^ServerName\) \(.*\:\).*\)/#\1\n\2 \3'${IHS_ADMIN_PORT}'/g' \
			> ${IHS_ADMIN_CONF}
			standard_output_handler "Done." cr
		SALT_MESSAGE="IHS Admin Server configured."
		export STATE_ihs_admin_server=configured
	fi
	SALT_MESSAGE="IHS Admin Server already configured"
	}


#------------------------------------------------
# Create IHS instance on file system
#
function start_ihs_admin_server {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_IHS_START_ADMIN_SERVER:" cr
	if [[ ${WHOAMI} == "root" ]]
	then
		standard_output_handler "Starting IHS Admin Server..." cr
		chown wasadm.wasadm ${IHS_HOME}/conf/${IHS_ADMIN_CONF}
		${IHS_HOME}/bin/adminctl restart
		standard_output_handler "Done." cr
		SALT_MESSAGE="IHS Admin Server started."
		export STATE_ihs_admin_server=started
	else
		standard_output_handler "Need to be ROOT user to start IHS Admin Server." cr
	fi
	standard_output_handler "" cr
	}


#------------------------------------------------
# Create IHS instance on file system
#
function create_ihs_instance {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_IHS_CREATE_INSTANCE:" cr
	standard_output_handler "- Instance Name = ${IHS_INSTANCE_NAME}." cr
	if [[ ! -f ${IHS_HOME}/conf/${IHS_INSTANCE_NAME}_httpd.conf ]]
	then
		if [[ ${DUMP_HOME}/${IHS_INSTANCE_NAME} ]]
		then
			mkdir -p ${DUMP_HOME}/${IHS_INSTANCE_NAME}
		fi
		cd ${IHS_HOME}/conf
		cat < httpd.conf.default \
			| sed -e 's/\(\(^PidFile\) .*\)/#\1\n\2 logs\/'${IHS_INSTANCE_NAME}'.pid/g' \
			| sed -e 's/\(\(^Timeout\) .*\)/#\1\n\2 3/g' \
			| sed -e 's/\(^ThreadLimit .*\)/#\1/g' \
			| sed -e 's/\(^ServerLimit .*\)/#\1/g' \
			| sed -e 's/\(^StartServers .*\)/#\1/g' \
			| sed -e 's/\(^MaxClients .*\)/#\1/g' \
			| sed -e 's/\(^MinSpareThreads .*\)/#\1/g' \
			| sed -e 's/\(^MaxSpareThreads .*\)/#\1/g' \
			| sed -e 's/\(^ThreadsPerChild .*\)/#\1/g' \
			| sed -e 's/\(^MaxRequestsPerChild .*\)/#\1\n\tThreadLimit\t\t500\n\tServerLimit\t\t2\n\tStartServers\t\t2\n\tMaxClients\t\t1000\n\tMinSpareThreads\t\t1000\n\tMaxSpareThreads\t\t1000\n\tThreadsPerChild\t\t500\n\tMaxRequestsPerChild\t0/g' \
			| sed -e 's/\(^Listen 80\)/#\1/g' \
			| sed -e 's/\(^LoadModule status_module.*\)/#\1/g' \
			| sed -e 's/\(\(^ErrorLog\) logs\/error_log\)/#\1\n\2 '$(escape_slashes ${IHS_LOG_HOME})'\/'${IHS_INSTANCE_NAME}'_error_log/g' \
			| sed -e 's/\(^LogFormat.*agent\)/\1\n\n\n#------------------------------------------------------------\n# TDBG logging formats\n#\nLogFormat \"\%h \%l \%u \%t \\\"\%r\\\" \%>s \%b \\\"\%\{Referer\}i\\\" \\\"\%\{User-Agent\}i\\\" \\\"\%\{Cookie}i\\\"\" extended\nLogFormat \"\%h \%l \%u \%t \\\"\%r\\\" \%>s \%b \%D\" perf\nLogFormat \"\%h \%l \%u \%t \%\{SSL_CIPHER\}e \%\{SSL_CIPHER_USEKEYSIZE\}e \%\{SSL_PROTOCOL\}e \\\"\%r\\\" \%>s \%b\" cipher\nSetEnvIf X-Forwarded-For \^\$ not_forwarded\nLogFormat \"\%\{X-Forwarded-For\}i \%l \%u \%t \\\"\%r\\\" \%>s \%b\" x_forwarded_for_common\nLogFormat \"\%\{X-Forwarded-For\}i \%l \%u \%t \\\"\%r\\\" \%>s \%b \\\"\%\{Referer\}i\\\" \\\"\%\{User-Agent\}i\\\" \\\"\%\{Cookie\}i\\\"\" x_forwarded_for_extended\n/g' \
			| sed -e 's/\(\(^Group\) .*\)/#\1\n\2 wasadm/g' \
			| sed -e 's/\(\(^CustomLog\) logs\/access_log \(.*\)\)/#\1\n\2 '$(escape_slashes ${IHS_LOG_HOME})'\/'${IHS_INSTANCE_NAME}'_access_log \3/g' \
			| sed -e 's/\(^#\(AddServerHeader Off\)\)/\1\n\2/g' \
			| sed -e 's/\(\(^ServerSignature\) .*\)/#\1\n\2 Off/g' \
			| sed -e 's/\(^#\(CoreDumpDirectory\) .*\)/\1\n\2 '$(escape_slashes ${DUMP_HOME})'\/'${IHS_INSTANCE_NAME}'/g' \
			| sed -e 's/\(\(^ReportInterval\) .*\)/#\1\n\2 60/g' \
			> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "#-------------------------------------" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "# WebSphere PLG Config" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "#" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "LoadModule was_ap22_module ${PLG_HOME}/bin/64bits/mod_was_ap22_http.so" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "WebSpherePluginConfig ${PLG_HOME}/config/${IHS_INSTANCE_NAME}/plugin-cfg.xml" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "#-------------------------------------" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "# Global SSL Config" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "#" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "LoadModule ibm_ssl_module modules/mod_ibm_ssl.so" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "SSLDisable" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "KeyFile ${APPLICATION_HOME}/config/ssl/${IHS_INSTANCE_NAME}.kdb" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "SSLCacheEnable" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "SSLCachePortFileName ${IHS_LOG_HOME}/${IHS_INSTANCE_NAME}_siddfile" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "SSLV3Timeout 100" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "#-------------------------------------" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "# Load TD virtual host configuration files" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "#" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "Include conf/${IHS_INSTANCE_NAME}_vhosts/*.conf" >> ${IHS_INSTANCE_NAME}_httpd.conf
		echo "" >> ${IHS_INSTANCE_NAME}_httpd.conf
		if [[ ${PLG_HOME}/config/${IHS_INSTANCE_NAME} ]]
		then
			mkdir -p ${PLG_HOME}/config/${IHS_INSTANCE_NAME}
		fi
		if [[ ${WHOAMI} == "root" ]]
		then
			chown wasadm.wasadm ${IHS_INSTANCE_NAME}_httpd.conf
			chown wasadm.wasadm ${PLG_HOME}/config/${IHS_INSTANCE_NAME}
		fi
		KEY_PASS=$(echo ${RANDOM}${RANDOM}${RANDOM})
		if [[ ! -d ${APPLICATION_HOME}/config/ssl ]]
		then
			mkdir -p ${APPLICATION_HOME}/config/ssl
		fi
		if [[ ${WHOAMI} == "root" ]]
		then
			chown -R wasadm.wasadm ${APPLICATION_HOME}
		fi
		${IHS_HOME}/bin/gskcmd -keydb -create -db ${APPLICATION_HOME}/config/ssl/${IHS_INSTANCE_NAME}.kdb -pw ${KEY_PASS} -type kdb -expire 7300 -stash -populate
		SAN_HOST=$(hostname | sed -e 's/dev/dynamic/g')
		if [[ -n ${SAN_HOST} && ${LOCALHOST_LONG_NAME} != ${SAN_HOST} ]]
		then
			${IHS_HOME}/bin/gskcmd -cert -create -db ${APPLICATION_HOME}/config/ssl/${IHS_INSTANCE_NAME}.kdb -pw ${KEY_PASS} -type kdb -label ${LOCALHOST_LONG_NAME}_self -dn "CN=${LOCALHOST_LONG_NAME}, OU=ITS, O=TD Bank Group, L=Toronto, ST=ON, C=CA" -expire 7300 -size 2048 -default_cert yes -san_dnsname ${SAN_HOST}
		else
			${IHS_HOME}/bin/gskcmd -cert -create -db ${APPLICATION_HOME}/config/ssl/${IHS_INSTANCE_NAME}.kdb -pw ${KEY_PASS} -type kdb -label ${LOCALHOST_LONG_NAME}_self -dn "CN=${LOCALHOST_LONG_NAME}, OU=ITS, O=TD Bank Group, L=Toronto, ST=ON, C=CA" -expire 7300 -size 2048 -default_cert yes
		fi
		if [[ ! -d ${IHS_HOME}/conf/${IHS_INSTANCE_NAME}_vhosts ]]
		then
			cd ${IHS_HOME}/conf
			mkdir ${IHS_INSTANCE_NAME}_vhosts
			BOOTSTRAP_IP=$(hostname -i | awk '{print $1}')
			PORT80_HOST_FILE=${IHS_INSTANCE_NAME}_vhosts/${BOOTSTRAP_IP}_80.conf
			echo "Listen ${BOOTSTRAP_IP}:80" >> ${PORT80_HOST_FILE}
			echo "NameVirtualHost ${BOOTSTRAP_IP}:80" >> ${PORT80_HOST_FILE}
			echo "" >> ${PORT80_HOST_FILE}
			echo "<VirtualHost ${BOOTSTRAP_IP}:80>" >> ${PORT80_HOST_FILE}
			echo "  ServerName ${LOCALHOST_LONG_NAME}:80" >> ${PORT80_HOST_FILE}
			echo "  ErrorLog  \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_80_error_log 50M\"" >> ${PORT80_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_80_access_log 50M\" x_forwarded_for_common env=!not_forwarded" >> ${PORT80_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_80_direct_access_log 50M\" common env=not_forwarded" >> ${PORT80_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_80_perf_log 50M\" perf" >> ${PORT80_HOST_FILE}
			echo "</VirtualHost>" >> ${PORT80_HOST_FILE}
			echo "" >> ${PORT80_HOST_FILE}
			echo "<VirtualHost ${BOOTSTRAP_IP}:80>" >> ${PORT80_HOST_FILE}
			echo "  ServerName ${SAN_HOST}:80" >> ${PORT80_HOST_FILE}
			echo "  ErrorLog  \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_80_error_log 50M\"" >> ${PORT80_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_80_access_log 50M\" x_forwarded_for_common env=!not_forwarded" >> ${PORT80_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_80_direct_access_log 50M\" common env=not_forwarded" >> ${PORT80_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_80_perf_log 50M\" perf" >> ${PORT80_HOST_FILE}
			echo "</VirtualHost>" >> ${PORT80_HOST_FILE}
			PORT443_HOST_FILE=${IHS_INSTANCE_NAME}_vhosts/${BOOTSTRAP_IP}_443.conf
			echo "Listen ${BOOTSTRAP_IP}:443" >> ${PORT443_HOST_FILE}
			echo "NameVirtualHost ${BOOTSTRAP_IP}:443" >> ${PORT443_HOST_FILE}
			echo "" >> ${PORT443_HOST_FILE}
			echo "<VirtualHost ${BOOTSTRAP_IP}:443>" >> ${PORT443_HOST_FILE}
			echo "  ServerName ${LOCALHOST_LONG_NAME}:443" >> ${PORT443_HOST_FILE}
			echo "  ErrorLog  \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_443_error_log 50M\"" >> ${PORT443_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_443_access_log 50M\" x_forwarded_for_common env=!not_forwarded" >> ${PORT443_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_443_direct_access_log 50M\" common env=not_forwarded" >> ${PORT443_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${LOCALHOST_LONG_NAME}_443_perf_log 50M\" perf" >> ${PORT443_HOST_FILE}
			echo "  SSLServerCert ${LOCALHOST_LONG_NAME}_self" >> ${PORT443_HOST_FILE}
			echo "  Include conf/vh_ssl.conf" >> ${PORT443_HOST_FILE}
			echo "</VirtualHost>" >> ${PORT443_HOST_FILE}
			echo "" >> ${PORT443_HOST_FILE}
			echo "<VirtualHost ${BOOTSTRAP_IP}:443>" >> ${PORT443_HOST_FILE}
			echo "  ServerName ${SAN_HOST}:443" >> ${PORT443_HOST_FILE}
			echo "  ErrorLog  \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_443_error_log 50M\"" >> ${PORT443_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_443_access_log 50M\" x_forwarded_for_common env=!not_forwarded" >> ${PORT443_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_443_direct_access_log 50M\" common env=not_forwarded" >> ${PORT443_HOST_FILE}
			echo "  CustomLog \"| ${IHS_HOME}/bin/rotatelogs ${IHS_LOG_HOME}/${SAN_HOST}_443_perf_log 50M\" perf" >> ${PORT443_HOST_FILE}
			echo "  SSLServerCert ${LOCALHOST_LONG_NAME}_self" >> ${PORT443_HOST_FILE}
			echo "  Include conf/vh_ssl.conf" >> ${PORT443_HOST_FILE}
			echo "</VirtualHost>" >> ${PORT443_HOST_FILE}
			if [[ ${WHOAMI} == "root" ]]
			then
				chown -R wasadm.wasadm ${IHS_INSTANCE_NAME}_vhosts
			fi
			rm -f vh_ssl.conf
			commander "cd ${IHS_HOME}/conf;wget -q ${TD_REPOSITORY_HOME}/source_media/vh_ssl.conf 2>&1" "wget command SSL vhost config"
		fi
		#------------------------------------------------
		# Set STATE VARIABLE
		#
		export STATE_ihs=instance_created
	else
		SALT_MESSAGE="IHS instance already exists."
		standard_output_handler "- IHS instance already exists." cr
	fi
	#set +x
	}


#------------------------------------------------
# Add Unmanaged (Web Server) Node
#
function add_unmanaged_node {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_ADD_UNMANAGED_NODE:" cr
	standard_output_handler "- Node name: ${UNMANAGED_NODE_NAME}" cr
	standard_output_handler "- Host name: ${UNMANAGED_HOST_NAME}" cr
	standard_output_handler "-  O/S type: ${UNMANAGED_OS_TYPE}" cr
	#------------------------------------------------
	# ensure that WAS is installaed and profile is available
	#
	if [[ ! -x ${WAS_BIN_HOME}/wsadmin.sh ]]
	then
		standard_error_handler 6 "WAS binaries not installed."
	fi
	if [[ ! -d ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME}/config/cells/${WAS_CELL_NAME}/nodes/${UNMANAGED_NODE_NAME} ]]
	then
		run_was_control addUnmanagedNode "${UNMANAGED_NODE_NAME} ${UNMANAGED_HOST_NAME} ${UNMANAGED_OS_TYPE}"
		#------------------------------------------------
		# Set STATE VARIABLE
		#
		export STATE_was_unmanaged_node=added
	else
		SALT_MESSAGE="Unmanaged node already exists."
		standard_output_handler "- Unmanaged node already exists." cr
	fi
	}


#------------------------------------------------
# Add IHS instance to WAS console
#
function add_ihs_instance {
	#set -x
	if [[ -n ${BASIC_IHS_INSTANCE} ]]
	then
		IHS_INSTANCE_NAME=$(echo ${UNMANAGED_NODE_NAME} | sed -e 's/\(.*\)/ihs_\1/g' -e 's/\(.*\)_web/\1/g')
	fi
	standard_output_handler "" cr
	standard_output_handler "ACTION_IHS_ADD_INSTANCE:" cr
	standard_output_handler "- Adding IHS Instance to WAS Configuration = ${IHS_INSTANCE_NAME}." cr
	if [[ ! -d ${WAS_PROFILE_HOME}/${DMGR_PROFILE_NAME}/config/cells/${WAS_CELL_NAME}/nodes/${UNMANAGED_NODE_NAME}/servers/${IHS_INSTANCE_NAME} ]]
	then
		WAS_IHS_CONFIG_FILE=/tmp/${IHS_INSTANCE_NAME}.properties
		if [[ -f ${WAS_IHS_CONFIG_FILE} ]]
		then
			rm -f ${WAS_IHS_CONFIG_FILE}
		fi
		echo "WebServer.name=${IHS_INSTANCE_NAME}" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.node=${UNMANAGED_NODE_NAME}" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.webserverInstallRoot=${IHS_HOME}" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.pluginProperties.PluginInstallRoot=${PLG_HOME}" >> ${WAS_IHS_CONFIG_FILE}
		echo "" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.configurationFilename=${IHS_HOME}/conf/${IHS_INSTANCE_NAME}_httpd.conf" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.pluginProperties.LogFilename=${IHS_LOG_HOME}/${IHS_INSTANCE_NAME}_http_plugin.log" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.pluginProperties.PluginGeneration=AUTOMATIC" >> ${WAS_IHS_CONFIG_FILE}
		echo "WebServer.pluginProperties.PluginPropagation=AUTOMATIC" >> ${WAS_IHS_CONFIG_FILE}
		echo "" >> ${WAS_IHS_CONFIG_FILE}
		if [[ ${WHOAMI} == "root" ]]
		then
			chown wasadm.wasadm ${WAS_IHS_CONFIG_FILE}
		fi
		run_was_control createWebServer ${WAS_IHS_CONFIG_FILE}
		rm -f ${WAS_IHS_CONFIG_FILE}
		#------------------------------------------------
		# Set STATE VARIABLE
		#
		export STATE_ihs=instance_added
	else
		SALT_MESSAGE="IHS instance already configured in WAS."
		standard_output_handler "- IHS instance already configured in WAS." cr
	fi
	#set +x
	}


#------------------------------------------------
# Start IHS instance in WAS console
#
function start_ihs_instance {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_IHS_START_INSTANCE:" cr
	standard_output_handler "- Starting IHS Instance ${IHS_INSTANCE_NAME} on Node ${UNMANAGED_NODE_NAME}." cr
	IHS_INSTANCE_NAME=$(echo ${UNMANAGED_NODE_NAME} | sed 's/\(.*\)_web/ihs_\1/g')
	run_was_control restartWebServer "${WAS_PROFILE_HOME}/${DMGR_NODE_NAME}/config ${WAS_CELL_NAME} ${UNMANAGED_NODE_NAME} ${IHS_INSTANCE_NAME}"
	SALT_MESSAGE="IHS instance started."
	export STATE_ihs=instance_started
	standard_output_handler "- IHS instance started." cr
	}


#------------------------------------------------
# Apply TD cell settings
#
function apply_td_cell_settings {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_APPLY_TD_CELL_SETTINGS:" cr
	if [[ -f ${WAS_HOME}/td_cell_settings_applied ]]
	then
		SALT_MESSAGE="TD standard cell settings already applied."
		standard_output_handler "- TD WAS settings are already applied." cr
	else
		standard_output_handler "- Applying TD Standard WAS Cell settings..." cr
		#------------------------------------------------
		# ensure that WAS is installaed and profile is available
		#
		if [[ ! -x ${WAS_BIN_HOME}/wsadmin.sh ]]
		then
			standard_error_handler 6 "WAS binaries not installed."
		fi
		#------------------------------------------------
		# TO DO - update key installation records
		#
		#if [[ ${WAS_VERSION} == "7.0" ]]
		#then
		#	run_wsadmin Jacl /WASupdates/legacy_install_files/jacl/updateKeyInstallationRecords.jacl ${DMGR_HOST_NAME}
		#fi
		#------------------------------------------------
		# TO DO - copy clear cache
		#
		#------------------------------------------------
		# TO DO - add tool box
		#
		#------------------------------------------------
		# add common signers
		#
		SIGNER_DIRECTORIES=${WAS_CONTROL_HOME}/etc/install
		#------------------------------------------------
		# add env specific signers
		#
		if [[ ${TD_ENVIRONMENT} == "AD_DEV" || ${TD_ENVIRONMENT} == "AD_SYS" || ${TD_ENVIRONMENT} == "ED_DEV" || ${TD_ENVIRONMENT} == "ED_SYS" ]]
		then
			SIGNER_DIRECTORIES=${SIGNER_DIRECTORIES}:${WAS_CONTROL_HOME}/etc/install/DEV_SYS
		elif [[ ${TD_ENVIRONMENT} == "AD_PAT" || ${TD_ENVIRONMENT} == "ED_PAT" ]]
		then
			SIGNER_DIRECTORIES=${SIGNER_DIRECTORIES}:${WAS_CONTROL_HOME}/etc/install/PAT
		elif [[ ${TD_ENVIRONMENT} == "AD_PROD" || ${TD_ENVIRONMENT} == "ED_PROD" ]]
		then
			SIGNER_DIRECTORIES=${SIGNER_DIRECTORIES}:${WAS_CONTROL_HOME}/etc/install/PROD
		fi
		if [[ -d ${WAS_CONTROL_HOME}/etc/install/${TD_ENVIRONMENT} ]]
		then
			SIGNER_DIRECTORIES=${SIGNER_DIRECTORIES}:${WAS_CONTROL_HOME}/etc/install/${TD_ENVIRONMENT}
		fi
		#------------------------------------------------
		# add signer for partcular TD environment
		#
		run_was_control addSignersFromDirectory ${SIGNER_DIRECTORIES}
		#------------------------------------------------
		# disable Application Placement and Health Controllers (XD)
		# TO DO - NEW - disable other XD features?
		#
		if [[ ${WAS_VERSION} == "8.5.5" ]]
		then
			run_was_control disableXDControllers
		fi
		#------------------------------------------------
		# set variables
		# TO DO - move variable creation from Salt to shell
		# TO DO - figure out why ${DUMP_HOME}/${WAS_SERVER_NAME} is not resolving for dump dir environment entries
		#
		TD_VAR_PROPFILE=${WAS_CONTROL_HOME}/etc/install/TDVariables.properties
		echo "DB2UNIVERSAL_JDBC_DRIVER_NATIVEPATH=${TD_LIB_HOME}/db2/primary" >> ${TD_VAR_PROPFILE}
		echo "DB2UNIVERSAL_JDBC_DRIVER_PATH=${TD_LIB_HOME}/db2/primary" >> ${TD_VAR_PROPFILE}
		echo "ORACLE_JDBC_DRIVER_PATH=${TD_LIB_HOME}/oracle/primary" >> ${TD_VAR_PROPFILE}
		echo "MICROSOFT_JDBC_DRIVER_PATH=${TD_LIB_HOME}/mssql/primary" >> ${TD_VAR_PROPFILE}
		echo "LOG_ROOT=${WAS_LOG_HOME}" >> ${TD_VAR_PROPFILE}
		echo "TD_APP_LOG_ROOT=${WEB_LOG_HOME}" >> ${TD_VAR_PROPFILE}
		echo "TD_APP_INSTALL_ROOT=${APPLICATION_HOME}/installedApps" >> ${TD_VAR_PROPFILE}
		echo "TD_LIB_JARS=${TD_LIB_HOME}/misc" >> ${TD_VAR_PROPFILE}
		echo "TD_APP_CONFIG_ROOT=${APPLICATION_HOME}/installedApps/config" >> ${TD_VAR_PROPFILE}
		echo "TD_DUMP_DIR=${DUMP_HOME}" >> ${TD_VAR_PROPFILE}
		echo "TD_WAS_TEMP_DIR=${WAS_TEMP_HOME}" >> ${TD_VAR_PROPFILE}
		if [[ ${WHOAMI} == "root" ]]
		then
			chown wasadm.wasadm ${TD_VAR_PROPFILE}
		fi
		if [[ -s ${TD_VAR_PROPFILE} ]]
		then
			run_wsadmin Jacl ${WAS_CONTROL_HOME}/jacl/TDVariables.jacl ${TD_VAR_PROPFILE}
		fi
		#------------------------------------------------
		# apply common TD configurations
		#
		run_was_control commonTDConfigurations ${TD_ENVIRONMENT}
		#------------------------------------------------
		# set maintenance mask
		#
		run_was_control setMaintenanceMask ${WAS_CONTROL_HOME}/etc/maintenance_mask.${WAS_VERSION}.properties
		#------------------------------------------------
		# full sync nodes
		#
		run_was_control fullSyncNodes
		#------------------------------------------------
		# Touch file to signal that standard settings are applieed
		#
		commander "touch ${WAS_HOME}/td_cell_settings_applied" "Touch cell settings"
		#------------------------------------------------
		# Set STATE VARIABLE
		#
		export STATE_was_cell=td_settings_applied
	fi
	}


#------------------------------------------------
# Apply TD cell security
#
function apply_td_cell_security {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_APPLY_TD_CELL_SECURITY:" cr
	if [[ -f ${WAS_HOME}/td_cell_security_applied ]]
	then
		SALT_MESSAGE="TD cell security already applied."
		standard_output_handler "- TD WAS Cell security is already applied." cr
	else
		standard_output_handler "- Applying TD WAS Cell security..." nocr
		#------------------------------------------------
		# ensure that WAS is installaed and profile is available
		#
		if [[ ! -x ${WAS_BIN_HOME}/wsadmin.sh ]]
		then
			standard_error_handler 6 "WAS binaries not installed."
		fi
		#------------------------------------------------
		# TO DO - set_dm_security
		#
		#------------------------------------------------
		# TO DO - set_current_ldap
		#
		#------------------------------------------------
		# TO DO - cleanup_ldap
		#
		#------------------------------------------------
		# set_global_security
		# TO DO - move bind password out of "Security files" and into tdecnrpyt storage
		#
		run_wsadmin Jacl ${WAS_CONTROL_HOME}/jacl/TDGlobalSecurity.jacl ${WAS_CONTROL_HOME}/etc/install/${TD_ENVIRONMENT}/Security.${TD_ENVIRONMENT}.properties
		#------------------------------------------------
		# add users and groups depending on environment
		# TO DO - convert to WAS Control and verify
		#
		run_wsadmin Jython ${WAS_CONTROL_HOME}/etc/install/map_users_groups.py ${TD_ENVIRONMENT}
		#------------------------------------------------
		# TO DO - add_wassecadm
		#
		#run_wsadmin Jacl $JACLDIR/mapwassecadmUser.jacl ""
		#------------------------------------------------
		# add LOB users and assign role based on environment
		#
		if [[ -n ${LDAP_GROUPS} ]]
		then
			if [[ ${TD_ENVIRONMENT} == "AD_DEV" || ${TD_ENVIRONMENT} == "ED_DEV" ]]
			then
				run_wsadmin Jython ${WAS_CONTROL_HOME}/jython/add_security_groups.py "${LDAP_GROUPS} Administrator"
			elif [[ ${TD_ENVIRONMENT} == "AD_SYS" || ${TD_ENVIRONMENT} == "ED_SYS" ]]
			then
				run_wsadmin Jython ${WAS_CONTROL_HOME}/jython/add_security_groups.py "${LDAP_GROUPS} Monitor"
			fi
		fi
		#------------------------------------------------
		# full sync nodes
		#
		run_was_control fullSyncNodes
		#------------------------------------------------
		# Touch file to signal that security settings are applieed
		#
		commander "touch ${WAS_HOME}/td_cell_security_applied" "Touch security settings"
		#------------------------------------------------
		# Set STATE VARIABLE
		#
		export STATE_was_cell=td_security_applied
	fi
	}


#------------------------------------------------
# WAS ADS - Application Configuration
#
function was_deploy_ads {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_WAS_DEPLOY_ADS:" cr
	standard_output_handler "- Deploying WAS ADS..." cr
	if [[ -d ${ADS_HOME} ]]
	then
		standard_output_handler "- Found ADS directory \"${ADS_HOME}\"." cr
		standard_output_handler "- Processing WAS ADS..." cr
		ADS_PATH=$(echo ${ADS_PATH} | sed -e 's/\/\.//g')
		if [[ -d ${ADS_HOME}/WAS/${ADS_PATH} ]]
		then
			ADS_PARENT_TEMP_WORK_SPACE=/td/work1/$(date "+%s")
			mkdir ${ADS_PARENT_TEMP_WORK_SPACE}
			cp -pR ${ADS_HOME}/* ${ADS_PARENT_TEMP_WORK_SPACE}
			ADS_ACTIVE_PATH=${ADS_PARENT_TEMP_WORK_SPACE}
			for ADS_PATH_ELEMENT in $(echo WAS/${ADS_PATH} | tr '/' ' ')
			do
				ADS_ACTIVE_PATH=${ADS_ACTIVE_PATH}/${ADS_PATH_ELEMENT}
				standard_output_handler "- Found ADS path \"${ADS_ACTIVE_PATH}\"." cr
				#------------------------------------------------
				# find properties in local path segment and reverse alpha sort so that commands are run in order
				#
				ADS_FILE_LIST=$(find ${ADS_ACTIVE_PATH} -maxdepth 1 -name "*.properties" | sort -r)
				WAS_CONTROL_BATCH_FILE=${ADS_ACTIVE_PATH}/was_control_batch_file.txt
				touch ${WAS_CONTROL_BATCH_FILE}
				for ADS_FILE in ${ADS_FILE_LIST}
				do
					if [[ $(grep -cvE "^#.*|^$|^^M" ${ADS_FILE}) -ne 0 ]]
					then
						standard_output_handler "  - Found ${ADS_FILE}." cr
						WAS_CONTROL_FUNCTION=$(echo ${ADS_FILE} | sed -e 's/.*\.\(.*\)\.properties/\1/')
						standard_output_handler "    - WAS Control Function = ${WAS_CONTROL_FUNCTION}." cr
						if [[ ${WAS_CONTROL_FUNCTION} == "wascontrolcommand" ]]
						then
							#------------------------------------------------
							# clean up command file and add to "front" of command list so that commands are run from end of path first
							#
							WAS_CONTROL_COMMAND_STRING=$(cat ${ADS_FILE} | grep -v command | tr -d $'\r\n')
							echo ${WAS_CONTROL_COMMAND_STRING} > ${ADS_FILE}
							WAS_CONTROL_COMMAND_FILES=${ADS_FILE}:${WAS_CONTROL_COMMAND_FILES}
						else
							$(grep -q create_if_not_exist ${ADS_FILE})
							if [[ $? -ne 0 ]]
							then
								echo "create_if_not_exist=true" >> ${ADS_FILE}
							fi
							echo ${ADS_FILE}=batch >> ${WAS_CONTROL_BATCH_FILE}
						fi
					fi
				done
				#------------------------------------------------
				# handle batch command for path element
				#
				standard_output_handler "  - Running WAS Control batch for ${ADS_ACTIVE_PATH}..." cr
				run_was_control processADSbatch ${WAS_CONTROL_BATCH_FILE}
			done
			#------------------------------------------------
			# handle was control commands from all path elements
			#
			standard_output_handler "  - Running WAS Control commands in this order:" cr
			for WAS_CONTROL_COMMAND_FILE in $(echo ${WAS_CONTROL_COMMAND_FILES} | tr ":" " ")
			do
				standard_output_handler "    - ${WAS_CONTROL_COMMAND_FILE}" cr
			done
			for WAS_CONTROL_COMMAND_FILE in $(echo ${WAS_CONTROL_COMMAND_FILES} | tr ":" " ")
			do
				WAS_CONTROL_COMMAND_FUNCTION=$(cat ${WAS_CONTROL_COMMAND_FILE} | awk '{print $1}')
				WAS_CONTROL_COMMAND_ARGUMENTS=$(cat ${WAS_CONTROL_COMMAND_FILE} | awk '{$1=""}{print $0}')
				run_was_control ${WAS_CONTROL_COMMAND_FUNCTION} "${WAS_CONTROL_COMMAND_ARGUMENTS}"
			done
			rm -fr ${ADS_PARENT_TEMP_WORK_SPACE}
		else
			standard_error_handler 31 "Error encountered.  Invalid configuration path \"${ADS_PATH}\"."
		fi
	else
		standard_error_handler 35 "Error encountered.  Cannot find ADS home."
	fi
	SALT_MESSAGE="Completed WAS Application Configuration Deployment."
	standard_output_handler "- Completed Application Configuration Deployment." cr
	export STATE_ads=application_deployed
	}


#------------------------------------------------
# Stop all application servers
#
function stop_application_servers {
	#set -x
	standard_output_handler "" cr
	standard_output_handler "ACTION_STOP_APPLICATION_SERVERS:" cr
	WAS_PROCESSES=$(ps -fu wasadm | grep ${MANAGED_NODE_NAME} | grep -vE "dmgr|grep|nodeagent" | awk '{print $2}')
	if [[ -n ${WAS_PROCESSES} ]]
	then
		for WAS_PROCESS in ${WAS_PROCESSES}
		do
			standard_output_handler "- Killing WAS process ${WAS_PROCESS}..." nocr
			#------------------------------------------------
			# TO DO - handle other WAS process states
			#
			commander "kill -9 ${WAS_PROCESS}" "Kill -9"
			standard_output_handler "Done." cr
		done
	else
		SALT_MESSAGE="No Application Servers are running."
		standard_output_handler "- No Application Servers are running." cr
	fi
	}


#------------------------------------------------
# stop all IHS
#
function stop_ihs {
	standard_output_handler "- Stop for IHS not implemented yet." cr
	}


#------------------------------------------------
# delete files
#
function delete_files {
	#set -x
	FILE_TYPE=$1
	standard_output_handler "" cr
	standard_output_handler "ACTION_DELETE_FILES:" cr
	standard_output_handler "- File type: ${FILE_TYPE}" cr
	if [[ ${FILE_TYPE} == "IM" ]]
	then
		FILE_HOME=${IM_HOME}
	elif [[ ${FILE_TYPE} == "IHS" ]]
	then
		FILE_HOME=${IHS_HOME}
	elif [[ ${FILE_TYPE} == "PLG" ]]
	then
		FILE_HOME=${PLG_HOME}
	elif [[ ${FILE_TYPE} == "WAS" ]]
	then
		FILE_HOME=${WAS_HOME}
	fi
	if [[ $? -eq 0 ]]
	then
		standard_output_handler "- Removing all ${FILE_TYPE} related files..." nocr
		for FILE in $(ls ${FILE_HOME})
		do
			#commander "cd ${FILE_HOME};rm -fr ${FILE}"
			commander "rm -fr ${FILE_HOME}/${FILE}" "Remove ${FILE_HOME} files"
		done
		standard_output_handler "Done." cr
	else
		standard_output_handler "- No ${FILE_TYPE} related files found." cr
	fi
	}


#------------------------------------------------
# User Input
#
if [[ -n ${ACTION_USER_INPUT} && ${DISPLAY_MESSAGES} != "salt" ]] 
then
	user_input "${ACTION_USER_INPUT}"
fi


#------------------------------------------------
# Install IM
#
if [[ -n ${ACTION_IM_INSTALL} ]] 
then
	install_im
fi


#------------------------------------------------
# uninstall IM
#
if [[ -n ${ACTION_IM_UNINSTALL} ]]
then
	uninstall_im
fi


#------------------------------------------------
# Install IHS package
#
if [[ -n ${ACTION_IHS_INSTALL} ]]
then
	install_package ${IHS_PACKAGE_PATTERN} ${IHS_INSTALL_RESPONSE_FILE}
fi


#------------------------------------------------
# Install PLG package
#
if [[ -n ${ACTION_PLG_INSTALL} ]]
then
	install_package ${PLG_PACKAGE_PATTERN} ${PLG_INSTALL_RESPONSE_FILE}
fi


#------------------------------------------------
# Install WAS package
#
if [[ -n ${ACTION_WAS_INSTALL} ]]
then
	install_package ${WAS_PACKAGE_PATTERN} ${WAS_INSTALL_RESPONSE_FILE}
fi


#------------------------------------------------
# Create Deployment Manager profile
#
if [[ -n ${ACTION_WAS_CREATE_DMGR_PROFILE} ]]
then
	create_dmgr_profile
fi


#------------------------------------------------
# Delete Deployment Manager profile
#
if [[ -n ${ACTION_WAS_DELETE_DMGR_PROFILE} ]]
then
	delete_dmgr_profile
fi


#------------------------------------------------
# Create Deploument Manager service
#
if [[ -n ${ACTION_WAS_CREATE_DMGR_SERVICE} ]]
then
	create_dmgr_service
fi


#------------------------------------------------
# Delete Deploument Manager service
#
if [[ -n ${ACTION_WAS_DELETE_DMGR_SERVICE} ]]
then
	delete_dmgr_service
fi


#------------------------------------------------
# Start Deployment Manager
#
if [[ -n ${ACTION_WAS_START_DMGR} ]]
then
	start_dmgr
fi


#------------------------------------------------
# Stop Deployment Manager
#
if [[ -n ${ACTION_WAS_STOP_DMGR} ]]
then
	stop_dmgr
fi


#------------------------------------------------
# Install TD libs
#
if [[ -n ${ACTION_TD_LIBS_INSTALL} ]]
then
	install_td_libs
fi


#------------------------------------------------
# Install WAS Control
#
if [[ -n ${ACTION_WAS_CONTROL_INSTALL} ]]
then
	install_was_control
fi


#------------------------------------------------
# Create Managed Node profile
#
if [[ -n ${ACTION_WAS_CREATE_MANAGED_NODE_PROFILE} ]]
then
	create_managed_node_profile
fi


#------------------------------------------------
# Delete Managed Node profile
#
if [[ -n ${ACTION_WAS_DELETE_MANAGED_NODE_PROFILE} ]]
then
	delete_managed_node_profile
fi


#------------------------------------------------
# Create Node Agent service
#
if [[ -n ${ACTION_WAS_CREATE_NODEAGENT_SERVICE} ]]
then
	create_nodeagent_service
fi


#------------------------------------------------
# Delete Node Agent service
#
if [[ -n ${ACTION_WAS_DELETE_NODEAGENT_SERVICE} ]]
then
	delete_nodeagent_service
fi


#------------------------------------------------
# Federate Node
#
if [[ -n ${ACTION_WAS_FEDERATE_NODE} ]]
then
	federate_node
fi


#------------------------------------------------
# Remove Node
# TO DO - figure out how to pass node name to remove_node function
#
if [[ -n ${ACTION_WAS_REMOVE_NODE} ]]
then
	remove_node ${TO_DO_NODE_NAME}
fi


#------------------------------------------------
# Start Node Agent
#
if [[ -n ${ACTION_WAS_START_NODEAGENT} ]]
then
	start_nodeagent
fi


#------------------------------------------------
# Stop Node Agent
#
if [[ -n ${ACTION_WAS_STOP_NODEAGENT} ]]
then
	stop_nodeagent
fi


#------------------------------------------------
# Create stand alone profile
#
if [[ -n ${ACTION_WAS_CREATE_STAND_ALONE_PROFILE} ]]
then
	create_stand_alone_profile
fi


#------------------------------------------------
# Start server1
#
if [[ -n ${ACTION_WAS_START_SERVER1} ]]
then
	start_server1
fi

#------------------------------------------------
# Add Managed Node
#
if [[ -n ${ACTION_WAS_ADD_MANAGED_NODE} ]]
then
	add_managed_node
fi


#------------------------------------------------
# Create IHS instance
#
if [[ -n ${ACTION_IHS_CREATE_INSTANCE} ]]
then
	create_ihs_instance
fi


#------------------------------------------------
# Add Unmanaged Nodes
#
if [[ -n ${ACTION_WAS_ADD_UNMANAGED_NODE} ]]
then
	add_unmanaged_node
fi


#------------------------------------------------
# Create IHS Admin Server
#
if [[ -n ${ACTION_IHS_CREATE_ADMIN_SERVER} ]]
then
	create_ihs_admin_server
fi


#------------------------------------------------
# Start IHS Admin Server
#
if [[ -n ${ACTION_IHS_START_ADMIN_SERVER} ]]
then
	start_ihs_admin_server
fi


#------------------------------------------------
# Add IHS instance
#
if [[ -n ${ACTION_IHS_ADD_INSTANCE} ]]
then
	add_ihs_instance
fi


#------------------------------------------------
# Start IHS instance
#
if [[ -n ${ACTION_IHS_START_INSTANCE} ]]
then
	start_ihs_instance
fi


#------------------------------------------------
# Apply WAS TD settings
#
if [[ -n ${ACTION_WAS_APPLY_TD_CELL_SETTINGS} ]] 
then
	apply_td_cell_settings
fi


#------------------------------------------------
# Apply WAS TD security
#
if [[ -n ${ACTION_WAS_APPLY_TD_CELL_SECURITY} ]] 
then
	apply_td_cell_security
fi


#------------------------------------------------
# Deploy ADS
#
if [[ -n ${ACTION_WAS_DEPLOY_ADS} ]] 
then
	was_deploy_ads
fi


#------------------------------------------------
# Uninstall ALL packages
#
if [[ -n ${ACTION_ALL_UNINSTALL} ]]
then
	# TO DO - stop everything
	# TO DO - remove any Linux services
	uninstall_package ALL
fi


#------------------------------------------------
# Uninstall IHS package only
#
if [[ -n ${ACTION_IHS_UNINSTALL} ]]
then
	uninstall_package ${IHS_PACKAGE_PATTERN}
fi


#------------------------------------------------
# Uninstall PLG package only
#
if [[ -n ${ACTION_PLG_UNINSTALL} ]]
then
	uninstall_package ${PLG_PACKAGE_PATTERN}
fi


#------------------------------------------------
# Uninstall WAS and related package
#
if [[ -n ${ACTION_WAS_UNINSTALL} ]] && [[ -n ${WAS_PACKAGE_PATTERN} ]]
then
	if [[ -n ${IBMJAVA70_PACKAGE_PATTERN} ]]
	then
		uninstall_package ${IBMJAVA70_PACKAGE_PATTERN}
	fi
	if [[ -n ${IBMJAVA71_PACKAGE_PATTERN} ]]
	then
		uninstall_package ${IBMJAVA71_PACKAGE_PATTERN}
	fi
	if [[ -n ${WEB2MOBILE_PACKAGE_PATTERN} ]]
	then
		uninstall_package ${WEB2MOBILE_PACKAGE_PATTERN}
	fi
	if [[ -n ${WXSCLIENT_PACKAGE_PATTERN} ]]
	then
		uninstall_package ${WXSCLIENT_PACKAGE_PATTERN}
	fi
	uninstall_package ${WAS_PACKAGE_PATTERN}
fi


#------------------------------------------------
# Stop ALL application servers
#
if [[ -n ${ACTION_WAS_STOP_APPLICATION_SERVERS} ]]
then
	stop_application_servers
fi


#------------------------------------------------
# handle if no "ACTION" given
#
#set -x
if [[ -z ${ACTION_USER_INPUT} && -z ${ACTION_IM_INSTALL} && -z ${ACTION_IHS_INSTALL} && -z ${ACTION_PLG_INSTALL} && -z ${ACTION_WAS_INSTALL} && -z ${ACTION_TD_LIBS_INSTALL} && -z ${ACTION_WAS_CONTROL_INSTALL} && -z ${ACTION_WAS_CREATE_DMGR_PROFILE} && -z ${ACTION_WAS_DELETE_DMGR_PROFILE} && -z ${ACTION_WAS_CREATE_DMGR_SERVICE} && -z ${ACTION_WAS_DELETE_DMGR_SERVICE} && -z ${ACTION_WAS_START_DMGR} && -z ${ACTION_WAS_STOP_DMGR} && -z ${ACTION_WAS_CREATE_MANAGED_NODE_PROFILE} && -z ${ACTION_WAS_DELETE_MANAGED_NODE_PROFILE} && -z ${ACTION_WAS_CREATE_NODEAGENT_SERVICE} && -z ${ACTION_WAS_DELETE_NODEAGENT_SERVICE} && -z ${ACTION_WAS_FEDERATE_NODE} && -z ${ACTION_WAS_REMOVE_NODE} && -z ${ACTION_WAS_START_NODEAGENT} && -z ${ACTION_WAS_STOP_NODEAGENT} && -z ${ACTION_WAS_CREATE_STAND_ALONE_PROFILE} && -z ${ACTION_WAS_START_SERVER1} && -z ${ACTION_WAS_ADD_MANAGED_NODE} && -z ${ACTION_IHS_CREATE_ADMIN_SERVER} && -z ${ACTION_IHS_START_ADMIN_SERVER} && -z ${ACTION_IHS_CREATE_INSTANCE} && -z ${ACTION_WAS_ADD_UNMANAGED_NODE} && -z ${ACTION_IHS_ADD_INSTANCE} && -z ${ACTION_IHS_START_INSTANCE} && -z ${ACTION_WAS_APPLY_TD_CELL_SETTINGS} && -z ${ACTION_WAS_DEPLOY_ADS} && -z ${ACTION_WAS_APPLY_TD_CELL_SECURITY} && -z ${ACTION_WAS_STOP_APPLICATION_SERVERS} && -z ${ACTION_IM_UNINSTALL} && -z ${ACTION_IHS_UNINSTALL} && -z ${ACTION_PLG_UNINSTALL} && -z ${ACTION_WAS_UNINSTALL} ]]
then
	standard_error_handler 1 "No \"ACTION\" set."
fi


if [[ ${DISPLAY_MESSAGES} != "salt" ]]
then
	standard_output_handler "" cr
fi


#------------------------------------------------
# Output salt state
#
if [[ ${DISPLAY_MESSAGES} == "salt" ]]
then
	#set -x
	standard_output_handler "" cr
	STATES=$(env | grep ^STATE)
	if [[ -n ${STATES} ]]
	then
		standard_output_handler "" cr
		if [[ -n ${SALT_MESSAGE} ]]
		then
			standard_output_handler "changed=yes comment='${SALT_MESSAGE}'" nocr
		else
			standard_output_handler "changed=yes comment='Middleware state has changed'" nocr
		fi
		for STATE in ${STATES}
		do
			if [[ ${OS} == "AIX" ]]
			then
				echo " \c"
			elif [[ ${OS} == "Linux" ]]
			then
				echo -n " "
			fi
			STATE_NAME=$(echo ${STATE} | cut -f1 -d= | sed -e 's/STATE_\(.*\)/\1/g')
			STATE_VALUE=$(echo ${STATE} | cut -f2 -d=)
			standard_output_handler ${STATE_NAME}=${STATE_VALUE} nocr
		done
		standard_output_handler "" cr
	else
		standard_output_handler "" cr
		if [[ -n ${SALT_MESSAGE} ]]
		then
			standard_output_handler "changed=no comment='${SALT_MESSAGE}'" cr
		else
			standard_output_handler "changed=no comment='No Middleware state changes'" cr
		fi
	fi
fi
