#!/bin/bash
 
# This script deploys the Splunk universal forwarder
 
# --Variables that you must set -----
# Set the install file name to the name of the file that wget downloads
# (the second argument to wget)
INSTALL_FILE="splunk_forwarder.tgz"
 
# This should be a WGET command that was *carefully* copied from splunk.com!!
# Sign into splunk.com and go to the download page, then look for the wget
# link near the top of the page (once you have selected your platform)
# copy and paste your wget command between the ""
WGET_CMD="wget http://10.112.213.57/nexus/service/local/artifact/maven/redirect?r=ITS-Group&g=com.splunk&a=forwarder&v=LATEST&c=x86_64&e=tgz -O $INSTALL_FILE" 

# After installation, the forwarder will send events to this receiving Splunk indexer.
# May or may not be the same server as Splunk Web.
FWD_RECEIVE_SERVER="10.112.213.52:9997"
 
# DISABLED: we will NOT use the Splunk deployment mechanism, rather Salt will tell the forwarders what files to monitor etc.
# After installation, the forwarder will become a deployment client of this
# host.  Specify the host and management (not web) port of the deployment server
# that will be managing these forwarder instances.
# DEPLOY_SERVER="10.111.161.72:8089"
 
# Set the new Splunk admin password
PASSWORD="admin"
 
# The user who will run splunkd on remote targets
SPLUNK_USER=root
 
# ----------- End of user settings -----------
 
# Watch out for line wraps, esp. in the "set deploy-poll" line below.
 
#Create user splunk in groups splunk, wheel (for sudo access)
# getent passwd $SPLUNK_USER > /dev/null
# if [ $? -eq 0 ]; then
#    echo "User $SPLUNK_USER exists. Continuing..."
# else
#    echo "User $SPLUNK_USER does not exist. Creating..."
#    useradd -m -s /bin/bash -G wheel $SPLUNK_USER
#fi
 
cd /opt
$WGET_CMD
# the below two lines can be changed to use RPM instead. Splunk provides RedHat RPM packages too. chown is not needed in that case as they create the splunk:splunk user/group.
tar -xzf $INSTALL_FILE
chown -R $SPLUNK_USER /opt/splunkforwarder
chgrp -R $SPLUNK_USER /opt/splunkforwarder

/opt/splunkforwarder/bin/splunk start --accept-license --answer-yes --auto-ports --no-prompt
/opt/splunkforwarder/bin/splunk edit user admin -password $PASSWORD -auth admin:changeme

/opt/splunkforwarder/bin/splunk add forward-server $FWD_RECEIVE_SERVER -auth admin:$PASSWORD

if [ -e /etc/redhat-release ]
then
    echo redhat
    yum install -y sysstat
else
    echo ubuntu
    apt-get install -y sysstat
fi
cd /opt/splunkforwarder/etc/apps
wget http://10.112.213.57/nexus/service/local/repo_groups/ITS-Group/content/com/splunk/unix-addon/5.1.0/unix-addon-5.1.0-x86_64.tgz
tar xf unix-addon-5.1.0-x86_64.tgz
chown $SPLUNK_USER:$SPLUNK_USER -R /opt/splunkforwarder/etc/apps/Splunk_TA_nix/

/opt/splunkforwarder/bin/splunk enable boot-start -user $SPLUNK_USER

# open firewall ports if needed:
lokkit --port=8089:tcp --update
lokkit --port=9997:tcp --update

 
# if specific splunk files are touched from here on, you also need to:
# 1. RECHECK dir/file user/group ownership in case it's been changed to root
# 2. RESTART the forwarder
# ------------------------
# add default files splunk monitors on all VMs.
# this is the celery log file
/opt/splunkforwarder/bin/splunk add monitor $(ls ~cloud-user/cloudify.*/work/celery.log) -index main -sourcetype storm:cloudify:celery -auth admin:$PASSWORD

# aide
/opt/splunkforwarder/bin/splunk add monitor "/var/log/aide/aide.log" -index main -sourcetype storm:security:aide -auth admin:$PASSWORD

# audit
/opt/splunkforwarder/bin/splunk add monitor "/var/log/audit/audit.log" -index main -sourcetype storm:security:audit -auth admin:$PASSWORD

# mail/postfix
/opt/splunkforwarder/bin/splunk add monitor "/var/log/maillog" -index main -sourcetype storm:infra:mail -auth admin:$PASSWORD

# sssd
/opt/splunkforwarder/bin/splunk add monitor "/var/log/sssd/*.log" -index main -sourcetype storm:security:sssd -auth admin:$PASSWORD

# salt minion log
/opt/splunkforwarder/bin/splunk add monitor "/var/log/salt/minion" -index main -sourcetype storm:salt:minion -auth admin:$PASSWORD

# salt grains file
/opt/splunkforwarder/bin/splunk add monitor "/etc/salt/grains" -index main -sourcetype storm:salt:grains -auth admin:$PASSWORD

# post install script
/opt/splunkforwarder/bin/splunk add monitor "/tmp/post-install-script.log" -index main -sourcetype storm:cloudify:post-install -auth admin:$PASSWORD

# monitor a catch-all dir /var/splunked for quick onboarding, where users can created symlinks to their own app's log dir, where *.log files will be splunked
mkdir /var/splunked
chmod a+rwx /var/splunked
/opt/splunkforwarder/bin/splunk add monitor "/var/splunked/*/*.log" -index main -auth admin:$PASSWORD

/opt/splunkforwarder/bin/splunk restart
