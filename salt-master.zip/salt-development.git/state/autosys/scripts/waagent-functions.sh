#!/bin/bash
#$ cat deploy_wa_vm.sh
# This script creates a virtual machine and real      #
# machine names for TD Cloud Computing Environment.   #
# $1 - Virtual Machine Name                           #
# $2 - Real Machine Name                              #
# $3 - Path to file if the default is not used        # 

function getKeys(){
# Retrieve the key file base on the environment and OS name
# Check for an input argument
log "Starting .. getkeys" 
wafile="${DIRECTORY}wa-agentkeys-$NOWT-$2.txt"
if [ $# -ne 2 ]
then
	echo "Usage: getKeys /"OSNAME/" /"ENVIRONMENT/""
	echo "Input"
	echo "# Argument 1 - values windows,linux,aix,solaris => Operating System Name"
	echo "# Argument 2 - values DEV,PAT,PRD  => Virtual Machine Name and Real Machine"
	echo "Output"
	echo "# Variable - getKeys"
	return 5 # missing arguments
	fi
log "getKeys - Input $1"
log "getKeys - Input $2"
wget -P ${DIRECTORY} --user=anonymous --password=anonymous ftp://ca-schsvr-lab.tdbank.ca:10021/unc/wa-agentkeys-"$2".txt -O $wafile
local getKey=$(grep $1 $wafile | cut -d':' -s -f2)
log "getKeys - Output $getKey"
echo $getKey
rm $wafile 
log "Ending getkeys"

}

function getVM() {
# Select only virtual machines from the autorep -M output
# Usage: getVM() where 
# Input: $1
# 	= "" => the Virtual Name Only
# 	= 2  => Virtual Machine Name and Real Machine
# Output: $result

log "getVM Input: $1"
if [ -z "$1" ]
then
	result=$( { autorep -M ALL -s | cut -c1-64 | cut -d'.' -s -f1,2; })
else
	result=$( { autorep -m "$1" -s | cut -c1-64 | cut -d'.' -s -f1; })
echo $?
fi
log "getVM Output: $result"
}

function addRealMachine() {
# Adds a Real Machine to Autosys
#td-rhel6-14e5c.dev.eng.cloud.td.com
# Build Real Machine File
if [ $# -ne 3 ]
then
	echo "Usage: addRealMachine /"HOSTNAME/" /"OSNAME/" /"ENVIRONMENT/""
	echo "Input"
	echo "# Argument 1 - System External HostName"
	echo "# Argument 2 - values windows,linux,aix,solaris => Operating System Name"
	echo "# Argument 3 - values DEV,PAT,PRD  => Virtual Machine Name and Real Machine"
	echo "Output"
	echo "# Return - TRUE (0) or FALSE(1)"
	return 5 # missing arguments
fi
log "Input 1 - $1"
log "Input 2 - $2"
log "Input 3 - $3"

local snrm=$(echo $1 |  cut -d'.' -s -f1)     # Short Name for the Real Machine
local rmjilfile=${DIRECTORY}jil/rm_$snrm_$NOWT.jil
local rmlogfile=${DIRECTORY}logs/rm_$snrm_$NOWT.log
: > $rmjilfile
: > $rmlogfile
	
#Build the JIL file
local resultKey=$(getKeys "$2" "$3")		#Get Agent Keys

log "Key Retrieved - $resultKey"

echo "insert_machine: $snrm" >> $rmjilfile
echo "type: a" >> $rmjilfile
echo "port: 7520" >> $rmjilfile
echo "node_name: $1" >> $rmjilfile
echo "agent_name: $snrm" >> $rmjilfile
echo "encryption_type: AES" >> $rmjilfile
echo "opsys: $2" >> $rmjilfile
echo "character_code: ASCII" >> $rmjilfile
echo "key_to_agent: $resultKey" >> $rmjilfile
echo "description: Cloud Added" >> $rmjilfile

#Execute JIL Command
$(jil<$rmjilfile > $rmlogfile 2>&1)
local rmjilerrcnt=$(grep -c 'Exit Code = 1' $rmlogfile)

#Check for Errors
if [ $rmjilerrcnt != 0 ] 
then
	log "Real Machine[$snrm] creation unsuccessful"
	return 10
else
	log "Real Machine[$snrm] creation successful"
	$(rm $rmjilfile)
	$(rm $rmlogfile)
	return 0
fi
}

function isVM() {
# Check if Virtual Machine Exists function
# Output: TRUE or FALSE
if [ -z $result ];
then
	return 0
else
	return 1
fi
}

function addVirtualMachine() {
# Adds a Virtual Machine to Autosys
# td-rhel6-14e5c.dev.eng.cloud.td.com
# Build Real Machine File

if [ $# -ne 2 ]
then
	echo "Usage: addVirtualMachine /"VMNAME/" /"HOSTNAME/""
	echo "Input"
	echo "# Argument 1 - Virtual Machine Name"
	echo "# Argument 2 - System External HostName"
	echo "Output"
	echo "# Return - TRUE (0) or FALSE(1)"
	return 5 # missing arguments
fi
log "addVirtualMachine Input - $1"
log "addVirtualMachine Input - $2"

local vmnm=$1
local snrm=$(echo $2 |  cut -d'.' -s -f1)     # Short Name for the Real Machine
local vmjilfile=${DIRECTORY}jil/vm_$snrm_$NOWT.jil
local vmlogfile=${DIRECTORY}logs/vm_$snrm_$NOWT.log
: > $vmjilfile
: > $vmlogfile
	
echo "insert_machine: $vmnm" >> $vmjilfile
echo "type: v" >> $vmjilfile
echo "machine: $snrm" >> $vmjilfile

#Execute JIL Command
#{ $(jil<$vmjilfile 2>&1 /dev/null | grep -i $ERRCODE > $vmlogfile); }
$(jil<$vmjilfile > $vmlogfile 2>&1)
local vmjilerrcnt=$(grep -c 'Exit Code = 1' $vmlogfile)

#Check for Errors
if [ $vmjilerrcnt != 0 ]
then
	log "Virtual Machine[$vmnm] creation unsuccessful"
	return 10
else
	log "Virtual Machine[$vmnm] creation successful"
	$(rm $vmjilfile)
	$(rm $vmlogfile)		
	return 0
fi
}

