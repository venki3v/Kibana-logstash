#!/bin/bash 
#$ cat set_saltgrains.sh                               #
# Execute this script as a tactical method to execute  # 
# the CA7/Autosys Salt state which mimics a bootstrap  # 
# issued through Storm/Cloudify.                       #

if [ $# -ne 4 ]
then
	echo -e "Usage: $0 "Scheduler_Client" "Scheduler_Type" "Scheduler_Environment" "Scheduler_Virtual_agent"\n"
	echo "e.g $0 True autosys SIT MYVIRTUALMACHINE"
	echo "Role: A role of 'scheduler_client' must be set to true to True activate or False to deactivate"
	echo "Grain: A grain of 'scheduler_type' created and set to one of the values: [autosys|ca7]"
	echo "Grain: A grain of 'scheduler_environment' created and set to one of the values: [SIT|PAT|PRD]"
	echo -e "Grain: A grain of 'scheduler_virtual_agent' created and set with a value of your agent alias name eg: AGENTALIAS. The name can contain up to 80 characters.\n\n"
        exit 5 # missing arguments
fi

schd_typ=(${2,,})
schd_env=(${3,,})
schd_vagt=(${4,,})

if [ $1 is False ]
then 
  sudo salt-call grains.roles roles scheduler_client
  sudo salt-call state.sls autosys.remove-agent --local
  exit 0
fi

sudo salt-call grains.append roles scheduler_client
sudo salt-call grains.setval scheduler_type $schd_typ
sudo salt-call grains.setval scheduler_environment $schd_env
sudo salt-call grains.setval scheduler_virtual_agent $schd_vagt

sudo salt-call state.sls autosys --local
