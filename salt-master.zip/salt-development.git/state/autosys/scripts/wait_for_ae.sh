#!/bin/bash
# This script is used to add a delay to Salt so that the #
# Autosys job can successully complete in a timely manor #
echo "Waiting to check state on job submission ..."

sleep 90

# writing the state line
echo  # an empty line here so the next line will be the last.
echo "changed=yes comment='Proceeding to check job results'"	 
