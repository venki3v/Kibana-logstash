{% from "autosys/map.jinja" import autosys with context %}

#!/bin/bash 
#$ cat add_cloud_to_ae.sh                             #
# This script triggers an Autosys job to process the  #
# TD Cloud Computing information.                     #

URL="https://{{autosys.web_services_url}}:{{autosys.web_services_port}}"

if [ $# -ne 2 ]
then
        echo "Usage: $0 /"VIRTUALNAME/" /"HOSTNAME/""
        echo "Input"
        echo "# Argument 1 - Virtual Machine Name"
        echo "# Argument 2 - Host Machine"
        echo "Output"
        echo "# Success (0) or Failed (10)"
        return 5 # missing arguments
fi

result=$( curl -k -s -i -X POST \
   -H "Authorization:{{autosys.auth_key}}" \
   -H "Content-Type:application/xml" \
   -d \
'<command>
<jobName>{{grains['scheduler_environment']|upper}}_CLOUD_CMD_CLOUDINSERTMACHINE</jobName>
<comment>Processing for Cloud Computing - '$1' - '$2'</comment>
</command>' \
 ''$URL'/AEWS/event/start-job' | grep -c '201 Created' )

if [ $result = 1 ]
then
    echo "Job submission successful. Proceeding to check response"; exit 0
else
    echo "Error on job submission" ; exit 10
fi
