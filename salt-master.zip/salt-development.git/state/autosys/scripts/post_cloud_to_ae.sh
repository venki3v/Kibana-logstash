{% from "autosys/map.jinja" import autosys with context %}

#!/bin/bash
#$ cat post_cloud_to_ae.sh                            #
# This script post TD Cloud Computing information to  #
# the Autosys environment.                            #
# $1 - Virtual Machine Name                           #
# $2 - Real Machine Name                              #
# $3 - Operating System                               #
# $4 - Environment                                    # 

URL="https://{{autosys.web_services_url}}:{{autosys.web_services_port}}"

if [ $# -ne 4 ]
then
        echo "Usage: $0 /"VIRTUALNAME/" /"HOSTNAME/" /"OSNAME/" /"ENVIRONMENT/""
        echo "Input"
        echo "# Argument 1 - Virtual Machine Name"
        echo "# Argument 2 - Host Machine"
        echo "# Argument 3 - values windows,linux,aix,solaris => Operating System Name"
        echo "# Argument 4 - values DEV,SIT,PAT,PRD"
        echo "Output"
        echo "# Variable - getKeys"
        return 5 # missing arguments
fi

result=$(curl -k --data "vmname=$1+&rmname=$2+&osname=$3+&envname=$4" $URL/UNC/fileupload.jsp )

if [ $result = "Success" ]
then
   echo "Agent information sent successfully"; exit 0
else
   echo "Error submitting agent information"; exit 10
fi
                                                            
