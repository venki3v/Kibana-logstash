#!/bin/bash 

function db {
# Debug function
# Usage: db message in parts
	if [ $DEBUG -eq 1 ];
	then
		echo "$@"
	fi
}

function log {
# Log function, handles input from stdin or from arguments
# Usage: log message in parts
# Usage2: echo message | log
# If there are parameters read from parameters
	if [ $# -gt 0 ]; then
		echo "[$(date +"%D %T")] $@" >> $LOG_FILE
		db "$@"
	else
		# If there are no parameters read from stdin
		while read data
		do
			echo "[$(date +"%D %T")] $data" >> $LOG_FILE
			db "$data"
		done
	fi
}

function error {
# Error function
# Usage: error N message
	echo "[$(date +"%D %T")] $@" >> $ERROR_FILE
	db "$@"
}