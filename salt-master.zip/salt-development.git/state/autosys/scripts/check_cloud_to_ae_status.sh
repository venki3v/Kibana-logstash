{% from "autosys/map.jinja" import autosys with context %}

#!/bin/bash
#$ cat check_cloud_to_ae_status.sh                    #
# This script triggers an Autosys job to process the  #
# TD Cloud Computing information.                     #

URL="https://{{autosys.web_services_url}}:{{autosys.web_services_port}}" 

if [ $# -ne 1 ]
then
        echo "Usage: $0 /"HOSTNAME/""
        echo "Input"
        echo "# Argument 1 - Host Machine"
        echo "Output"
        echo "# Success (0) or Failed (10)"
        return 5 # missing arguments
fi

snrm=$(echo $1 |  cut -d'.' -s -f1)
result=$(curl -k --data "rmname=$snrm" $URL/UNC/checkstatus.jsp | grep -c 'Success' )

if [ $result = 1 ]
then
    echo "Success"; exit 0
else
    echo "Failed" ; exit 10
fi
