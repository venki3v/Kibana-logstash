#!/bin/bash

#$ cat deploy_wa_vm.sh
# This script creates a virtual machine and real      #
# machine names for TD Cloud Computing Environment.   #
# $1 - Input File which contains the path to the JIL  #

# Basic Enviroment Settings 
DEBUG=0
NOW=$(date +"%Y_%m_%d")
NOWT=$(date +"%Y_%m_%d_%H_%M_%S")
DIRECTORY="/td/UNC/CloudAutomation/"
ERROR_FILE="${DIRECTORY}error_$NOW.log"
LOG_FILE="${DIRECTORY}logs/log_$NOW.log"

# Debug Functions
. /td/UNC/application-and-error-logging.sh

# Machine Functions
. /td/UNC/waagent-functions.sh

log "==================== $NOWT ====================="

function setAppEnvironment() {
echo "argument:$1"
if [ $1 ]
then
	ERRCODE='CAUAJM_E_10302|CAUAJM_E_10305|CAUAJM_E_18984|'
	OSNAMES='windows|linux|'
	directorypath=$(dirname $1)
	filename=$(basename $1)
	deploylog=deploy-$(date +"%Y-%m-%d").log
fi
db $directorypath
db $filename
db $deploylog
}

function usage () {
	echo -e "\nInvalid option: -$OPTARG. " >&2
	echo "Usage 1: $0 -f <<directory path and file name>> -e <<Environment>>"
	echo "Usage 2: $0 -v <<Virtual Machine>> -r <<Real Machine>> -e <<Environment>>"
	echo -e "\n" ;
}

isFile="isFalse"
isBad="isFalse"
isVirtual="isFalse"
isReal="isFalse"

# Checks for Correct Arguments
if [ -z $1 ]
then
   usage
   exit
fi

while getopts "e:f:v:r:o:" opt; do
  case $opt in
    e)  db "Flag -e was triggered, Parameter: $OPTARG" 
		env=$OPTARG
		isENV=true
		;;
    o)  db "Flag -o was triggered, Parameter: $OPTARG"
                osname=$OPTARG
		echo $OSNAMES | grep -o $osname
                isOS=true
                ;;
    f)  db "Flag -f was triggered, Parameter: $OPTARG"
		isFile="isTrue" 
		filedr=$OPTARG
		;;
    v)  db "Flag -v was triggered, Parameter: $OPTARG" 
		if [ $isFile = "isTrue" ]
		then 
		isBad="isTrue" 
		fi
		vmname=$OPTARG
		isVirtual="isTrue"
		;;
    r)  db "Flag -r was triggered, Parameter: $OPTARG" 
		if [ $isFile = "isTrue" ] 
		then 
		isBad="isTrue"
		fi 
		rmname=$OPTARG
		isReal="isTrue"
		;;
    \?)	
		usage
		exit 5
		;;
  esac
done

if [ ! $isENV  ]
then
    echo -e "[-e Environment] flag is required. Options: DEV, PAT and PRD\n" >&2
    exit 5
fi

if [ $isBad = "isTrue" ]
then
    echo -e "[-f File] can not be used with [-v Virtual ] or [ -r Real Machine ]. The flags are mutually exclusive.\n" >&2
    exit 5
fi

if [ $isFile = "isTrue" ]
then
        if [ ! -d $filedr ] && [ ! -f $filedr ]
        then
                echo -e "[-f File] must be followed by a valid directory or a valid file that exists.\n" >&2
                exit 5
        fi
        if [ -f $filedr ]
        then
                variable=$(cat $filedr)
                vmname=$( cut -f 1 -d ' ' <<< $variable)
                rmname=$( cut -f 2 -d ' ' <<< $variable)
                osname=$( cut -f 3 -d ' ' <<< $variable)
                env=$( cut -f 4 -d ' ' <<< $variable)
                db "Contents from the file: $vmname $rmname $osname $env"
        else

                for filename in $filedr/*
                do
                        db "File name in folder: $filename"

                        variable=$(cat $filename)
                        vmname=$( cut -f 1 -d ' ' <<< $variable)
                        rmname=$( cut -f 2 -d ' ' <<< $variable)
                        osname=$( cut -f 3 -d ' ' <<< $variable)
                        env=$( cut -f 4 -d ' ' <<< $variable)

                        db "Contents from the file: $vmname $rmname $osname $env"
                done
        fi
fi

db "Starting"
if [ ! -z $vmname ]; then log "Virtual Machine: $vmname"; fi
if [ ! -z $rmname ]; then log "Real Machine: $rmname"; fi

if [ $isVirtual = "isTrue" ]; then vmname=${vmname^^}; fi	# Virtual Machine name
if [ $isReal = "isTrue" ]; then rmname=${rmname^^}; fi		# Real Machine name

db "Virtual Machine format: $vmname";
db "Real Machine format: $rmname";

# Setting Variables
db "Starting setAppEnvironment"
setAppEnvironment $filedr

#Check Autosys VM exists
db "Starting getVM"
getVM $vmname


if [ $result = $vmname ]
then
	log "Virtual Machine already exist ... adding Real Machine"
	addRealMachine "$rmname" "$osname" "$env"
else
	log "Virtual Machine does not exist ... adding Real Machine"
	addRealMachine "$rmname" "$osname" "$env"
	addVirtualMachine "$vmname" "$rmname" 
fi

log "Reached the end"
