
#**CA Workload Automation Agent**
**CA Workload Automation** includes various types of agents that enable a vast array of workload job types that go well beyond simple executable to allow more efficient design, test, and execution of mission critical workload processes.



[TOC]

#Release Notes
This release 1.0 of the Workload Automation agent provides resources the dynamic capabilities of .  Though this release is not packaged as a certified blueprint, it does provide the core workflows for a new feature in TOSCA blueprints known as types. 

>**Naming Convention:**
WA-AGENT - CA Workload Automation Agent
WAAE - CA Workload Automation Autosys Edition a.k.a Autosys
WASE - CA Workload Automation - CA-7 Edition a.k.a CA-7

##New Functionality
This release of the Workload Automation agent provides the following capabilities on both Linux and Windows operating systems:

 - Installation of the Workload Agent for CA-7 and Autosys 
 - Configuration of the Workload Agent for CA-7 and Autosys 
 - Registration of the Workload Automation Agent with CA-7 or Autosys 
 - Registration of the Virtual Agent with Autosys

#Installation

The diagram below outlines the overall installation of the WA-AGENT.  However, the key difference between the CA7 and Autosys is the registration of the agent with the scheduler.  The WA-AGENT only registers itseif to Autosys scheduling environment.  For CA7, you must contact the  [ITS-EITO-SCHEDULING Services](its-eito-scheduling_services@td.com) team to inform them about the need to register your agent.   

Similar to the TD Certified TOSCA blueprints, there are various inputs that are required to successfully install the agent.  These inputs are accessible either via a _blueprint_ input parameters or set in an _adhoc_ manor locally on the target VM in Saltstack grains. 

##Blueprint / Script Inputs 

 _Scheduler_Client_ 
 :  A role of '_scheduler_client_' must be set to true 

_Scheduler_Type_
 :  A grain of '_scheduler_type_' created and set to one of the values: [ autosys | ca7 ]
 
_Scheduler_Environment_
: A grain of '_scheduler_environment_' created and set to one of the values: [ SIT | PAT | PRD ]    

_Scheduler_Virtual_Agent_
 :  A grain of '_scheduler_virtual_agent_' created and set with a value of your agent alias name e.g: _AGENTALIAS_. The name can contain up to 80 characters.

##Openstack Security Group
To allow your application connectivity between the scheduling environment, the Security Group **SecGroup-CA7_Autosys** must be applied to your VM instance.  Security groups are sets of IP filter rules that are applied to an instance's networking.

##Installation via Script
To install and register the agent, execute the appropriate scripts to initiate the installation.  

> **Important**: Remember to include all the applicable arguments or you may experience issues with your installation.

_Scripts Parameters_

> **Linux** 
./set_saltgrains.sh _Scheduler_Client_" "_Scheduler_Type_" "_Scheduler_Environment_"  "_Scheduler_Virtual_Agent_" 

> **Windows** 
powershell set_saltgrains.ps1 "_Scheduler_Client_" "_Scheduler_Type_" "_Scheduler_Environment_"  "_Scheduler_Virtual_Agent_"



_BASH Script_

> 

Once executed, the script will proceed to set the appropriate Salt grains followed by the launch of the Salt state - _autosys_.  From there, you may observe various output from the individual XXXXX with its results.

On completion, the Salt state will report on the status of the deployment.  A successful completion will result in output similar to the one below:

> 

If errors have occurred, you may choose to rerun the script an additional time.  If further issues still occur, contact your support area. 


##Installation via Blueprint
_work in progress_

##Post Installation
###Outputs
_work in progress_

###Agent Validation
Outside of the scheduling environment i.e. CA7 / Autosys, there are a few areas to check on the status of agent installation and registration.  

 - _Installation Log_ 
 - _agentparm.txt_
 - 
 - 
#Scheduling Your Job Stream
At this point, you are ready to start to scheduling the execution of your scripts and other distributed functions.  If you had previous experience, that's great. Get on your way to scheduling on the Cloud.  However, if you have questions on how to proceed, feel free to contact the [ITS-EITO-SCHEDULING Services](its-eito-scheduling_services@td.com) group for more information.   

#Known Issues
None

----


> Written by Sean Simon.
