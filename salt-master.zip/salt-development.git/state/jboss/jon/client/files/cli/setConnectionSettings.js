/*
       Objective:
       
              This script will set the credentials specified on all of the EAP instances within JON for a given Platform.
              
              This script will also set the following connection parameters:
              
                     trustStrategy                     trustAny
                     hostnameVerification       skip
                     user                              Provided EAP admin user
                     password                          Provided EAP admin user password
                     nativeHost                        127.0.0.1
                     nativeLocalAuth                   true
                     
              This script will also rename the EAP instances in JON to mirror their profile name for multi-instance and mal + "_0000" for standalone.
              
       Usage:
       
              setConnectionSettings.js {Hostname} {MAL} {User} {Password} 
       
       Written by:
  
    martib7 July 2015

*/

function usage() {
  println("Requires {Hostname} {MAL} {User} {Password}");
  throw "Illegal arguments";
}

if( args.length < 4 ) usage();
var hostName = args[0];
var mal = args[1];
var user = args[2];
var password = args[3];


var rc = ResourceCriteria();
rc.addFilterParentResourceName(hostName);
rc.addFilterResourceCategories([ResourceCategory.valueOf("SERVER")]);
rc.addFilterPluginName("JBossAS7");
rc.addFilterResourceTypeName("JBossAS7 Standalone Server");

//Get all the JBossAS resources for specified Platform
var rs = ResourceManager.findResourcesByCriteria(rc);         

println("Setting connection settings for all JBoss AS instances on " + hostName);                                         

//For each resource, get it's Plugin Configuration, make necessary changes.
for (var i=0; i < rs.size(); i++) {
  var conf = ConfigurationManager.getPluginConfiguration(rs.get(i).id);
  var property = new PropertySimple("user",user);
  conf.put(property);
  var property = new PropertySimple("password",password);
  conf.put(property); 
  var property = new PropertySimple("trustStrategy","trustAny");
  conf.put(property);
  var property = new PropertySimple("hostnameVerification","skip");
  conf.put(property);
  var property = new PropertySimple("nativeHost", "127.0.0.1");
  conf.put(property);
  var property = new PropertySimple("nativeLocalAuth", "true");
  conf.put(property);
  ConfigurationManager.updatePluginConfiguration(rs.get(i).id, conf);
  println("  Connection settings set for " + rs.get(i).name + " on " + new java.util.Date().toString());
  var r = rs.get(i);
  var oldname = r.name;
  r.name = conf.get("baseDir").stringValue.split('/').pop();
  
  if (r.name == "standalone") {
    r.name = mal + "_0000";
  } 
    
  ResourceManager.updateResource(r);
  println("  " + oldname + " renamed to " + r.name + " on " + new java.util.Date().toString());
}

