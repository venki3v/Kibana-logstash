/*
  Objective:
  
    This script will set the Permissions on a Role.  Only Roles in DEV are updated.

  Written by:
  
    martib7 April 2015
*/

function usage() {
  println("Requires lobName ENV");
  throw "Illegal arguments";
}

if( args.length < 2 ) usage();
var lobName = args[0];
var env = args[1];

// form role name
var roleName = lobName + "." + env

if (env == "DEV" || env == "PLATFORM") {
  roleName += ".Deployers"
  
  var c = new RoleCriteria();
  c.addFilterName(roleName);
  c.fetchPermissions(true);
  c.fetchBundleGroups(true);
  c.fetchResourceGroups(true);
  c.fetchLdapGroups(true);

  var roles = RoleManager.findRolesByCriteria( c );

  if (roles.size() == 0) {
    println(roleName + " not found.  Role must be created first.");
  } else {
    // add Permissions to Role
  
    var role = roles.get(0);
    
	// permission map
    //role.addPermission(Permission.ASSIGN_BUNDLES_TO_GROUP); 
    //role.addPermission(Permission.CONFIGURE_READ); 
    //role.addPermission(Permission.CONFIGURE_WRITE);
    role.addPermission(Permission.CONTROL); 
    //role.addPermission(Permission.CREATE_BUNDLES); 
    role.addPermission(Permission.CREATE_BUNDLES_IN_GROUP);
    role.addPermission(Permission.CREATE_CHILD_RESOURCES); 
    //role.addPermission(Permission.DELETE_BUNDLES); 
    role.addPermission(Permission.DELETE_BUNDLES_FROM_GROUP);
    //role.addPermission(Permission.DELETE_RESOURCE); 
    //role.addPermission(Permission.DEPLOY_BUNDLES); 
    role.addPermission(Permission.DEPLOY_BUNDLES_TO_GROUP);
    //role.addPermission(Permission.MANAGE_ALERTS); 
    //role.addPermission(Permission.MANAGE_BUNDLE); 
    //role.addPermission(Permission.MANAGE_BUNDLE_GROUPS);
    //role.addPermission(Permission.MANAGE_CONTENT); 
    //role.addPermission(Permission.MANAGE_DRIFT); 
    //role.addPermission(Permission.MANAGE_EVENTS);
    //role.addPermission(Permission.MANAGE_INVENTORY); 
    //role.addPermission(Permission.MANAGE_MEASUREMENTS); 
    //role.addPermission(Permission.MANAGE_REPOSITORIES);
    //role.addPermission(Permission.MANAGE_SECURITY);
    //role.addPermission(Permission.MANAGE_SETTINGS);
    role.addPermission(Permission.MODIFY_RESOURCE);
    //role.addPermission(Permission.UNASSIGN_BUNDLES_FROM_GROUP);
    //role.addPermission(Permission.VIEW_BUNDLES);
    role.addPermission(Permission.VIEW_BUNDLES_IN_GROUP);
    role.addPermission(Permission.VIEW_RESOURCE); 
    role.addPermission(Permission.VIEW_USERS);

    try {
      RoleManager.updateRole(role);
    }
    catch(e) {
	  // Just hiding a potiential exception... I know... I know.  
	  //
	  // There appears to be a bug in the CLI triggered by 1 role
	  // so I need to do this to prevent the Cloud scripts from breaking.
	  //
	  // Everything still works, but a nasty error is thrown:
	  // 
      //  org.jboss.remoting.CannotConnectException: Can not connect http client invoker after 1 attempt(s)
      //  RoleManager.updateRole(role);
	  //  ...
	  //  Caused by: java.lang.NullPointerException
      //    at org.rhq.core.domain.authz.Role.hashCode(Role.java:375)
    }
    println("Deployer permissions added to Role " + roleName + " on " + new java.util.Date().toString())
  } 
} else {
  roleName += ".ReadOnly"
  println("Not a DEV environment.  Read Only access is on the " + roleName + " role by default.  Nothing done.");
}

