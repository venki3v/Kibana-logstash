/*
  Objective:
  
    This script will stop the Agent, remove all Resources assigned to the Agent, and remove the Agent.

  Written by:
  
    martib7 April 2015
*/

function usage() {
  println("Requires hostName ");
  throw "Illegal arguments";
}

if( args.length < 1 ) usage();
var hostName = args[0];

// get agent
var ac = new AgentCriteria();
ac.addFilterName(hostName);

var agents = AgentManager.findAgentsByCriteria(ac);

if (agents.size() == 0) {
  println(hostName + " agent not found.  Is this the hostname used in JON?"); } else {
  // agent to delete
  var agent = agents.get(0);

  // stop agent - need to get Agent Resource
  var rc = new ResourceCriteria();
  rc.addFilterParentResourceName(hostName);
  rc.addFilterResourceTypeName("RHQ Agent");

  var ragents = ResourceManager.findResourcesByCriteria(rc);

  // assuming only 1 Agent will be returned.
  if(ragents.size() == 0) {
    println("Agent Resource not found for " + hostName);
  }
  else {
    // shutdown Agent.
    var ragent = ProxyFactory.getResource(ragents.get(0).id)
    ragent.shutdownAgent();
  }
  
  var logFile = 'delAgent.error.log';
  var exp = exporter;
  
  exp.setTarget( 'raw', logFile );
  
  // uninventory all resources and remove Agent.
  var counter = 1;
  var complete = false;
  
  while(complete != true) {
    try {
      ResourceManager.uninventoryAllResourcesByAgent(agent);
      complete = true;
    } 
    catch(e) {
      exp.write(e);
      println(" Error encountered during ResourceManager.uninventoryAllResourcesByAgent().  Sleeping 15 seconds and trying again.");
    }
    finally {
      if(complete == false) {   
        java.lang.Thread.sleep(15000);
        counter++;
      }
    }
    if(counter > 5) {
      println("Breaking loop.  Unable to uninventory resources.  Please take a look at delAgent.error.log.");
      break;
    }
  }
}

// sleep for 10 seconds to ensure the resources have time to uninventory.
println("Sleeping for 10 seconds to allow uninventory call to finish.");
java.lang.Thread.sleep(10000);
  
// this AgentManager.deleteAgent() function doesn't always work the first try.
// looping the logic to ensure the agent is removed.
counter = 1;
  
while(agents.size() != 0) {
  println(" Attempt #" + counter + " to delete agent for " + hostName);
  try {
    AgentManager.deleteAgent(agents.get(0));
  }
  catch(e) {
    exp.write(e);
  }
  finally {
    agents = AgentManager.findAgentsByCriteria(ac);
    counter++;
    if(counter > 5) {
      println("Breaking loop.  This agent wants to live.  Take a look at the delAgent.error.log.");
      break;
    }
    java.lang.Thread.sleep(5000);
  }
}

println(hostName + " agent deleted " + new java.util.Date().toString());

