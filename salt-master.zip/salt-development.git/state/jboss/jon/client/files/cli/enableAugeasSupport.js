/*
	Objective:
	
		This script will enable Augeas support for all Apache instances on the specified EWS server within JON.
		
	Usage:
	
		enableAugeasSupport.js {Hostname}
	
	Written by:
  
    martib7 May 2015

*/

function usage() {
  println("Requires {Hostname}");
  throw "Illegal arguments";
}

if( args.length < 1 ) usage();
var hostName = args[0];

var rc = ResourceCriteria();
rc.addFilterParentResourceName(hostName);
rc.addFilterResourceCategories([ResourceCategory.valueOf("SERVER")]);
rc.addFilterPluginName("Apache");
rc.addFilterResourceTypeName("Apache HTTP Server");

var rs = ResourceManager.findResourcesByCriteria(rc);

println("Enabling Augeas support for all Apache instances on " + hostName);

//For each resource, get it's Configuration, enable Augeas support and update the Plugin Configuration
for (var i=0; i < rs.size(); i++) {
  var conf = ConfigurationManager.getPluginConfiguration(rs.get(i).id);
  var property = new PropertySimple("augeasEnabled","yes");
  conf.put(property);
  ConfigurationManager.updatePluginConfiguration(rs.get(i).id, conf);
  println("  Augeas support enabled for " + rs.get(i).name + " on " + new java.util.Date().toString());
}