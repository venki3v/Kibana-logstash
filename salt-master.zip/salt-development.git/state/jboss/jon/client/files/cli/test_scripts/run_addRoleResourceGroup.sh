#!/bin/bash

# Wrote this wrapper script because it's an ugly command.
#  martib7

/opt/rhq-remoting-cli-4.12.0.JON330GA/bin/rhq-cli.sh -u rhqadmin -p rhqadmin -s jon01.mgmt1.cloud.td.com -t 7443 -f /opt/scripts/provisioning/application/addRoleResourceGroup.js TDCT DEV TDCT-CSD_CLK_SYS-F4_Application
