/*
  Objective:
  
    This script will add a Bundle Group to a Role.

  Written by:
  
    martib7 April 2015
*/

function usage() {
  println("Requires lobName ENV");
  throw "Illegal arguments";
}

if( args.length < 2 ) usage();
var lobName = args[0];
var env = args[1];

// form role name
var roleName = lobName + "." + env

if (env == "DEV") {
  roleName += ".Deployers"
} else {
  roleName += ".ReadOnly"
}

var c = new RoleCriteria();
c.addFilterName(roleName);
c.fetchPermissions(true);
c.fetchBundleGroups(true);
c.fetchResourceGroups(true);
c.fetchLdapGroups(true);

var roles = RoleManager.findRolesByCriteria( c );

if (roles.size() == 0) {
  println(roleName + " not found.  Role must be created first.");
} else {
  // add BundleGroup to Role
  bgc = new BundleGroupCriteria();
  bgc.addFilterName(lobName);

  var bgs = BundleManager.findBundleGroupsByCriteria(bgc);
  
  if (bgs.size() == 0) {
    println(lobName + " BundleGroup not found.  BundleGroup must be created first.");
  } else {
    RoleManager.addBundleGroupsToRole(roles.get(0).id,[bgs.get(0).id]);
	println(lobName + " added to Role " + roleName + " on " + new java.util.Date().toString())
  }
}

