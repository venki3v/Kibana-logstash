/*
  Objective:
  
    This script will check for the existance of a Bundle group in JON.  If it doesn't exist
	then this script will create it.
	
  Written by:
  
    martib7 April 2015
*/

function usage() {
  println("Requires a groupName parameter");
  throw "Illegal arguments";
}

if( args.length < 1 ) usage();
var groupName = args[0];

groupcriteria = new BundleGroupCriteria();
groupcriteria.addFilterName(groupName);

var groups = BundleManager.findBundleGroupsByCriteria(groupcriteria);

if( groups != null ) {
  if( groups.size() > 0 ) {
    println("BundleGroup " + groupName + " already exists.  Nothing done.");
  }
  else if( groups.size() == 0) {
    var bg = new BundleGroup();
    bg.setName(groupName);
    // bg.setDescription("Created via Cloud provisioning automation scripts on " + new java.util.Date().toString()); 
    bg = BundleManager.createBundleGroup(bg);

    println("BundleGroup " + groupName + " created " + new java.util.Date().toString());
  }
}
