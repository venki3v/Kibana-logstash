/*
  Objective:
  
    This script will add the specified EAP instance(s) on a specified host to the specified group.

  By:
  
    martib7 May 2015
*/

function usage() {
  println("Requires hostName groupName resourceName");
  throw "Illegal arguments";
}
if( args.length < 3 ) usage();
var hostName = args[0];
var groupName = args[1];
var resourceName = args[2];

groupcriteria = new ResourceGroupCriteria();
groupcriteria.addFilterName(groupName);
var groups = ResourceGroupManager.findResourceGroupsByCriteria(groupcriteria);
var group = "";

if( groups.size() > 0 ) {
  group = groups.get(0);
}
else {
  println("Group not found.");
}

var rc = ResourceCriteria();
rc.addFilterParentResourceName(hostName);
rc.addFilterResourceCategories([ResourceCategory.valueOf("SERVER")]);
rc.addFilterPluginName("JBossAS7");
rc.addFilterResourceTypeName("JBossAS7 Standalone Server");
rc.addFilterName(resourceName);

var rs = ResourceManager.findResourcesByCriteria(rc);

if( rs.size() > 0 ) {
  println("Resource(s) found.  Attempting to add to group");
  for( i = 0; i < rs.size(); ++i) {
    var resource = rs.get(i);
    println("  " + resource.name + " found. Trying to add to " + group.name);
       ResourceGroupManager.addResourcesToGroup(group.id,[resource.id]);
    println("  " + resource.name + " added to " + group.name + " on " + new java.util.Date().toString());
  }
}
else {
  println("Did not find any resources. It's possible it hasn't been imported from the Discovery queue yet.");
}

