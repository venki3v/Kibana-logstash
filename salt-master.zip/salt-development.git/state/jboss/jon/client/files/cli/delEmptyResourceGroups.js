/*
  Objective:
  
    This script will delete all of the empty Resource Groups.
	
	NOTE:	A bug exists in JON where Resource Groups attached to multiple Bundle Deployments 
			cannot be removed through the CLI.  The Bundle Deployments must be removed prior to 
			this script being able to remove the Resource Groups cleanly.
			
			https://access.redhat.com/support/cases/#/case/01449930
 
  By:
  
    martib7 May 2015
*/


var rgc = new ResourceGroupCriteria();
rgc.fetchGroupDefinition(true);
rgc.fetchExplicitResources(true);
rgc.addFilterRecursive(true);

var rgs = ResourceGroupManager.findResourceGroupsByCriteria(rgc);

var logFile = 'delEmptyResourceGroups.error.log';
var exp = exporter;
  
exp.setTarget( 'raw', logFile )

// loop through all Resource Groups and attempt to delete empty ones.
for( i = 0; i < rgs.size(); ++i) {
  var rg = rgs.get(i);
  if( rg.explicitResources.size() == 0 ) {
	println(rg.name + " is empty. Checking for Bundle Destinations.");
	
	// checking for Bundle Destinations.
	var bdc = new BundleDestinationCriteria();
	bdc.addFilterGroupId(rg.id);
	bdc.fetchBundle(true);
	bdc.fetchGroup(true);
	var bds = BundleManager.findBundleDestinationsByCriteria(bdc);
	if( bds != null && bds.size() > 0 ) {
	  println("Bundle Destinations to " + rg.name + " found:");
	  // currently no way to delete Bundle Destinations via the CLI
	  // this could prevent the Resource Group from being deleted.
	  for( c = 0; c < bds.size(); ++c) {
		var bd = bds.get(c);
		var bgc = new BundleGroupCriteria();
		bgc.addFilterBundleIds(bd.bundle.id); 
		// should always return 1 Bundle Group
		var bgs = BundleManager.findBundleGroupsByCriteria(bgc);
		var bg = bgs.get(0);
		println("  Bundle Group: " + bg.name + "\n  Bundle Name: " + bd.bundle.name + "\n  Destination: " + bd.name + "\n ***Please manually remove this Destination through the GUI***");
	  } 
	}
	else {
	  println("No Bundle Destinations to " + rg.name + " found.  Group can be deleted cleanly.");
	}
	try {
	  ResourceGroupManager.deleteResourceGroup(rg.id);
	  println("  " + rg.name + " deleted " + new java.util.Date().toString());
    }
	catch(e) {
	  // there is a known bug when trying to remove Resource Groups that have more than 1
	  // Bundle version deployed https://bugzilla.redhat.com/show_bug.cgi?id=1206084
	  println("Problem deleting " + rg.name);
	  exp.write(e);
	}
  }
}
