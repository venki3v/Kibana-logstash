/*
  Objective:
  
    This script will locate the Agent in JON for this server and trigger a Discovery scan.
 
  By:
  
    martib7 April 2015
*/

function usage() {
  println("Requires a resourceName (hostname) parameter");
  throw "Illegal arguments";
}
if( args.length < 1 ) usage();
var resourceName = args[0];
var resourceTypeName = "RHQ Agent"

criteria = new ResourceCriteria();
criteria.addFilterParentResourceName(resourceName);
criteria.addFilterResourceTypeName(resourceTypeName);
var agents = ResourceManager.findResourcesByCriteria(criteria);

//  assuming only 1 Agent will be returned.
if( agents != null ) {
  
  var resource = agents.get(0);
  var agent = ProxyFactory.getResource(resource.id)
  println("Triggering discovery on:");
  println("  " + agent.name + " running on " + resourceName );
  agent.executePromptCommand("discovery");
   
  var opcrit = ResourceOperationHistoryCriteria();
  opcrit.addFilterResourceIds(resource.id);
  opcrit.fetchResults(true); // request the additional optional data in the result
  opcrit.addSortStartTime(PageOrdering.DESC); // sort by start time
  
  java.lang.Thread.sleep(2000); // wait a 2 seconds to make sure operation is in the history

// wait for up to 30 seconds for last operation to complete, then print result

  var now = new Date().getTime();
  
  while (new Date().getTime() - now < 30000 ) {
    operations = OperationManager.findResourceOperationHistoriesByCriteria(opcrit);
    
	if (operations.get(0).getResults() == null) {
      println("operation still pending result");
      java.lang.Thread.sleep(3000);
    } 
	else {
      pretty.print(operations.get(0));
	  var d = new Date(operations.get(0).createdTime);
	  println("Discovery trigged: " + d)
	  println("Waiting 45 seconds for Discovery scan to finish.")
	  java.lang.Thread.sleep(45000);
      break;
    }

    if (operations.get(0).getErrorMessage() != null) {
      println("Error getting process list: ");
      pretty.print(operations.get(0).getErrorMessage());
    }
    else {
      pretty.print(operations.get(0));
	  var d = new Date(operations.get(0).createdTime);
	  println("Discovery trigged: " + d)
	  println("Waiting 45 seconds for Discovery scan to finish.")
	  java.lang.Thread.sleep(45000);
      break;
    }
  }
}
else {
  println("Did not find Agent.  Please ensure the Agent has registered with JON.");
}
