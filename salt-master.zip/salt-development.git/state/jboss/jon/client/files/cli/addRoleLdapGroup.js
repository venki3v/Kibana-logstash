/*
  Objective:
  
    This script will add an Active Directory Group to a Role.

  Written by:
  
    martib7 April 2015
*/

function usage() {
  println("Requires lobName ENV accessGroup");
  throw "Illegal arguments";
}

if( args.length < 3 ) usage();
var lobName = args[0];
var env = args[1];
var accessGroup = args[2];

// form role name
var roleName = lobName + "." + env

if (env == "DEV") {
  roleName += ".Deployers"
} else {
  roleName += ".ReadOnly"
}

var c = new RoleCriteria();
c.addFilterName(roleName);
c.fetchPermissions(true);
c.fetchBundleGroups(true);
c.fetchResourceGroups(true);
c.fetchLdapGroups(true);

var roles = RoleManager.findRolesByCriteria( c );

if (roles.size() == 0) {
  println(roleName + " not found.  Role must be created first.");
} else {
  // add AD Group to Role
  var adg = new LdapGroup();
  adg.setName(accessGroup);
  
  var role = roles.get(0);
  //pretty.print(role);
  role.addLdapGroup(adg);
  
  try {
    RoleManager.updateRole(role);
  }
  catch(e) {
      // Just hiding a potiential exception... I know... I know.  
	  //
	  // There appears to be a bug in the CLI triggered by 1 role
	  // so I need to do this to prevent the Cloud scripts from breaking.
	  //
	  // Everything still works, but a nasty error is thrown:
	  // 
      //  org.jboss.remoting.CannotConnectException: Can not connect http client invoker after 1 attempt(s)
      //  RoleManager.updateRole(role);
	  //  ...
	  //  Caused by: java.lang.NullPointerException
      //    at org.rhq.core.domain.authz.Role.hashCode(Role.java:375)
  }
  println(accessGroup + " added to Role " + roleName + " on " + new java.util.Date().toString())
}

