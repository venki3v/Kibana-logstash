/*
  Objective:
  
    This script will check for the existance of a group in JON.  If it doesn't exist
	then this script will create it.
	
  Written by:
  
    martib7 April 2015
*/

function usage() {
  println("Requires groupName");
  throw "Illegal arguments";
}

if( args.length < 1 ) usage();
var groupName = args[0];

groupcriteria = new ResourceGroupCriteria();
groupcriteria.addFilterName(groupName);

var groups = ResourceGroupManager.findResourceGroupsByCriteria(groupcriteria);

if( groups != null ) {
  if( groups.size() > 0 ) {
    println("Group " + groupName + " already exists.  Nothing done.");
  } 
  else if( groups.size() == 0) {
    var resType = ResourceTypeManager.getResourceTypeByNameAndPlugin("Platforms","Linux");

    var rg = new ResourceGroup(resType);
    rg.setRecursive(true);
    // rg.setDescription("Created via Cloud provisioning automation scripts on " + new java.util.Date().toString());
    rg.setName(groupName);
    rg = ResourceGroupManager.createResourceGroup(rg);
    println("Group " + groupName + " created " + new java.util.Date().toString());
  }
}  





