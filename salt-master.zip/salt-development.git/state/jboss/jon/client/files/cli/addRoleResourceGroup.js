/*
  Objective:
  
    This script will add a Resource Group to a Role.

  Written by:
  
    martib7 April 2015
*/

function usage() {
  println("Requires lobName ENV ResourceGroup ");
  throw "Illegal arguments";
}

if( args.length < 3 ) usage();
var lobName = args[0];
var env = args[1];
var resourceGroup = args[2];

// form role name
var roleName = lobName + "." + env

if (env == "DEV") {
  roleName += ".Deployers"
} else {
  roleName += ".ReadOnly"
}

var c = new RoleCriteria();
c.addFilterName(roleName);
c.fetchPermissions(true);
c.fetchBundleGroups(true);
c.fetchResourceGroups(true);
c.fetchLdapGroups(true);

var roles = RoleManager.findRolesByCriteria( c );

if (roles.size() == 0) {
  println(roleName + " not found.  Role must be created first.");
} else {
  // add ResourceGroup to Role
  rgc = new ResourceGroupCriteria();
  rgc.addFilterName(resourceGroup);
  var rgs = ResourceGroupManager.findResourceGroupsByCriteria(rgc);
  
  if (rgs.size() == 0) {
    println(resourceGroup + " not found.  ResourceGroup must be created first.");
  } else {
    RoleManager.addResourceGroupsToRole(roles.get(0).id,[rgs.get(0).id]);
	println(resourceGroup + " added to Role " + roleName + " on " + new java.util.Date().toString())
  }
}

