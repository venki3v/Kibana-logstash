/*
  Objective:
  
    This script will check for the existance of a LOB Role in JON.  If it doesn't exist
	then this script will create it.

	Naming convention:
	
	  DEV or PLATFORM:
	  
	    {lobName}.DEV.Deployers
	  
	  Non-DEV:
	
	    {lobName}.{ENV}.ReadOnly
	
  Written by:
  
    martib7 April 2015
*/

function usage() {
  println("Requires lobName ENV");
  throw "Illegal arguments";
}

if( args.length < 2 ) usage();
var lobName = args[0];
var env = args[1];

// form role name
var roleName = lobName + "." + env

if (env == "DEV" || env == "PLATFORM") {
  roleName += ".Deployers"
} else {
  roleName += ".ReadOnly"
}

//  check is role exists - create if it doesn't.
var c = new RoleCriteria();
c.addFilterName(roleName);

var roles = RoleManager.findRolesByCriteria( c );

if (roles.size() != 0) {
  println(roleName + " already exists.  Nothing done.");
} else {
  var role = Role(roleName);
  RoleManager.createRole(role);
  println(roleName + " created " + new java.util.Date().toString())
}
