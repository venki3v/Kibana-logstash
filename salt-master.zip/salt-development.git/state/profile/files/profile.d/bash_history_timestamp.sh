export HISTTIMEFORMAT="[%d %b %T] "
export HISTIGNORE="history*:ls:[bf]g:exit"
shopt -s histappend

function search {
#  echo "Searching for [" $2 "] in files [" $1 "]"
#  cmd="find -name '$1' | xargs grep $2"
#  cmd="find . -name '$1' -exec grep -H '$2' {} \;"
  cmd="grep -R --include='$1' '$2' ."
  echo $cmd
  eval $cmd
}
