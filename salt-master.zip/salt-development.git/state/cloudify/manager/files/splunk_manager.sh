#!/bin/bash

# Enable RabbitMQ trace to file (JSON)
curl -i -u guest:guest -H "content-type:application/json" -XPUT  http://localhost:15672/api/traces/%2f/all -d'{"format":"json","pattern":"#"}' 

# Monitor the RabbitMQ trace
/opt/splunkforwarder/bin/splunk add monitor /var/tmp/rabbitmq-tracing/all.log -index main -sourcetype storm:cloudify:rabbitmq -auth admin:admin
