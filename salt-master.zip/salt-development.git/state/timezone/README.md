Timezone
========

Sets the timezone on RedHat 6.X servers.