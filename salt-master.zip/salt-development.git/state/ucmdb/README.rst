HP UCMDB Clientless Agent
=========================

Description:
~~~~~~~~~~~~
UCMDB is a CMDB and discovery (combining DDMA and DDMI technique) software product produced by Hewlett Packard
supporting ITIL Configuration Management and which features a Configuration Management Database, as well as a
mechanism for the automatic discovery of IT infrastructure components, such as computers, network devices and composing
relationships between them.

This formula applies state to the ucmdb user, group, and public sshkey.

Notes:
~~~~~~
When running the websphere formula need to reapply this state
so that the pcfmapp user gets added to the wasadm group.

Supported Operating Systems:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- RedHat

Key contacts:
~~~~~~~~~~~~~
- Technical: Masood, Akmal <Akmal.Masood@td.com>
- Manager: Bhangari, Cindy <cindy.bhangari@td.com>
- Operational: Novak, Suzanne <Suzanne.Novak@td.com>