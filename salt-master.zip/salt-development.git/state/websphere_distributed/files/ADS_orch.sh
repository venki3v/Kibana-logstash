#!/bin/sh
#set -x

# TO DO - add logging for ADS_orch script

#----------------------------------
# version history
#
# initial draft (Phase 1 ADS project, 2014) - B. Cosentino
#ADSORCHVER='v2014-02-01'
# support for wrapper app:
# - 'package_info' functions added which generates ADS info, J2C info, amd manual instructions info
# - added 'list_environments' function
#ADSORCHVER='v2014-02-28'
# added support for stand-alone WAS Control commands
# added logic for exporting TDWCC cred removal at appropriate times
#ADSORCHVER='v2014-05-14'
# organised list_envirojnments so that DEV first, then sit/sys, etc...
#ADSORCHVER='v2014-05-30'
# added support for IHS (handle_IHS)
# cleaned up functions open_ADS, match_environment, get_environment_info
# (moved get_cell_info to get_environment_info)
ADSORCHVER='v2014-07-04'
# added error handling support for IHS Control
# changed manual instructions to support and file extension (not just *.properties)
# cleaned up find_server_environment
# cleaned up match_environment to support more descriptive environment names
# changed handle_J2C to be same handle_manual
# added code to handle iHUB WAS servers
export ADSORCHVER


#----------------------------------
# GLOBALS
#
EXECUTOR=$(who -m | awk '{print $1}')
ADS_PACKAGE=$1
ADS_PACKAGE_TYPE=$2
TD_ENV=$3
export ADS_FUNCTION=$4
LOCAL_HOST=$(uname -n)
ADS_EPOCH=$(date -u +%s)
ADS_TEMP_DIR=/td/work1/ADS_${ADS_EPOCH}
START_DIR=$(pwd)
# TO DO - change from beta to regular version once ADS automation pilot and 2nd phase complete
#WAS_CONTROL_SHELL=/td/mw/mnt/wascontrol_beta/bin/was_control.sh
#WAS_CONTROL_SHELL=/webAS/installedApps/Automation.EAR/wascontrol_beta/bin/was_control.sh
WAS_CONTROL_SHELL=/td/mgmt/middleware/wascontrol/bin/was_control.sh
WAS_CONTROL_MIN_VERSION=20140131
WAS_BASE_PATH=/usr/opt/WebSphere*/AppServer/java
#IHS_CONTROL_PACKAGE=/td/mw/mnt/wascontrol_properties/ADS_automation/IHS_Control/
IHS_CONTROL_PACKAGE=/webAS/installedApps/Automation.EAR/ADS_automation/IHS_Control/
TOMCATAPACHE_PACKAGE=/webAS/installedApps/Automation.EAR/ADS_automation/TomcatApache 
#need to get the absolute PATH to call HPOO_Handler.sh
ADS_ORCH_DIR=`dirname $0`



#----------------------------------
# function cleanup
#
function cleanup {
	#set -x
	# TO DO - cleanup exit codes from other areas of the script
	# TO DO - print WIKI link as part of exit
	ADS_ERROR_CODE=$1
	ADS_ERROR_MESSAGE=$2
	echo "************************************************"
	echo
	cd ${START_DIR}
	if [[ -d ${ADS_TEMP_DIR} ]]
	then
		echo "Removing temporary ADS files..."
		rm -fr ${ADS_TEMP_DIR}
		echo
	fi
	if [[ ${ADS_ERROR_CODE} -ne 0 ]]
	then
		echo "ADS_orch ERROR ${ADS_ERROR_CODE}: ${ADS_ERROR_MESSAGE}.  Exiting."
		echo
		exit ${ADS_ERROR_CODE}
	else
		echo ${ADS_ERROR_MESSAGE}
		echo
		exit 0
	fi
	}


#----------------------------------
# generic authentication function
# (not used at his time)
#
function authenticate {
	AUTH_TYPE=$1
	trap 'stty echo;echo;cleanup;exit' INT TERM KILL ILL SEGV HUP ABRT QUIT
	echo
	echo "Please enter ${AUTH_TYPE} credentials:"
	echo
	echo "Username [${EXECUTOR}]: \c"
	read U
	if [[ -n $U ]]
	then
		ADS_USER=${U}
	else
		ADS_USER=${EXECUTOR}
	fi
	PADDING=$(echo ${EXECUTOR} | tr '[:alnum:]' '[ *]')
	stty -echo
	echo "${PADDING}   Password: \c"
	read P
	stty echo
	if [[ -n $P ]]
	then
		ADS_PASS=${P}
	fi
	echo
	echo
	}


#----------------------------------
# open ADS package
#
function open_ADS_package {
	#set -x
	echo "************************************************"
	echo
	echo "Opening ADS package ${ADS_PACKAGE}...\c"
	if [[ $(echo ${ADS_PACKAGE} | cut -c1) == "/" ]]
	then
		FULL_PATH_TO_ADS_PACKAGE=${ADS_PACKAGE}
	else
		FULL_PATH_TO_ADS_PACKAGE=${START_DIR}/${ADS_PACKAGE}
	fi
	mkdir -p ${ADS_TEMP_DIR}
	cd ${ADS_TEMP_DIR}
	if [[ -r ${FULL_PATH_TO_ADS_PACKAGE} && ! -d ${FULL_PATH_TO_ADS_PACKAGE} ]]
	then
		JAR_COMMAND=/usr/opt/WebSphere855/AppServer/java/bin/jar
		${JAR_COMMAND} -xf ${FULL_PATH_TO_ADS_PACKAGE}
		echo "done."
		echo
	elif [[ -d ${FULL_PATH_TO_ADS_PACKAGE} ]]
	then	
		cp -pR ${FULL_PATH_TO_ADS_PACKAGE}/* .
		echo "done."
		echo
	else
		cleanup	4 "${FULL_PATH_TO_ADS_PACKAGE} does not exist.\nPlease ensure 1st argument is either:
		- a readable zip file export from the ADS spreadsheet
		- a readable directory structure containg the contents of the ADS zip file"
	fi
	PACKAGE_INFO_FILE=${ADS_TEMP_DIR}/ADS_info.txt
	if [[ ! -f ${PACKAGE_INFO_FILE} ]]
	then
		echo
		echo
		cleanup 5 "'${PACKAGE_INFO_FILE}' file was not found in the '${ADS_PACKAGE}' ADS package"
	else
		echo "Package Information:"
		echo
		if [[ ${ADS_FUNCTION} == "list_environments" || ${ADS_FUNCTION} == "package_info" ]]
		then
			INFO_COUNTER=0
			while read LINE
			do
				echo ${LINE} | sed -e 's/^\(.*\)/ADS_ENV_ADS_INFO_'${INFO_COUNTER}' \1/g'
				let INFO_COUNTER=${INFO_COUNTER}+1
			done < "${PACKAGE_INFO_FILE}"
		else
			cat < ${PACKAGE_INFO_FILE} | sed -e 's/\(.*\)/     \1/g'
		fi
		echo
	fi
	if [[ ${ADS_FUNCTION} == "list_environments" ]]
	then
		echo "************************************************"
		echo
		echo "Environments for ${ADS_PACKAGE_TYPE}:"
		echo
		ENV_COUNTER=0
		ADS_ENVS=$(ls -l ${ADS_PACKAGE_TYPE}/ | grep ^d | awk '{print $9}')
		for i in $(ls -l ${ADS_PACKAGE_TYPE}/ | grep ^d | awk '{print $9}' | grep -i dev)
		do
			echo ADS_ENV_${ENV_COUNTER} ${i}
			let ENV_COUNTER=${ENV_COUNTER}+1
		done
		for i in $(ls -l ${ADS_PACKAGE_TYPE}/ | grep ^d | awk '{print $9}' | grep -iE "sit|sys")
		do
			echo ADS_ENV_${ENV_COUNTER} ${i}
			let ENV_COUNTER=${ENV_COUNTER}+1
		done
		for i in $(ls -l ${ADS_PACKAGE_TYPE}/ | grep ^d | awk '{print $9}' | grep -i bat)
		do
			echo ADS_ENV_${ENV_COUNTER} ${i}
			let ENV_COUNTER=${ENV_COUNTER}+1
		done
		for i in $(ls -l ${ADS_PACKAGE_TYPE}/ | grep ^d | awk '{print $9}' | grep -iE "pat|perf")
		do
			echo ADS_ENV_${ENV_COUNTER} ${i}
			let ENV_COUNTER=${ENV_COUNTER}+1
		done
		for i in $(ls -l ${ADS_PACKAGE_TYPE}/ | grep ^d | awk '{print $9}' | grep -iE "prod|soc|cpo|bdc")
		do
			echo ADS_ENV_${ENV_COUNTER} ${i}
			let ENV_COUNTER=${ENV_COUNTER}+1
		done
		for i in $(ls -l ${ADS_PACKAGE_TYPE}/ | grep ^d | awk '{print $9}' | grep -viE "dev|sit|sys|bat|pat|perf|prod|soc|cpo|bdc")
		do
			echo ADS_ENV_${ENV_COUNTER} ${i}
			let ENV_COUNTER=${ENV_COUNTER}+1
		done
		echo
		cleanup 0 "ADS_orch.sh script completed."
	fi
	PACKAGE_LOCATION=${ADS_TEMP_DIR}/${ADS_PACKAGE_TYPE}/${TD_ENV}
	if [[ ! -d ${PACKAGE_LOCATION} ]]
	then
		cleanup 5 "'${TD_ENV}' environment was not found in the '${ADS_PACKAGE}' ADS package"
	fi
	}


#----------------------------------
# find server env
#
function find_server_environment {
	#set -x
	SERVER=$(echo $1 | tr "[A-Z]" "[a-z]")
	SERVER=$(echo ${SERVER} | cut -f1 -d.)
	#SERVER_NAME_LENGTH=$(echo ${SERVER} | wc -c | awk '{print $1}')
	SERVER_NAME_LENGTH=$(echo ${SERVER}'\c' | wc -c | awk '{print $1}')
	#SERVER_NAME_LENGTH=$(echo ${SERVER}'\c' | wc -c | awk '{print $1}')
	SERVER_FIRST_LETTER=$(echo ${SERVER} | cut -c1)
	SERVER_FIRST_TWO_LETTERS=$(echo ${SERVER} | cut -c-2)
	#((ENV_LETTER_POSITION=${SERVER_NAME_LENGTH}-3))
	((ENV_LETTER_POSITION=${SERVER_NAME_LENGTH}-2))
	ENV_LETTER=$(echo ${SERVER} | cut -c${ENV_LETTER_POSITION})
	#ENV_LETTER=$(echo ${SERVER}'\c' | cut -c${ENV_LETTER_POSITION})
	#((ENV_DIGIT_POSITION=${SERVER_NAME_LENGTH}-2))
	((ENV_DIGIT_POSITION=${SERVER_NAME_LENGTH}-1))
	ENV_DIGIT=$(echo ${SERVER} | cut -c${ENV_DIGIT_POSITION})
	if [[ ${SERVER_NAME_LENGTH} -eq 8 ]]
	then
		if [[ ${SERVER_FIRST_LETTER} == "k" ]]
		then
			SERVER_ENV=prePAT
		elif [[ ${SERVER_FIRST_LETTER} == "d" ]]
		then
			SERVER_ENV=prePAT
		elif [[ ${SERVER_FIRST_LETTER} == "s" ]]
		then
			SERVER_ENV=prePAT
		elif [[ ${SERVER_FIRST_LETTER} == "u" ]]
		then
			SERVER_ENV=PATPERF
		elif [[ ${SERVER_FIRST_LETTER} == "c" ]]
		then
			if [[ ${ENV_LETTER} == "t" ]]
			then
				SERVER_ENV=PATPERF
			fi
		elif [[ ${SERVER_FIRST_LETTER} == "p" ]]
		then
			if [[ ${ENV_DIGIT} -eq 3 ]]
			then
				SERVER_ENV=PROD-SOC
			elif [[ ${ENV_DIGIT} -eq 4 ]]
			then
				SERVER_ENV=PROD-CPO
			fi
		elif [[ ${SERVER_FIRST_TWO_LETTERS} == "ec" ]]
		then
			if [[ ${ENV_DIGIT} -eq 2 ]]
			then
				#SERVER_ENV=PAT
				SERVER_ENV=PATPERF
			elif [[ ${ENV_DIGIT} -eq 3 ]]
			then
				SERVER_ENV=PROD-SOC
			elif [[ ${ENV_DIGIT} -eq 4 ]]
			then
				SERVER_ENV=PROD-CPO
			fi
		fi
	elif [[ ${SERVER_FIRST_TWO_LETTERS} == "cp" ]]
	then
		if [[ ${SERVER_NAME_LENGTH} -le 8 ]]
		then
			SERVER_ENV=PROD-CPO
		elif [[ ${SERVER_NAME_LENGTH} -gt 8 ]]
		then
			if [[ ${ENV_LETTER} == "k" || ${ENV_LETTER} == "b" ]]
			then
				SERVER_ENV=prePAT
			elif [[ ${ENV_LETTER} == "v" ]]
			then
				SERVER_ENV=prePAT
			elif [[ ${ENV_LETTER} == "s" ]]
			then
				SERVER_ENV=prePAT
			elif [[ ${ENV_LETTER} == "t" ]]
			then
				SERVER_ENV=PATPERF
			elif [[ ${ENV_LETTER} == "p" ]]
			then
				SERVER_ENV=PROD-CPO
			else 
				SERVER_ENV=PROD-CPO
			fi
		else
			SERVER_ENV=PROD-CPO
		fi
	elif [[ ${SERVER_FIRST_TWO_LETTERS} == "sc" ]]
	then
		SERVER_ENV=PROD-SOC
	elif [[ ${SERVER_FIRST_TWO_LETTERS} == "ba" ]]
	then
		SERVER_ENV=PROD-BDC
	elif [[ ${SERVER_FIRST_TWO_LETTERS} == "wa" && ${SERVER_NAME_LENGTH} -eq 5 ]]
	then
		#this branch is just to handle iHub project
		ENV_LETTER=$(echo ${SERVER} | cut -c${SERVER_NAME_LENGTH}-${SERVER_NAME_LENGTH})
		if [[ ${ENV_LETTER} == "v" ]]
		then
			SERVER_ENV=PROD-BDC
		elif [[ ${ENV_LETTER} == "w" ]]
		then
			SERVER_ENV=PATPERF
		else
			SERVER_ENV=prePAT
		fi
		
	else
		SERVER_ENV="UNIDENTIFIED_TD_ENVIRONMENT"
	fi
	echo ${SERVER_ENV}
	}


#----------------------------------
# match environment
#
function match_environment {
	#set -x
	echo "************************************************"
	echo
	ADS_TD_ENV=$(echo ${TD_ENV} | tr '-' '_' | cut -d_ -f-2 | tr -cd '[[:alpha:]]')
	ADS_TD_ENV_FIRST_THREE_LETTERS=$(echo ${ADS_TD_ENV} | cut -c-3)
	ADS_TD_ENV_FIRST_FOUR_LETTERS=$(echo ${ADS_TD_ENV} | cut -c-4)
	ADS_TD_ENV_FIRST_SEVEN_LETTERS=$(echo ${ADS_TD_ENV} | cut -c-7)
	if [[ ${ADS_TD_ENV_FIRST_THREE_LETTERS} == "DEV" || ${ADS_TD_ENV_FIRST_THREE_LETTERS} == "BAT" || ${ADS_TD_ENV_FIRST_THREE_LETTERS} == "SIT" || ${ADS_TD_ENV_FIRST_THREE_LETTERS} == "SYS" ]]
	then
		ADS_TD_ENV=prePAT
	elif [[ ${ADS_TD_ENV_FIRST_THREE_LETTERS} == "PAT" || ${ADS_TD_ENV_FIRST_FOUR_LETTERS} == "PERF" || ${ADS_TD_ENV_FIRST_THREE_LETTERS} == "EPT" || ${ADS_TD_ENV_FIRST_THREE_LETTERS} == "PRF" ]]
	then
		ADS_TD_ENV=PATPERF
	elif [[ ${ADS_TD_ENV_FIRST_SEVEN_LETTERS} == "PRODSOC" || ${ADS_TD_ENV_FIRST_THREE_LETTERS} == "SOC" ]]
	then
		ADS_TD_ENV=PROD-SOC
	elif [[ ${ADS_TD_ENV_FIRST_SEVEN_LETTERS} == "PRODCPO" || ${ADS_TD_ENV_FIRST_THREE_LETTERS} == "CPO" ]]
	then
		ADS_TD_ENV=PROD-CPO
	elif [[ ${ADS_TD_ENV_FIRST_SEVEN_LETTERS} == "PRODBDC" || ${ADS_TD_ENV_FIRST_THREE_LETTERS} == "BDC" ]]
	then
		ADS_TD_ENV=PROD-BDC
	fi
	LOCAL_ENV=$(find_server_environment ${LOCAL_HOST})
	if [[ -z ${ADS_ENV_WRAPPER_LOCAL_ENV_CONFIRM} && ${LOCAL_ENV} != ${ADS_TD_ENV} ]]
	then
		cleanup 8 "Local server '${LOCAL_HOST}' is a '${LOCAL_ENV}' server and should NOT be used to target the '${TD_ENV}' environment"
	elif [[ ! -z ${ADS_ENV_WRAPPER_LOCAL_ENV_CONFIRM} && ${LOCAL_ENV} != ${ADS_TD_ENV} ]]
	then
		echo "Local server '${LOCAL_HOST}' is a '${LOCAL_ENV}' server and does NOT match the '${TD_ENV}' environment.  Proceeding due to override..."
		echo
	else
		echo "Local server '${LOCAL_HOST}' is a '${LOCAL_ENV}' server and matches the '${TD_ENV}' environment.  Proceeding..."
		echo
	fi
	if [[ ${ADS_PACKAGE_TYPE} == "WAS" || ${ADS_PACKAGE_TYPE} == "WESB" || ${ADS_PACKAGE_TYPE} == "Pega" || ${ADS_PACKAGE_TYPE} == "FileNet" || ${ADS_PACKAGE_TYPE} == "Portal" ]]
	then
		WAS_ENV=$(find_server_environment ${WAS_HOST})
		#if [[ ${ADS_TD_ENV} != ${WAS_ENV} ]]
		#then
		#	cleanup 9 "The target ${ADS_PACKAGE_TYPE} server '${WAS_HOST}' is NOT a '${TD_ENV}' environment"
		#else
		#	echo "WAS server '${WAS_HOST}' is a '${WAS_ENV}' server and matches the '${TD_ENV}' environment.  Proceeding..."
		#	echo
		#fi
	#elif [[ ${ADS_PACKAGE_TYPE} == "Tomcat" ]]
	#then
        #	TOMCAT_ENV=${find_server_environment ${TC_SERVER_HOST})
        #	if  [[ ${ADS_TD_ENV} != ${TOMCAT_ENV} ]]
        #	then
        #		cleanup 9 "The target ${ADS_PACKAGE_TYPE} server '${TOMCAT_HOST}' is not a '${TD_ENV}' environment"
        #	else
        #		echo "Tomcat server '${TC_SERVER_HOST}' is a '${TOMCAT_ENV}' server and matches the '${TD_ENV}' environment.  Proceeding..."
        #		echo
        #	fi  # Tomcat package 
	elif [[ ${ADS_PACKAGE_TYPE} == "IHS" ]]
	then
		for IHS_HOST in ${IHS_HOSTS}
		do
			IHS_ENV=$(find_server_environment ${IHS_HOST})
			if [[ ${ADS_TD_ENV} != ${IHS_ENV} ]]
			then
				cleanup 9 "The target ${ADS_PACKAGE_TYPE} server '${IHS_HOST}' is not a '${TD_ENV}' environment"
			else
				echo "IHS server '${IHS_HOST}' is a '${IHS_ENV}' server and matches the '${TD_ENV}' environment.  Proceeding..."
				echo
			fi
		done
	fi
	if [[ ${ADS_TD_ENV} == "PROD-SOC" || ${ADS_TD_ENV} == "PROD-CPO" || ${ADS_TD_ENV} == "PROD-BDC" ]]
	then
		if [[ -n ${ADS_ENV_WRAPPER_PROD_CONFIRM} ]]
		then
			echo "ADS Wrapper has provided PRODUCTION confirmation."
			echo
		else
			echo "PLEASE CONFIRM THAT YOU ARE TARGETING A PRODUCTION ENVRIONMENT (ENTER 'YES' TO CONFIRM): \c"
			read PROD_ACK
			echo
			if [[ $(echo ${PROD_ACK} | tr "[a-z]" "[A-Z]") != "YES" ]]
			then
				cleanup 10 "Production confirmation not given"
			fi
		fi
	fi
	}


#----------------------------------
# get WAS cell information from file contained in ADS
#
function get_environment_info {
	#set -x
	ENV_INFO_FILE=${PACKAGE_LOCATION}/cell_info.txt
	if [[ -r ${ENV_INFO_FILE} ]]
	then
		echo "************************************************"
		echo
		echo "Environment Information:"
		echo
		if [[ ${ADS_FUNCTION} == "package_info" ]]
		then
			cat < ${ENV_INFO_FILE} | sed -e 's/^\(.*\) \(.*\)/ADS_ENV_CELL_INFO_\1 \2/g'
		else
			cat < ${ENV_INFO_FILE} | sed -e 's/^\(.*\)/     \1/g'
		fi
		echo
		if [[ ${ADS_PACKAGE_TYPE} == "WAS" || ${ADS_PACKAGE_TYPE} == "WESB" || ${ADS_PACKAGE_TYPE} == "Pega" || ${ADS_PACKAGE_TYPE} == "Portal" ]]
		then
			#WAS_VERSION=$(cat ${ENV_INFO_FILE} | sed -e 's///' | grep "^was_version" | awk '{print $2}' | cut -f-2 -d.)
			WAS_VERSION=$(cat ${ENV_INFO_FILE} | sed -e 's///' | grep "^was_version" | awk '{print $2}')
			WAS_HOST=$(cat ${ENV_INFO_FILE} | sed -e 's///' | grep "^host" | awk '{print $2}')
			WAS_PORT=$(cat ${ENV_INFO_FILE} | sed -e 's///' | grep "^port" | awk '{print $2}')
			WAS_PLATFORM=$(cat ${ENV_INFO_FILE} | sed -e 's///' | grep "^was_platform" | awk '{print $2}')
			if [[ -z ${WAS_VERSION} || -z ${WAS_HOST} || -z ${WAS_PORT} || -z ${WAS_PLATFORM} ]]
			then
				cleanup 11 "WAS cell information missing.  Please check the cell_info.txt file"
			fi
		elif [[ ${ADS_PACKAGE_TYPE} == "IHS" ]]
		then
			IHS_VERSION=$(cat ${ENV_INFO_FILE} | sed -e 's///' | grep "^IHS_version" | awk '{print $2}' | cut -f-2 -d.)
			DOT_COUNT=`ls ${PACKAGE_LOCATION} | grep ihsinstance | grep -v vhost | tr -d -c '.' | awk '{ print length; }`
			IHS_HOSTS=$(ls ${PACKAGE_LOCATION} | grep ihsinstance | grep -v vhost | cut -f${DOT_COUNT} -d.)
			IHS_INSTALL_ROOT=$(cat ${ENV_INFO_FILE} | sed -e 's///' | grep "^IHS_Install_Root" | awk '{print $2}')
			IHS_PLATFORM=$(cat ${ENV_INFO_FILE} | sed -e 's///' | grep "^ihs_platform" | awk '{print $2}')
			if [[ -z ${IHS_VERSION} || -z ${IHS_HOSTS} || -z ${IHS_INSTALL_ROOT} || -z ${IHS_PLATFORM} ]]
			then
				cleanup 11 "IHS information missing.  Please check the cell_info.txt file"
			fi
		elif [[ ${ADS_PACKAGE_TYPE} == "Tomcat" ]]
                then
                        APPLICATION_NAME=$(cat ${ENV_INFO_FILE} | sed -e 's/^M//' | grep "^APPLICATION_NAME" | awk '{print $2}')
                        INSTANCE_NAME=$(cat ${ENV_INFO_FILE} | sed -e 's/^M//' | grep "^INSTANCE_NAME" | awk '{print $2}')
                        TC_SERVER_HOST=$(cat ${ENV_INFO_FILE} | sed -e 's/^M//' | grep "^TC_SERVER_HOST" | awk '{print $2}')
                        TOMCAT_VERSION=$(cat ${ENV_INFO_FILE} | sed -e 's/^M//' | grep "^Tomcat_version" | awk '{print $2}')
                        JAVA_VERSION=$(cat ${ENV_INFO_FILE} | sed -e 's/^M//' | grep "^JAVA_version" | awk '{print $2}')
                        if [[ -z ${APPLICATION_NAME} || -z ${INSTANCE_NAME} || -z ${TC_SERVER_HOST} || -z ${TOMCAT_VERSION} || -z ${JAVA_VERSION} ]]
                        then
                                cleanup 11 "Tomcat information missing.  Please check the cell_info.txt file"
                        fi
		fi
	else
		if [[ ${ADS_FUNCTION} != "list_environments" ]]
		then
			cleanup 12 "Cannot find ${ENV_INFO_FILE} file"
		fi
	fi
	}


#----------------------------------
# Handle WAS 
#
function handle_WAS {
	#set -x
	echo "************************************************"
	echo
	WAS_CONTROL_VERSION=$(${WAS_CONTROL_SHELL} version)
	if [[ $(echo ${WAS_CONTROL_VERSION} | awk '{print $3}' | tr -cd '[:digit:]') -lt ${WAS_CONTROL_MIN_VERSION} ]]
	then
		cleanup 14 "WAS Control version '${WAS_CONTROL_VERSION}' is too low.  Please updrade WAS control to at least ${WAS_CONTROL_MIN_VERSION} before running this ADS_orch.sh function"
	fi
	if [[ ${ADS_FUNCTION} == "preview" ]]
	then
		WAS_CONTROL_PREVIEW_MODE="-preview"
	elif [[ ${ADS_FUNCTION} == "commit" ]]
	then
		WAS_CONTROL_PREVIEW_MODE=""
	fi
	if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
	then
		echo "Searching for local WAS default profile...\c"
		# TO DO - let ShuGuang know that 'WAS_LOCATION' can be passed in to shorten execution time
		if [[ -z ${WAS_LOCATION} ]]
		then
			WAS_CONTROL_LOCATION_COMMAND="${WAS_CONTROL_SHELL} -was_version ${WAS_VERSION} -wasLocation"
			WAS_LOCATION=$(${WAS_CONTROL_LOCATION_COMMAND} | grep WAS_LOCATION | awk '{print $2}')
		fi
		if [[ -z ${WAS_LOCATION} ]]
		then
			cleanup 15 "Could not find default WAS profile"
		fi
		WAS_CONTROL_BASE_COMMAND="${WAS_CONTROL_SHELL} -was_version ${WAS_VERSION} -was_location ${WAS_LOCATION} -host ${WAS_HOST} -port ${WAS_PORT} -was_platform ${WAS_PLATFORM}"
	fi
	if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
	then
		echo "done."
		echo
		echo "Searching for instructions in WAS package..."
		echo
	fi
	WAS_CONTROL_BATCH_FILE=${PACKAGE_LOCATION}/was_control_batch_file.txt
	touch ${WAS_CONTROL_BATCH_FILE}
	#J2C_COUNTER=0
	#for PROP_FILE in `ls ${PACKAGE_LOCATION}/*\.*\.WAS\.*\.properties`
	for PROP_FILE in `ls ${PACKAGE_LOCATION}/*\.*\.WAS\.*`
	do
		if [[ $(grep -cvE "^#.*|^$|^" ${PROP_FILE}) -eq 0 ]]
		then
			if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
			then
				echo "Skipping this file since it contains only comments and/or empty lines:"
				echo "     ${PROP_FILE}"
			fi
		else
			#WAS_CONTROL_FUNCTION=$(echo ${PROP_FILE} | sed -e "s/.*\.\(.*\).properties$/\1/g")
			# fixed on June 30
			DOT_COUNT=$(echo ${PROP_FILE} | tr -d -c '.' | wc -c)
			WAS_CONTROL_FUNCTION=$(echo ${PROP_FILE} | cut -d\. -f${DOT_COUNT})
			if [[ ${WAS_CONTROL_FUNCTION} == "createJ2CAuthenticationAlias" || ${WAS_CONTROL_FUNCTION} == "updateJ2CAuthenticationAlias" ]]
			then
				if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
				then
					echo "Found J2C authentication alias:"
				fi
				# make the following into function
				$(grep -q create_if_not_exist ${PROP_FILE})
				if [[ $? -ne 0 ]]
				then
					echo "create_if_not_exist=true" >> ${PROP_FILE}
				fi
				J2C_INSTRUCTIONS=${J2C_INSTRUCTIONS}:${PROP_FILE}
			elif [[ ${WAS_CONTROL_FUNCTION} == "WASCONTROLFUNCTION_UNKNOWN" || ${WAS_CONTROL_FUNCTION} == "README-SPECIAL-MANUAL-PROCEDURE" || ${WAS_CONTROL_FUNCTION} == "MANUAL_INSTRUCTION" ]]
			then
				if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
				then
					echo "Found manual instructions:"
				fi
				MANUAL_INSTRUCTIONS=${MANUAL_INSTRUCTIONS}:${PROP_FILE}
			elif [[ ${WAS_CONTROL_FUNCTION} == "wascontrolcommand" ]]
			then
				WAS_CONTROL_STAND_ALONE_COMMAND_STRING=$(cat ${PROP_FILE} | grep -v command | tr -d $'\r\n')
				echo ${WAS_CONTROL_STAND_ALONE_COMMAND_STRING} > ${PROP_FILE}
				if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
				then
					echo "Found WAS Control stand-alone command:"
				elif [[ ${ADS_FUNCTION} == "package_info" ]]
				then
					# TO DO - add index to variables sent to GUI to support choice of which commnds to run
					echo ADS_ENV_WAS_CONTROL_STAND_ALONE_COMMAND ${PROP_FILE} `cat ${PROP_FILE}`
				fi
				WAS_CONTROL_STAND_ALONE_FILES=${WAS_CONTROL_STAND_ALONE_FILES}:${PROP_FILE}
			else
				if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
				then
					echo "Found WAS Control batch command:"
				elif [[ ${ADS_FUNCTION} == "package_info" ]]
				then
					# TO DO - add index to variables sent to GUI
					echo ADS_ENV_WAS_CONTROL_BATCH_COMMAND ${PROP_FILE}
				fi
				# TO DO - why is this not in the above "if" clause for preview or commit
				# make the following into function
				$(grep -q create_if_not_exist ${PROP_FILE})
				if [[ $? -ne 0 ]]
				then
					echo "create_if_not_exist=true" >> ${PROP_FILE}
				fi
				echo ${PROP_FILE}=batch >> ${WAS_CONTROL_BATCH_FILE}
			fi
			if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
			then
				echo "     ${PROP_FILE}"
			fi
		fi
	done
	echo
	NUMBER_OF_WAS_CONTROL_BATCH_COMMANDS=$(wc -l ${WAS_CONTROL_BATCH_FILE} | awk '{print $1}')
	NUMBER_OF_WAS_CONTROL_STAND_ALONE_COMMANDS=$(echo ${WAS_CONTROL_STAND_ALONE_FILES} | sed -e 's/[^:]//g' | awk '{print length}')
	if [[ ${ADS_FUNCTION} == "package_info" ]]
	then
		echo ADS_ENV_NUMBER_OF_WAS_CONTROL_BATCH_COMMANDS ${NUMBER_OF_WAS_CONTROL_BATCH_COMMANDS}
		echo ADS_ENV_NUMBER_OF_WAS_CONTROL_STAND_ALONE_COMMANDS ${NUMBER_OF_WAS_CONTROL_STAND_ALONE_COMMANDS}
		echo
	fi
	if [[ ${NUMBER_OF_WAS_CONTROL_BATCH_COMMANDS} -gt 0 ]]
	then
		let TOTAL_NUMBER_OF_WAS_CONTROL_COMMANDS=${NUMBER_OF_WAS_CONTROL_STAND_ALONE_COMMANDS}+1
	else
		let TOTAL_NUMBER_OF_WAS_CONTROL_COMMANDS=${NUMBER_OF_WAS_CONTROL_STAND_ALONE_COMMANDS}
	fi
	handle_J2C
	handle_manual_instructions
	if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
	then
		if [[ ${TOTAL_NUMBER_OF_WAS_CONTROL_COMMANDS} -gt 0 && $(echo ${WAS_HOST} | cut -f1 -d.) != ${LOCAL_HOST} ]]
		then
			echo "************************************************"
			echo
			echo "Importing root signer certificate from remote cell...\c"
			${WAS_CONTROL_BASE_COMMAND} -retrieveRootSignerCertificate 1>/dev/null
			if [[ $? -ne 0 ]]
			then
				cleanup 16 "Issue encountered importing the cell/dmgr signer certificate"
			fi
			echo "done."
			echo
		fi
		if [[ ${NUMBER_OF_WAS_CONTROL_STAND_ALONE_COMMANDS} -eq 0 ]]
		then
			export TDWCC_REMOVE=true
		fi
		if [[ ${NUMBER_OF_WAS_CONTROL_BATCH_COMMANDS} -gt 0 ]]
		then
			WAS_CONTROL_BATCH_COMMAND="${WAS_CONTROL_BASE_COMMAND} ${WAS_CONTROL_PREVIEW_MODE} processADSbatch ${WAS_CONTROL_BATCH_FILE}"
			echo "************************************************"
			echo
			echo "Running WAS Control ADS batch function..."
			echo ${WAS_CONTROL_BATCH_COMMAND}
			echo
			${WAS_CONTROL_BATCH_COMMAND}
			if [[ $? -ne 0 ]]
			then
				cleanup 19 "Issue encountered running '${WAS_CONTROL_BATCH_COMMAND}'"
			else
				echo
				echo "WAS Control ADS batch function completed."
				echo
			fi
		else
			echo "************************************************"
			echo
			echo "No WAS Control ADS batch functions found."
			echo
		fi
		if [[ ${NUMBER_OF_WAS_CONTROL_STAND_ALONE_COMMANDS} -gt 0 ]]
		then
			STAND_ALONE_COUNTER=1
			for WAS_CONTROL_STAND_ALONE_FILE in $(echo ${WAS_CONTROL_STAND_ALONE_FILES} | tr ":" " ")
			do
				WAS_CONTROL_STAND_ALONE_COMMAND_STRING=$(cat ${WAS_CONTROL_STAND_ALONE_FILE})
				WAS_CONTROL_STAND_ALONE_COMMAND="${WAS_CONTROL_BASE_COMMAND} ${WAS_CONTROL_PREVIEW_MODE} ${WAS_CONTROL_STAND_ALONE_COMMAND_STRING}"
				if [[ ${STAND_ALONE_COUNTER} -eq ${NUMBER_OF_WAS_CONTROL_STAND_ALONE_COMMANDS} ]]
				then
					export TDWCC_REMOVE=true
				fi
				echo "************************************************"
				echo
				echo "Running WAS Control ADS stand-alone command:"
				echo ${WAS_CONTROL_STAND_ALONE_COMMAND_STRING}
				echo
				${WAS_CONTROL_STAND_ALONE_COMMAND}
				if [[ $? -ne 0 ]]
				then
					cleanup 19 "Issue encountered running '${WAS_CONTROL_STAND_ALONE_COMMAND}'"
				else
					echo
					echo "WAS Control ADS stand-alone command completed."
					echo
				fi
				let STAND_ALONE_COUNTER=${STAND_ALONE_COUNTER}+1
			done < ${WAS_CONTROL_STAND_ALONE_FILE}
		fi
	fi
	}


#----------------------------------
# Handle IHS 
#
function handle_IHS {
	#set -x
	echo "************************************************"
	echo
	IHS_INSTANCE_LIST=$(ls ${PACKAGE_LOCATION} | grep ihsinstance | grep -v vhost)
	WEBSERVER_HOSTNAMES=""
	TEMP_PREWEBSERVER=""
	for IHS_INSTANCE in ${IHS_INSTANCE_LIST}
	do
		IHS_INSTANCE_FILE=${PACKAGE_LOCATION}/${IHS_INSTANCE}
		echo "Found IHS instance ${IHS_INSTANCE_FILE}"
		echo
		DOT_COUNT=`ls ${IHS_INSTANCE_FILE} | tr -d -c '.' | awk '{ print length; }`
		IHS_INSTANCE_NUMBER=$(ls ${IHS_INSTANCE_FILE} | cut -f$(($DOT_COUNT -1)) -d.)
		VHOST_FILE_LIST_ROOT=$(echo ${PACKAGE_LOCATION}/${IHS_INSTANCE} | cut -f-$(($DOT_COUNT -1)) -d.).vhost
		VHOST_FILE_LIST=$(ls ${VHOST_FILE_LIST_ROOT}*)
		INSTANCE_NAME=$(cat ${IHS_INSTANCE_FILE} | grep ^IHS-Instance-Name | cut -f2 -d=)
		INSTANCE_HOST=$(cat ${IHS_INSTANCE_FILE} | grep ^Server-Host-Name | cut -f2 -d=)
		if [[ ${ADS_FUNCTION} == "package_info" ]]
		then
			echo ADS_ENV_IHS_INSTANCE_${IHS_INSTANCE_NUMBER}_NAME=${INSTANCE_NAME}
			echo ADS_ENV_IHS_INSTANCE_${IHS_INSTANCE_NUMBER}_HOST=${INSTANCE_HOST}
			echo
		else
			# add code to handle web server host name to call HPOO flow
			TEMP_WEBSERVER=$(echo $IHS_INSTANCE | rev |cut -d '.' -f2 | rev)
			if [[ "$TEMP_PREWEBSERVER" != "$TEMP_WEBSERVER" ]]
			then
				TEMP_PREWEBSERVER="$TEMP_WEBSERVER"
				WEBSERVER_HOSTNAMES="$(echo ${WEBSERVER_HOSTNAMES},${TEMP_WEBSERVER})"
			fi
		fi 
		for VHOST_FILE in ${VHOST_FILE_LIST}
		do
			echo "Found Virtual Host ${VHOST_FILE}"
			echo
			DOT_COUNT=`echo ${VHOST_FILE} | tr -d -c '.' | awk '{ print length; }`
			VHOST_INDEX=$(echo ${VHOST_FILE} | cut -f$DOT_COUNT -d.)
			VHOST_NAME=$(cat ${VHOST_FILE} | grep ServerName | awk '{print $2}')
			VHOST_ADDRESS=$(cat ${VHOST_FILE} | grep "<VirtualHost " | awk '{print $2}' | cut -f1 -d\>)
			VHOST_HOST=$(echo ${VHOST_ADDRESS} | cut -f1 -d:)
			VHOST_PORT=$(echo ${VHOST_ADDRESS} | cut -f2 -d:)
			if [[ ${VHOST_HOST} == ${VHOST_PORT} ]]
			then
				VHOST_PORT=""
			fi
			if [[ ${ADS_FUNCTION} == "package_info" ]]
			then
				echo ADS_ENV_IHS_INSTANCE_${IHS_INSTANCE_NUMBER}_VHOST_${VHOST_INDEX}_NAME=${VHOST_NAME}
				echo ADS_ENV_IHS_INSTANCE_${IHS_INSTANCE_NUMBER}_VHOST_${VHOST_INDEX}_HOST=${VHOST_HOST}
				echo ADS_ENV_IHS_INSTANCE_${IHS_INSTANCE_NUMBER}_VHOST_${VHOST_INDEX}_PORT=${VHOST_PORT}
				echo
			elif [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
			then
				NEW_VHOST_FILE=${VHOST_FILE}_new
				NEW_VHOST_NAME=$(eval echo \${ADS_ENV_IHS_INSTANCE_${IHS_INSTANCE_NUMBER}_VHOST_${VHOST_INDEX}_NAME})
				if [[ ! -z ${NEW_VHOST_NAME} && ${NEW_VHOST_NAME} != ${VHOST_NAME} ]]
				then
					echo "Updating ${VHOST_FILE} server name from '${VHOST_NAME}' to '${NEW_VHOST_NAME}'..."
					echo
					cat < ${VHOST_FILE} | sed -e 's/'${VHOST_NAME}'/'${NEW_VHOST_NAME}'/g' > ${NEW_VHOST_FILE}
					mv ${NEW_VHOST_FILE} ${VHOST_FILE}
				fi
				NEW_VHOST_HOST=$(eval echo \${ADS_ENV_IHS_INSTANCE_${IHS_INSTANCE_NUMBER}_VHOST_${VHOST_INDEX}_HOST})
				if [[ ! -z ${NEW_VHOST_HOST} && ${NEW_VHOST_HOST} != ${VHOST_HOST} ]]
				then
					echo "Updating ${VHOST_FILE} host name from '${VHOST_HOST}' to '${NEW_VHOST_HOST}'..."
					echo
					cat < ${VHOST_FILE} | sed -e 's/NameVirtualHost \(.*\):\(.*\)/\NameVirtualHost '${NEW_VHOST_HOST}':\2/'  -e 's/Listen \(.*\):\(.*\)/\Listen '${NEW_VHOST_HOST}':\2/' -e 's/VirtualHost \(.*\):\(.*\)/VirtualHost '${NEW_VHOST_HOST}':\2/' > ${NEW_VHOST_FILE}
					mv ${NEW_VHOST_FILE} ${VHOST_FILE}
				fi
				NEW_VHOST_PORT=$(eval echo \${ADS_ENV_IHS_INSTANCE_${IHS_INSTANCE_NUMBER}_VHOST_${VHOST_INDEX}_PORT})
				if [[ ! -z ${NEW_VHOST_PORT} && ${NEW_VHOST_PORT} != ${VHOST_PORT} ]]
				then
					echo "Updating ${VHOST_FILE} port from '${VHOST_PORT}' to '${NEW_VHOST_PORT}'..."
					echo
					cat < ${VHOST_FILE} | sed -e 's/NameVirtualHost \(.*\):\(.*\)/NameVirtualHost \1:'${NEW_VHOST_PORT}'/' -e 's/Listen \(.*\):\(.*\)/Listen \1:'${NEW_VHOST_PORT}'/' -e 's/VirtualHost \(.*\):\(.*\)\>/VirtualHost \1:'${NEW_VHOST_PORT}'\>/' > ${NEW_VHOST_FILE}
					mv ${NEW_VHOST_FILE} ${VHOST_FILE}
				fi
			fi
		done
	done
	MANUAL_INSTRUCTIONS=$(find ${PACKAGE_LOCATION} -type f | grep -E "README-SPECIAL-MANUAL-PROCEDURE|MANUAL_INSTRUCTION")
	MANUAL_INSTRUCTIONS=$(echo ${MANUAL_INSTRUCTIONS} | tr ' ' ':')
	handle_manual_instructions
	if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
	then
		echo "************************************************"
		echo
		echo "Creating IHS_Control package and including any changes made to Virtual Host data...\c"
		cd ${PACKAGE_LOCATION}
		cp -pR ${IHS_CONTROL_PACKAGE} .
		
		TEMP_ZIPORG=`basename $ADS_PACKAGE`
		TEMP_ZIPREFIX=${TEMP_ZIPORG%.*}
		TEMP_IHSDIR=`dirname $PACKAGE_LOCATION`
		TEMP_IHSZIP=`basename $PACKAGE_LOCATION`
		PACKAGE_LOCATION_IHS=${TEMP_IHSDIR}/${TEMP_ZIPREFIX}_${TEMP_IHSZIP}
		${JAR_COMMAND} -cf ${PACKAGE_LOCATION_IHS}.zip ./*
		
		#extract Target Web Server list by cutting the leading comma ","
		WEBSERVER_HOSTNAMES=$(echo $WEBSERVER_HOSTNAMES | cut -d ',' -f2-)
		IHS_USER=${ADS_USER}
		if [[ -z ${IHS_USER} ]]
		then
			IHS_USER=${AUTO_USER}
		fi
		
		echo "done."
		echo
		echo "Executing IHS_Control with following arguments:"
		echo "     Package Type: ${ADS_PACKAGE_TYPE}"   
		echo "     Package File: ${PACKAGE_LOCATION}.zip"
		echo "          User ID: ${IHS_USER}"
		echo " Function/Command: ${ADS_FUNCTION}"
		echo "   Target Servers: ${WEBSERVER_HOSTNAMES}"
		echo
		# TO DO - execute HPOO / IHS Control
		#cd -
		IHS_USER=${ADS_USER}
		if [[ -z ${IHS_USER} ]]
		then
			IHS_USER=${AUTO_USER}
		fi
		#Testing code for ED to get the ZIP file after call IHS preview via GUI
		cp ${PACKAGE_LOCATION_IHS}.zip  /tmp
		${ADS_ORCH_DIR}/HPOO_Handler.sh ${ADS_PACKAGE_TYPE} ${PACKAGE_LOCATION_IHS}.zip ${IHS_USER} ${ADS_FUNCTION} ${WEBSERVER_HOSTNAMES}
		HPOO_Handler_RC=$?
		echo "HPOO_Handler return Code: $HPOO_Handler_RC"
		if [[  $HPOO_Handler_RC -ne 0 ]]
		then
			if [[ ${ADS_FUNCTION} == "preview" ]]
			then
				cleanup 25 "Issue encountered during previewing IHS changes"
			else
				cleanup 25 "Issue encountered after committing IHS changes"
			fi
		fi
	fi
	}

function handle_TomcatApache {
        echo "************************************************"
        echo
        TOMCATAPACHE_PROP_FILE=$(ls ${PACKAGE_LOCATION} | grep Tomcat | grep app )
        echo "Found TomcatApache properties ${TOMCATAPACHE_PROP_FILE}"
        echo
        IFS="."
        set -A array ${TOMCATAPACHE_PROP_FILE}
        PROJECTNAME=`echo ${array[0]}`
        ENVNAME=`echo ${array[1]}`
        unset IFS
        echo PROJECTNAME=${PROJECTNAME}
        echo ENVNAME=${ENVNAME}
        echo
 
        INSTANCE_NAME=$(cat ${PACKAGE_LOCATION}/${TOMCATAPACHE_PROP_FILE} | grep ^INSTANCE_NAME | cut -f2 -d=)
        INSTANCE_NAME=`echo ${INSTANCE_NAME} |  awk -F '"' '{print $2}'`  # remove double quotes

        TOMCAT_HOST=$(cat ${PACKAGE_LOCATION}/${TOMCATAPACHE_PROP_FILE} | grep ^TC_SERVER_HOST | cut -f2 -d=)
        TOMCAT_TARGET_HOST=`echo ${TOMCAT_HOST} |  awk -F '"' '{print $2}'`  # remove double quotes
 
        APACHE_HOST=$(cat ${PACKAGE_LOCATION}/${TOMCATAPACHE_PROP_FILE} | grep ^AP_HOST_NAME | cut -f2 -d=)
        APACHE_TARGET_HOST=`echo ${APACHE_HOST} |  awk -F '"' '{print $2}'`  # remove double quotes

        TOMCATAPACHE_GENERAL_FILE=$(ls ${PACKAGE_LOCATION} | grep Tomcat | grep general )
        echo "Found TomcatApache properties ${TOMCATAPACHE_GENERAL_FILE}"
        echo
        TOMCATONLY=$(cat ${PACKAGE_LOCATION}/${TOMCATAPACHE_GENERAL_FILE} | grep ^Tomcat-only | cut -f2 -d=)
        TOMCATONLY=`echo ${TOMCATONLY} |  awk -F '"' '{print $2}'`  # remove double quotes
        echo Tomcat-only = ${TOMCATONLY}

        if [[ ${ADS_FUNCTION} == "package_info" ]]
        then
         echo ADS_ENV_TOMCATAPACHE_INSTANCE=${INSTANCE_NAME} 
         echo ADS_ENV_TOMCAT_HOST=${TOMCAT_TARGET_HOST}

         # If TomcatOnly equal to FALSE then Apache is required
         if [[ ${TOMCATONLY} == "FALSE"  ]]
         then
          echo ADS_ENV_APACHE_HOST=${APACHE_TARGET_HOST}
         fi

         echo ADS_ENV_TOMCATONLY=${TOMCATONLY}
         echo
        fi
 
        MANUAL_INSTRUCTIONS=$(find ${PACKAGE_LOCATION} -type f | grep -E "README-SPECIAL-MANUAL-PROCEDURE|MANUAL_INSTRUCTION")
        MANUAL_INSTRUCTIONS=$(echo ${MANUAL_INSTRUCTIONS} | tr ' ' ':')
        handle_manual_instructions
 

        if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
        then
         echo "************************************************"
         echo
         echo "Building Tomcat/Apache configurations from the ADS package on the CMS server ."
         echo "------------------------------------------------------------------------------"
         echo "Executing CMS_Tomcat.sh script. TomcatControl.sh is being called as a part of the process ."
         echo 
         cd ${TOMCATAPACHE_PACKAGE};./CMS_Tomcat.sh ${FULL_PATH_TO_ADS_PACKAGE} 
         echo
         echo "======================================================================"
         echo
        fi # ADS_FUNCTION preview or commit

        if [[ ${ADS_FUNCTION} == "commit" ]]
        then
	 JAR_COMMAND=/usr/opt/WebSphere8/AppServer/java/bin/jar

         # User to be used to run the HPOO/HPSA flows . The value of AUTO_USER will be passed by GUI.
         TOMCATAPACHE_USER=${AUTO_USER}
 
         echo "************************************************"
         echo "Creating a Tomcat/Apache Zip package to be distributed via HPOO/HPSA flow."
         echo
	 # Tomcat flow
         echo "Tomcat flow to be processed."
	 echo
         TOMCAT_HOST=$(cat ${PACKAGE_LOCATION}/${TOMCATAPACHE_PROP_FILE} | grep ^TC_SERVER_HOST | cut -f2 -d=)
         TOMCAT_TARGET_HOST=`echo ${TOMCAT_HOST} |  awk -F '"' '{print $2}'`  # remove double quotes
          
	 TOMCATTAR=tomcat_${TOMCAT_TARGET_HOST}_${INSTANCE_NAME}.tar
         TOMCATTAR=`echo ${TOMCATTAR} | tr -d '\n' | tr -d '\r'`
         TOMCATINSTALLZIP=tomcat_${TOMCAT_TARGET_HOST}_${INSTANCE_NAME}_install.zip
         TOMCATINSTALLZIP=`echo ${TOMCATINSTALLZIP} | tr -d '\n' | tr -d '\r'`

         echo "Creating /tmp/${TOMCATINSTALLZIP} ... compressing. "
	 # Move the tar file to the current dir to avoid archiving with the full path
         mv -f ${TOMCATAPACHE_PACKAGE}/dist_build/${PROJECTNAME}/${ENVNAME}/${TOMCATTAR} . 

	 # Copy Tomcat install script to the current dirrectory   
         if [ ! -f  ${TOMCATAPACHE_PACKAGE}/install_tomcatsrv.sh ];then
	  cp -p ${TOMCATAPACHE_PACKAGE}/install_tomcatsrv.sh      
         fi

	 ${JAR_COMMAND} -cf /tmp/${TOMCATINSTALLZIP} ${TOMCATTAR}
         ${JAR_COMMAND} -uf /tmp/${TOMCATINSTALLZIP} install_tomcatsrv.sh  
         echo "Created: /tmp/${TOMCATINSTALLZIP}"
	 rm -f ${TOMCATTAR}  #  # remove tar file after the zip package was created
	 echo
         echo "************************************************"
         echo
         echo "Executing HPOO/HPSA flow distribution for a Tomcat with the following arguments:"
         echo "     Package Type:       ${ADS_PACKAGE_TYPE}"
         echo "     Package File:       ${TOMCATINSTALLZIP}"
         echo "     User ID     :       ${TOMCATAPACHE_USER}"
         echo "     Function/Command:   ${ADS_FUNCTION}"
         echo
         echo ${ADS_ORCH_DIR}/HPOO_Handler.sh ${ADS_PACKAGE_TYPE} /tmp/${TOMCATINSTALLZIP} ${TOMCATAPACHE_USER} ${ADS_FUNCTION} ${TOMCAT_TARGET_HOST}

         if [[ $? -ne 0 ]]
         then
           cleanup 25 "Issue encountered during comitting Tomcat."
         fi
          
	 # Remove zip file after executing HPOO/HPSA flow 	
	 echo rm -f ${TOMCATINSTALLZIP}

	 # If TomcatOnly equal to FALSE then Apache is required
         if [[ ${TOMCATONLY} == "FALSE"  ]] 
          then
 	  # Apache flow
	  echo
          echo "Apache flow to be processed."
          echo
          APACHETAR=apache_${APACHE_TARGET_HOST}_${INSTANCE_NAME}.tar
          APACHETAR=`echo ${APACHETAR} | tr -d '\n' | tr -d '\r'`
   	  APACHEINSTALLZIP=apache_${APACHE_TARGET_HOST}_${INSTANCE_NAME}_install.zip
          APACHEINSTALLZIP=`echo ${APACHEINSTALLZIP} | tr -d '\n' | tr -d '\r'`

          echo "Creating /tmp/${APACHEINSTALLZIP} ... compressing. "
	  # Move the tar file to the current dir to avoid archiving with the full path
	  mv -f ${TOMCATAPACHE_PACKAGE}/dist_build/${PROJECTNAME}/${ENVNAME}/${APACHETAR} .  

 	  ${JAR_COMMAND} -cf /tmp/${APACHEINSTALLZIP} ${APACHETAR} 

	  # Copy Apache install script to the current dirrectory   
          if [ ! -f  ${TOMCATAPACHE_PACKAGE}/install_apachesrv.sh ];then
	   cp -p ${TOMCATAPACHE_PACKAGE}/install_apachesrv.sh . # Copy install script to the current dir 
          fi

          ${JAR_COMMAND} -uf /tmp/${APACHEINSTALLZIP} install_apachesrv.sh  
          echo "Created: /tmp/${APACHEINSTALLZIP}"
	  rm -f  ${APACHETAR} # remove tar file after the zip package was created 
 	  echo
	  echo "************************************************"
          echo
          echo "Executing HPOO/HPSA flow distribution for a Tomcat with the following arguments:"
          echo "     Package Type:       ${ADS_PACKAGE_TYPE}"
          echo "     Package File:       ${APACHEINSTALLZIP}"
          echo "     User ID     :       ${TOMCATAPACHE_USER}"
          echo "     Function/Command:   ${ADS_FUNCTION}"
          echo
          echo ${ADS_ORCH_DIR}/HPOO_Handler.sh ${ADS_PACKAGE_TYPE} /tmp/${APACHEINSTALLZIP} ${TOMCATAPACHE_USER} ${ADS_FUNCTION} ${APACHE_TARGET_HOST}

          if [[ $? -ne 0 ]]
          then
           cleanup 25 "Issue encountered during comitting Apache."
          fi

	  # Remove zip file after executing HPOO/HPSA flow 	
          echo rm -f  ${APACHEINSTALLZIP}

	 fi # TOMCATONLY 
 
 
        fi  # ADS_FUNCTION commit

}
#----------------------------------
# Handle Apache
#
function handle_Apache {
	echo "************************************************"
        echo
        APACHE_PROP_FILE=$(ls ${PACKAGE_LOCATION} | grep Apache | grep app )
        echo "Found Apache properties ${APACHE_PROP_FILE}"
        echo
        IFS="."
        set -A array ${APACHE_PROP_FILE}
        PROJECTNAME=`echo ${array[0]}`
        ENVNAME=`echo ${array[1]}`
        unset IFS
        echo PROJECTNAME=${PROJECTNAME}
        echo ENVNAME=${ENVNAME}
        echo
 
        INSTANCE_NAME=$(cat ${PACKAGE_LOCATION}/${APACHE_PROP_FILE} | grep ^INSTANCE_NAME | cut -f2 -d=)
        INSTANCE_NAME=`echo ${INSTANCE_NAME} |  awk -F '"' '{print $2}'`  # remove double quotes

        APACHE_HOST=$(cat ${PACKAGE_LOCATION}/${APACHE_PROP_FILE} | grep ^AP_HOST_NAME | cut -f2 -d=)
        APACHE_TARGET_HOST=`echo ${APACHE_HOST} | awk -F '"' '{print $2}'`  # remove double quotes
 
        if [[ ${ADS_FUNCTION} == "package_info" ]]
        then
         echo ADS_ENV_APACHE_INSTANCE=${INSTANCE_NAME} 
         echo ADS_ENV_APACHE_HOST=${APACHE_TARGET_HOST}
         echo
        fi
 
        MANUAL_INSTRUCTIONS=$(find ${PACKAGE_LOCATION} -type f | grep -E "README-SPECIAL-MANUAL-PROCEDURE|MANUAL_INSTRUCTION")
        MANUAL_INSTRUCTIONS=$(echo ${MANUAL_INSTRUCTIONS} | tr ' ' ':')
        handle_manual_instructions

        if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
        then
         echo "************************************************"
         echo
         echo "Building Apache configurations from the ADS package on the CMS server ."
         echo "------------------------------------------------------------------------------"
         echo "Executing CMS_Apache.sh script. ApacheControl.sh is being called as a part of the process ."
         echo
         cd ${TOMCATAPACHE_PACKAGE};./CMS_Apache.sh ${FULL_PATH_TO_ADS_PACKAGE}
         echo
         echo "======================================================================"
         echo
        fi # ADS_FUNCTION preview or commit
 
        if [[ ${ADS_FUNCTION} == "commit" ]]
        then
         JAR_COMMAND=/usr/opt/WebSphere8/AppServer/java/bin/jar
 
         # User to be used to run the HPOO/HPSA flows . The value of AUTO_USER will be passed by GUI.
         APACHE_USER=${AUTO_USER}
 
          # Apache flow
          echo
          echo "Apache flow to be processed."
          echo
          APACHETAR=apache_${APACHE_TARGET_HOST}_${INSTANCE_NAME}.tar
          APACHETAR=`echo ${APACHETAR} | tr -d '\n' | tr -d '\r'`
          APACHEINSTALLZIP=apache_${APACHE_TARGET_HOST}_${INSTANCE_NAME}_install.zip
          APACHEINSTALLZIP=`echo ${APACHEINSTALLZIP} | tr -d '\n' | tr -d '\r'`
           
          echo "Creating /tmp/${APACHEINSTALLZIP} ... compressing. "
          # Move the tar file to the current dir to avoid archiving with the full path
          mv -f ${TOMCATAPACHE_PACKAGE}/dist_build/${PROJECTNAME}/${ENVNAME}/${APACHETAR} .
 
          ${JAR_COMMAND} -cf /tmp/${APACHEINSTALLZIP} ${APACHETAR}
 
          # Copy Apache install script to the current dirrectory
          if [ ! -f  ${TOMCATAPACHE_PACKAGE}/install_apachesrv.sh ];then
           cp -p ${TOMCATAPACHE_PACKAGE}/install_apachesrv.sh . # Copy install script to the current dir
          fi
 
          ${JAR_COMMAND} -uf /tmp/${APACHEINSTALLZIP} install_apachesrv.sh
          echo "Created: /tmp/${APACHEINSTALLZIP}"
          rm -f  ${APACHETAR} # remove tar file after the zip package was created
          echo
          echo "************************************************"
          echo
          echo "Executing HPOO/HPSA flow distribution for a Tomcat with the following arguments:"
          echo "     Package Type:       ${ADS_PACKAGE_TYPE}"
          echo "     Package File:       ${APACHEINSTALLZIP}"
          echo "     User ID     :       ${TOMCATAPACHE_USER}"
          echo "     Function/Command:   ${ADS_FUNCTION}"
          echo
          echo ${ADS_ORCH_DIR}/HPOO_Handler.sh ${ADS_PACKAGE_TYPE} /tmp/${APACHEINSTALLZIP} ${APACHE_USER} ${ADS_FUNCTION} ${APACHE_TARGET_HOST}
 
          if [[ $? -ne 0 ]]
          then
           cleanup 25 "Issue encountered during comitting Apache."
          fi
 
          # Remove zip file after executing HPOO/HPSA flow
          echo rm -f  ${APACHEINSTALLZIP}
 
        fi  # ADS_FUNCTION commit
 
}

#----------------------------------
# Handle Pega
#
function handle_Pega {
	cleanup 1 "Pega not supported at this time"
	}


#----------------------------------
# Handle JBoss
#
function handle_JBoss {
	cleanup 1 "JBoss not supported at this time"
	}


#----------------------------------
# Handle Portal
#
function handle_Portal {
	cleanup 1 "WebSphere Portal not supported at this time"
	}


#----------------------------------
# Handle FileNet
#
function handle_FileNet {
	cleanup 1 "FileNet not supported at this time"
	}


#----------------------------------
# Handle MQ
#
function handle_MQ {
	cleanup 1 "MQ not supported at this time"
	}


#----------------------------------
# Handle J2C authenitcation aliases
#
function handle_J2C {
	#set -x
	if [[ -n ${J2C_INSTRUCTIONS} ]]
	then
		J2C_COUNTER=0
		for J2CI in $(echo ${J2C_INSTRUCTIONS} | tr ":" " ")
		do
			echo "************************************************"
			echo 
			if [[ $(eval echo \${ADS_ENV_J2C_${J2C_COUNTER}}) == "true" ]]
			then
				echo "Wrapper provided:"
				echo ALIAS=$(eval echo \${ADS_ENV_J2C_${J2C_COUNTER}_ALIAS}) | tee -a ${J2CI}
				echo ALIAS_USERID=$(eval echo \${ADS_ENV_J2C_${J2C_COUNTER}_ALIAS_USERID}) | tee -a ${J2CI}
				echo ALIAS_PASSWORD=$(eval echo \${ADS_ENV_J2C_${J2C_COUNTER}_ALIAS_PASSWORD}) >> ${J2CI}
				echo ALIAS_DESCRIPTION=$(eval echo \${ADS_ENV_J2C_${J2C_COUNTER}_ALIAS_DESCRIPTION}) | tee -a ${J2CI}
				echo ${J2CI}=batch >> ${WAS_CONTROL_BATCH_FILE}
				echo
			elif [[ $(eval echo \${ADS_ENV_J2C_${J2C_COUNTER}}) == "skip" ]]
			then
				echo "     Skipping input"
			else
				ALIAS=$(cat ${J2CI} | sed -e 's///' | grep -i "^alias" | cut -f2 -d=)
				ALIAS_USERID=$(cat ${J2CI} | sed -e 's///' | grep -i "^userid" | cut -f2 -d=)
				ALIAS_DESCRIPTION=$(cat ${J2CI} | sed -e 's///' | grep -i "^description" | cut -f2 -d=)
				if [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
				then
					echo "Found J2C alias:"
					echo "            Name: ${ALIAS}"
					echo "              ID: ${ALIAS_USERID}"
					echo "     Description: ${ALIAS_DESCRIPTION}"
					echo "     Do you want to create/update this J2C Authentication Alias? (YES/NO): \c"
					read ALIAS_CONFIRM
					if [[ $(echo ${ALIAS_CONFIRM} | tr "[a-z]" "[A-Z]") == "YES" ]]
					then
						trap 'stty echo;echo;cleanup 17 "Interrupted while running get_authentication_alias function"' INT TERM
						stty -echo
						echo "     Enter J2C Authentication Alias Password: \c"
						read ALIAS_PASSWORD
						stty echo
						echo
						echo ALIAS=${ALIAS} >> ${J2CI}
						echo ALIAS_USERID=${ALIAS_USERID} >> ${J2CI}
						echo ALIAS_PASSWORD=${ALIAS_PASSWORD} >> ${J2CI}
						echo ALIAS_DESCRIPTION=${ALIAS_DESCRIPTION} >> ${J2CI}
						echo ${J2CI}=batch >> ${WAS_CONTROL_BATCH_FILE}
					elif [[ $(echo ${ALIAS_CONFIRM} | tr "[a-z]" "[A-Z]") == "NO" ]]
					then
						echo "     Skipping this J2C Authentication Alias."
					else
						cleanup 18 "Invalid response.  Must be YES or NO"
					fi
					echo
				elif [[ ${ADS_FUNCTION} == "package_info" ]]
				then
					echo ADS_ENV_J2C_${J2C_COUNTER}_ALIAS ${ALIAS}
					echo ADS_ENV_J2C_${J2C_COUNTER}_ALIAS_USERID ${ALIAS_USERID}
					echo ADS_ENV_J2C_${J2C_COUNTER}_ALIAS_DESCRIPTION ${ALIAS_DESCRIPTION}
					echo ${J2CI}=batch >> ${WAS_CONTROL_BATCH_FILE}
				fi
			fi
			let J2C_COUNTER=${J2C_COUNTER}+1
		done
	fi
	}


#----------------------------------
# Handle Manual Instructions
#
function handle_manual_instructions {
	#set -x
	if [[ -n ${MANUAL_INSTRUCTIONS} ]]
	then
		MANUAL_COUNTER=0
		for MI in $(echo ${MANUAL_INSTRUCTIONS} | tr ":" " ")
		do
			echo "************************************************"
			echo 
			echo "Found Manual Instructions ${MI}"
			echo
			echo "The following instructions must be performed."
			echo "Please note that these instructions might have already been completed previously:"
			echo 
			cat < ${MI} | grep -v create_if_not_exist > temp_MI
			if [[ ${ADS_FUNCTION} == "package_info" ]]
			then
				MANUAL_INFO_COUNTER=0
				while read LINE
				do
					echo ${LINE} | sed -e 's/^\(.*\)/ADS_ENV_MANUAL_'${MANUAL_COUNTER}'_'${MANUAL_INFO_COUNTER}' \1/g'
					let MANUAL_INFO_COUNTER=${MANUAL_INFO_COUNTER}+1
				done < temp_MI
				let MANUAL_COUNTER=${MANUAL_COUNTER}+1
				rm temp_MI
				echo
			elif [[ ${ADS_FUNCTION} == "preview" || ${ADS_FUNCTION} == "commit" ]]
			then
				cat < temp_MI
				rm temp_MI
				echo 
				if [[ ! -n ${ADS_SKIP_MANUAL_INSTRUCTIONS} ]]
				then
					echo "Please acknowledge you have read this message and enter \"YES\" to continue: \c"
					read MI_CONFIRM
					echo
					if [[ $(echo ${MI_CONFIRM} | tr "[a-z]" "[A-Z]") != "YES" ]]
					then
						cleanup 21 "Incorrect repsonse given"
					fi
				else
					echo "Skipping manual instructions confirmation due to override."
					echo
				fi
			fi
		done
	else
		echo "No manual instructions found."
		echo
	fi
	}


#------------------------------------------------------
# function to verfiy supported functions
#
function ADS_function_check {
	#set -x
	ADS_SUPPORTED_FUNCTIONS=$1
	for ADS_SUPPORTED_FUNCTION in ${ADS_SUPPORTED_FUNCTIONS}
	do
		if [[ ${ADS_SUPPORTED_FUNCTION} == ${ADS_FUNCTION} ]]
		then
			ADS_FUNCTION_CHECK=OK
			break
		fi
	done
	if [[ -z ${ADS_FUNCTION_CHECK} ]]
	then
		cleanup 50 "The '${ADS_FUNCTION}' function is not supported for the '${ADS_PACKAGE_TYPE}' type"
	fi
	}


#------------------------------------------------------
# script entry
#
clear
if [[ $# -ne 4 ]]
then
	cleanup 1 "Script requires 4 arguments:
	1 - Package location (either a zip file or directory structure)
	2 - Package type (WAS, WESB, DataPower, IHS, Tomcat, Apache, Pega, Portal, MQ, JBoss)
	3 - Environment (DEV61, SYS, PAT2, PROD-SOC, PROD-BDC, etc...)
	4 - Functon/Mode (preview, commit)"
fi


#----------------------------------
# main script logic
#
#set -x
trap 'cleanup 18 "Interrupted while running main script logic"' INT TERM KILL ILL SEGV HUP ABRT QUIT
if [[ ${ADS_PACKAGE_TYPE} == "WAS" ]]
then
	ADS_function_check "list_environments package_info preview commit"
	open_ADS_package ${ADS_PACKAGE} ${ADS_PACKAGE_TYPE} ${TD_ENV}
	get_environment_info
	match_environment
	handle_WAS
elif [[ ${ADS_PACKAGE_TYPE} == "IHS" ]]
then
	ADS_function_check "list_environments package_info preview commit"
	open_ADS_package ${ADS_PACKAGE} ${ADS_PACKAGE_TYPE} ${TD_ENV}
	get_environment_info
	match_environment
	handle_IHS
elif [[ ${ADS_PACKAGE_TYPE} == "Tomcat" ]]
then
        ADS_function_check "list_environments package_info preview commit"
        open_ADS_package ${ADS_PACKAGE} ${ADS_PACKAGE_TYPE} ${TD_ENV}
        get_environment_info
        match_environment
        handle_TomcatApache 
elif [[ ${ADS_PACKAGE_TYPE} == "Apache" ]]
then
        ADS_function_check "list_environments package_info preview commit"
        open_ADS_package ${ADS_PACKAGE} ${ADS_PACKAGE_TYPE} ${TD_ENV}
        get_environment_info
        match_environment
        handle_Apache
elif [[ ${ADS_PACKAGE_TYPE} == "WESB" ]]
then
	handle_WESB
elif [[ ${ADS_PACKAGE_TYPE} == "Portal" ]]
then
	handle_Portal
elif [[ ${ADS_PACKAGE_TYPE} == "FileNet" ]]
then
	handle_FileNet
elif [[ ${ADS_PACKAGE_TYPE} == "Pega" ]]
then
	handle_Pega
elif [[ ${ADS_PACKAGE_TYPE} == "JBoss" ]]
then
	handle_JBoss
else
	cleanup 2 "ADS package type '${ADS_PACKAGE_TYPE}' not recognized"
fi
# TO DO - incorporate preview into get_SDM_information
# TO DO - create zip of log files

cleanup 0 "ADS_orch.sh script completed."

