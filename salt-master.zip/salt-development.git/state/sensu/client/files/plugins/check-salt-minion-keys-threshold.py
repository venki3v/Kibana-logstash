from os import listdir
from os.path import isfile
from argparse import ArgumentParser
from common.sensu import Sensu
from common.proc import Proc

sensu = Sensu()


def main():
    """
    Checks locally if the salt-master has hit the
    threshold for maximum number of minion keys.

    The number of accepted minion keys should
    be lower than 1/4 of the max open files soft
    setting. - http://git.io/vZTkt
    """
    parser = ArgumentParser()
    parser.add_argument('--pki-dir', default='/etc/salt/pki/master/minions')
    parser.add_argument('-w', default=70, type=int,
                        choices=range(0, 101), help='Warning Percent')
    parser.add_argument('-c', default=90, type=int,
                        choices=range(0, 101), help='Critical Percent')
    args = parser.parse_args()
    #
    # Get number of minion keys
    minions = _count_minions(args.pki_dir)
    #
    # Get number of max open files for salt-master process
    max_open_files = _get_limit()
    #
    # Calculate threshold percent based on saltstacks recommendation
    threshold_percent = _threshold_percent(minions, max_open_files)
    #
    # Output check state
    if threshold_percent >= args.c:
        return sensu.output_check(sensu.STATE_CRITICAL,
                                  message='Minion key threshold CRITICAL '
                                          '({0}%)'.format(threshold_percent))
    elif threshold_percent >= args.w:
        return sensu.output_check(sensu.STATE_WARNING,
                                  message='Minion key threshold WARNING '
                                          '({0}%)'.format(threshold_percent))
    else:
        return sensu.output_check(sensu.STATE_OK,
                                  message='Minion key threshold OK '
                                          '({0}%)'.format(threshold_percent))


def _count_minions(pdir):
    """
    Count the number of minion keys

    :pdir: Master minion pki dir location
    :returns: int count of minion keys
    """
    return len([n for n in listdir(pdir) if isfile('{0}/{1}'.format(pdir, n))])


def _get_limit(name='salt-master',
               limit_type='soft',
               limit_name='max_open_files'):
    """
    Get the requested limit for a process

    :name: name of the salt master process optional
    :limit_type: Limit type either 'soft' or 'hard' optional
    :limit_name: Limit name optional
    :returns: int number of max open files limit
    """
    p = Proc(name=name)
    return p.limits[limit_type][limit_name]


def _threshold_percent(minions, max_open_files):
    """
    Using salts recommended formula calc minion key
    threshold as a percent

    :minions: int count of minion keys
    :max_open_files: int soft limit of max open files 
                     for salt-master process
    :returns: threshold of max minion keys as a percent
    """
    return minions / (max_open_files * 0.25) * 100

if __name__ == '__main__':
    main()

