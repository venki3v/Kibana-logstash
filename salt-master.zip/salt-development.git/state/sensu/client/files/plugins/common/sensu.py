import socket
import time
import warnings
from sys import exit

warnings.filterwarnings("ignore", category=DeprecationWarning)


class Sensu(object):
    """
    Sensu object for creating checks and metrics
    """
    STATE_OK = 0
    STATE_WARNING = 1
    STATE_CRITICAL = 2
    STATE_UNKNOWN = 3
    VALID_STATES = range(0,4)

    def __init__(self, scheme=None):
        """
        :scheme: base scheme of the metric as an str
        """
        if scheme:
            self.scheme = scheme.rstrip('.')
        return

    def output_metric(self, name, value):
        """
        Output metric to stdout
        The metric name will be appended to the base scheme

        :name: name of the metric as an str
        :value: value of the metric as an int
        :returns: prints metric to stdout
        """
        print '{0}.{1}\t{2}\t{3}'.format(self.scheme, name, value, int(time.time()))
        return

    def output_check(self, state, message=''):
        """
        Output check result to stdout

        :state: one of the valid sensu states as an int
        :message: message to show to standard out as an str
        :returns: exit code and message to stdout
        """
        if not self._valid_state(state):
            raise BadSensuCheckState("Please enter a valid Sensu check state.")
        print '{0}'.format(message)
        exit(state)
        return

    def _valid_state(self, state):
        """
        Validates the sensu check state

        :state: the state as an int
        """
        return True if state in self.VALID_STATES else False


class BadSensuCheckState(Exception):
    pass

