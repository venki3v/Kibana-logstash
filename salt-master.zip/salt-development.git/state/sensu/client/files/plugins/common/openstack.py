import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning) 


class OpenStackClient(object):
    """
    Instantiate the OpenStack client and return an instance
    of the requested openstack_client
    """
    openstack_client = ''
    user = ''
    password = ''
    tenant = ''
    auth_url = ''
    api_version = ''
    openstack_clients = ['nova', 'keystone', 'cinder']

    def __init__(self, openstack_client, api_version, user, password, tenant, auth_url):
        self.openstack_client = openstack_client
        self.user = user
        self.password = password
        self.tenant = tenant
        self.auth_url = auth_url
        self.api_version = api_version
        return

    def client(self):
        try:
            if self.openstack_client == 'nova':
                import novaclient.client as client
                c = client.Client(self.api_version, self.user, self.password, self.tenant, self.auth_url)
            elif self.openstack_client == 'keystone':
                import keystoneclient.v2_0.client as client
                c = client.Client(username=self.user, password=self.password, tenant_name=self.tenant, auth_url=self.auth_url)
            elif self.openstack_client == 'cinder':
                import cinderclient.client as client
                c = client.Client(self.api_version, self.user, self.password, self.tenant, self.auth_url)
            else:
                raise Exception("Invalid openstack_client option specified. "
                                "Please select one of the following: {0}".format(self.openstack_clients))
        except ImportError:
            raise ImportError("{0} client not found run 'pip install python-{1}client'".format(self.openstack_client,
                                                                                               self.openstack_client))
        return c
