import subprocess
from collections import OrderedDict


class Proc():
    """
    Instantiates a Proc class that collects information
    about the given process ID or name

    WARNING: TESTED ONLY ON RHEL 6
    """
    def __init__(self, pid='', name=''):
        if not pid and not name:
            raise ProcessIDAndNameNotDefined('Provide either a process '
                                             '"pid" or "name"')
        self.name = name if name else self.get_name(pid)
        self.pid = pid if pid else self.get_pid(name)
        self.limits = self.get_limits(self.pid)
        return

    def __str__(self):
        """
        Class string name of process id and name
        """
        return '<Proc Object(pid: {0}, name: {1})>'.format(self.pid, self.name)

    def _subprocess(self, cmd, shell=False):
        """
        A shortcut method for the subprocess class

        :cmd: command to execute via subprocess
        :shell: execute via shell 
        :returns: tuple of stdout and error
        """
        process = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                   stderr=subprocess.PIPE, shell=shell)
        return process.communicate()

    def get_name(self, pid):
        """
        Gets the process name by ID

        :pid: pid of the process
        :returns: name of the process id
        """
        cmd = ['cat', '/proc/{0}/comm'.format(pid)]
        name, err = self._subprocess(cmd)
        if not name:
            raise ProcessIDDoesNotExist(pid)
        return name.strip()

    def get_pid(self, name):
        """
        Gets parent process ID by name

        :name: name of the process
        :returns: parent process id of the process name
        """
        cmd = ['ps', 'hf', '-opid', '-C', name]
        pid, err = self._subprocess(cmd)
        try:
            pid = int(pid.split('\n')[0])
        except (IndexError, ValueError):
            raise ProcessNameDoesNotExist(name)
        return pid

    def get_limits(self, pid):
        """
        Gets the soft and hard limits for a given process id

        :pid: process id
        :returns: dict with keys 'soft' and 'hard' limit for given 
                  process ID with OrdererdDict of limit names and 
                  values
        """
        def limits(pid, limit):
            """
            :pid: Process ID
            :limit: Limit type of 'soft' or 'hard'
            :returns: dict of limit keys and values
            """
            template = OrderedDict([
                           ('max_cpu_time', ''),
                           ('max_file_size', ''),
                           ('max_data_size', ''),
                           ('max_stack_size', ''),
                           ('max_core_file_size', ''),
                           ('max_resident_set', ''),
                           ('max_processes', ''),
                           ('max_open_files', ''),
                           ('max_locked_memory', ''),
                           ('max_address_space', ''),
                           ('max_file_locks', ''),
                           ('max_pending_signals', ''),
                           ('max_msgqueue_size', ''),
                           ('max_nice_priority', ''),
                           ('max_realtime_priority', ''),
                           ('max_realtime_timeout', '')
                       ])
            limit = '\'{print $1}\'' if limit == 'soft' else '\'{print $2}\''
            cmd = ['cut -c 27- /proc/{0}/limits | awk {1}'.format(pid, limit)]
            limits, err = self._subprocess(cmd, shell=True)
            if err:
                raise GetProcessLimitsFailed()
            else:
                limits = limits.split('\n')[1:]
            for n, limit in enumerate(template):
                try:
                    template[limit] = int(limits[n])
                except ValueError:
                    template[limit] = limits[n]
            return template
        return {'soft': limits(pid, 'soft'), 'hard': limits(pid, 'hard')}


class ProcessIDAndNameNotDefined(Exception):
    pass


class ProcessIDDoesNotExist(Exception):
    pass


class ProcessNameDoesNotExist(Exception):
    pass


class GetProcessLimitsFailed(Exception):
    pass

