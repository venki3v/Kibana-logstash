import ast
from salt.config import minion_config, master_config
from argparse import ArgumentParser
from common.sensu import Sensu

sensu = Sensu()


def main():
    """
    Check if the specified salt configuration key has
    the expected value
    """
    parser = ArgumentParser()
    parser.add_argument('--conf-file', default='/etc/salt/master')
    parser.add_argument('--conf-type', default='master',
                        help='Configuration type of "master" or "minion"')
    parser.add_argument('--key', required=True,
                        help='Configuration key name to compare value to')
    parser.add_argument('--value', default='/etc/salt/master',
                        help='Expected configuration value')
    args = parser.parse_args()
    #
    # Check salt configuration
    result, value = _check_salt_conf(args.conf_file, args.conf_type,
                                     args.key, args.value)
    #
    # Output check state
    if result:
        message = 'Salt configuration "{0}" ' \
                  'has correct value of "{1}" OK'.format(args.key,
                                                         value)
        return sensu.output_check(sensu.STATE_OK, message=message)
    else:
        message = 'Salt configuration "{0}" has invalid value of ' \
                  '"{1}", expected value "{2}" CRITICAL'.format(args.key,
                                                                value,
                                                                args.value)
        return sensu.output_check(sensu.STATE_CRITICAL, message=message)


def _check_salt_conf(conf, conf_type, key, value):
    """
    Validates the salt configuration

    :conf: path to the salt configuration file
    :conf_type: configuration type of 'master' or 'minion'
    :key: key to get in the salt configuration
    :value: value to compare in the salt configuration
    :returns: Tuple of True if configuration valid or False if
              configuration invalid, and the opts[key] value
    """
    try:
        value = ast.literal_eval(value)
    except ValueError:
        pass
    opts = master_config(conf) if 'master' in conf_type else minion_config(conf)
    return (True, opts[key]) if opts[key] == value else (False, opts[key])


if __name__ == '__main__':
    main()

