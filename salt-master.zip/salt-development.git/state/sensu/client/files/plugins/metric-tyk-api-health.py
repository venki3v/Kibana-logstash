from sensu_class import Sensu
from argparse import ArgumentParser
import imp
import requests


def main():
    parser = ArgumentParser()
    parser.add_argument('--scheme', required=True)
    parser.add_argument('--auth-token', required=True)
    parser.add_argument('--api-url', help='example http://api.tyk.acme.com/tyk/health/?api_id=1', required=True)
    args = parser.parse_args()

    scheme = "{0}.tyk.health_status".format(args.scheme.lower())
    sensu = Sensu(scheme)

    headers = {'X-Tyk-Authorization': args.auth_token}

    r = requests.get(args.api_url, headers=headers)

    for check_name, check_value in r.json().iteritems():
        sensu.output_metric("tyk_health_{0}".format(check_name.lower()), check_value)
    return

if __name__ == '__main__':
    main()
