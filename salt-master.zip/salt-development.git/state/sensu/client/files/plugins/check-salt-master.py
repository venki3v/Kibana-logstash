import salt.client
from salt.config import apply_minion_config
from argparse import ArgumentParser
from common.sensu import Sensu

sensu = Sensu()


def main():
    """
    Checks if the specified salt-master is responding to salt ping's
    This check can be ran from any host with a salt-minion installed
    """
    parser = ArgumentParser()
    parser.add_argument('--master', default='localhost')
    args = parser.parse_args()
    #
    #
    # Test.ping salt master which is a functional test
    result = _check_salt_master(args.master)
    #
    #
    # Output check state
    if result:
        message = 'Ping salt-master "{0}" succesful OK'.format(args.master)
        return sensu.output_check(sensu.STATE_OK, message=message)
    else:
        message = 'Ping salt-master "{0}" failed CRITICAL'.format(args.master)
        return sensu.output_check(sensu.STATE_CRITICAL, message=message)


def _check_salt_master(master='localhost'):
    """
    Does a salt test.ping on the specified master host

    :master: ip address or fqdn of salt-master
    :returns: True if ping successful, False if ping failed
    """
    opts = apply_minion_config()
    opts['master'] = master
    opts['auth_timeout'] = 20
    opts['auth_tries'] = 2
    opts['log_level'] = 'quiet'
    opts['log_level_logfile'] = 'quiet'
    try:
        caller = salt.client.Caller(mopts=opts)
        result = caller.function('test.ping')
    except salt.exceptions.SaltClientError:
        result = False
    return True if result else False

if __name__ == '__main__':
    main()

