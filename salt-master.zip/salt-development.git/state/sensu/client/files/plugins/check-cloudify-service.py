######################################################################################
## Name: check-cloudify-services.py
##
## Purpose: Checks the status of a Cloudify service
##          via the Rest API.
##
## Input:
##      ServerUrl(String): The Cloudify Manager URL. (Eg. cloudify.maintenance.eng.cloud.td.com)
##
##      RequestedService(String): The name of the service process to check the health of.
##
## Author: Charles Curran
## Date: 4/14/2015
## Version: 1.1
######################################################################################
import requests
import sys
from argparse import ArgumentParser

# Sensu valid return codes
STATE_OK = 0
STATE_WARNING = 1
STATE_CRITICAL = 2
STATE_UNKNOWN = 3

def main():
    parser = ArgumentParser()
    parser.add_argument('-a',
                        '--apiurl',
                        help='Cloudify rest url example: http://cloudify.acme.com, if not specified will use loopback address.',
                        default='http://127.0.0.1')
    parser.add_argument('-s',
                        '--service',
                        choices=['riemann', 'celeryd-cloudify-management',
                                 'rabbitmq-server', 'manager', 'elasticsearch',
                                 'ssh', 'nginx', 'cloudify-ui', 'rsyslog', 'logstash'],
                        required=True)
    args = parser.parse_args()

    response = requests.get("{0}/status".format(args.apiurl))

    # Error out if API call failed
    if not response.status_code >= 200 and response.status_code >= 299:
        error_text = response.text if response.text else "Unknown"
        print "API call failed with error: {0}".format(error_text)
        sys.exit(STATE_CRITICAL)

    # Get service status
    for service in response.json()['services']:
        if service['name'].lower() == args.service.lower():
            try:
                service_status = service['instances'][0]['state']
                break
            except IndexError:
                print "Cloudify service '{0}' is not running. " \
                      "Service not found.".format(args.service)
                sys.exit(STATE_CRITICAL)
    else:
        print "Cloudify service '{0}' is not running. " \
              "Service not found.".format(args.service)
        sys.exit(STATE_CRITICAL)

        # If not in running state exit with critical error
    if not service_status.upper() == 'RUNNING':
        print "Cloudify service '{0}' is not running. " \
              "Service status is '{1}'".format(args.service, service_status.upper())
        sys.exit(STATE_CRITICAL)

    # State is good exit OK
    print "Cloudify service '{0}' is in nominal status. " \
          "Service status is '{1}'".format(args.service, service_status.upper())
    sys.exit(STATE_OK)
    return


if __name__ == '__main__':
    main()
