######################################################################################################
## Name: Linux-RebootCheck.Py
## 
## Purpose: Checks for a recent reboot of the sysetm. 
##
## Input:
## 		
## 		Frequency(String): The Frequncy between checks to determine if reebot happen between checks.
## 		
## 		MetricScheme(String): The Metric Scheme Name to be used for the influxdb metric.
##
##		Output(String): The name of the service to check the health of. 	
##
## Return:
##		0: No Reeboot Found
##
## Author: Charles Curran
## Date: 7/23/2015
## Version: 1.0 - Original Working Version
#####################################################################################################
import sys
from argparse import ArgumentParser
import time
import socket
import os

# Sensu valid check return codes
STATE_OK = 0
STATE_WARNING = 1
STATE_CRITICAL = 2
STATE_UNKNOWN = 3

def output_result(output,scheme, value, outputMessage):

	if output.lower() == "check":
		print outputMessage
		sys.exit(value)

	if output.lower() == "metric":
		"""
		Output metric to stdout
		"""
		print '{0}\t{1}\t{2}'.format(scheme, value, int(time.time()))
		sys.exit(0)

def main():
	#Read in the parameters provided
	parser = ArgumentParser()
	parser.add_argument('-f',
					'--frequency',
					help='Frequency of the checks in minutes. Check if Up Time is Longer then check frequency meaning it rebooted on previous check',
					required=True)
	parser.add_argument('-ms',
						'--metricscheme',
						help='Metric Sceheme format: Environment.<ENV>.Tenant.<Tenant>.host.<FQDN Hostname (replace . with _ )>.<Metric Name>',
						required=False)
	parser.add_argument('-o',
						'--output',
						choices=['check', 'metric','CHECK','METRIC'],
						required=True)
	args = parser.parse_args()

	#Set Scheme
	if args.metricscheme :
		scheme = args.metricscheme
	else:
		hostname = (socket.gethostname()).replace('.','_')
		env = hostname.split('_')[1]
		tenant =  hostname.split('_')[2]
		scheme = 'env.{0}.lob.{1}.host.{2}.{3}'.format(env,tenant,hostname,'server_reboot_check')

	try:
		# Set Variables
		CheckMessage = ""
		command = "cat /proc/uptime | awk '{print ($1/60)}'"
		frequency = float(args.frequency)
		# Retrieve Uptime in Minutes
		uptime = float(os.popen(command).read().strip())

		# Check Server Up Time is Less then the Last Time Server was checked
		if uptime:
			if uptime > frequency:
				CheckMessage = "{0} uptime is in nominal status. " \
				"Uptime is {1} minutes.".format(hostname, uptime)
				output_result(args.output,scheme,STATE_OK,CheckMessage)
			elif uptime == frequency:
				CheckMessage = "{0} uptime is in warning status. Reboot has occured on edge of check window." \
				"Uptime is {1} minutes.".format(hostname, uptime)
				output_result(args.output,scheme,STATE_WARNING,CheckMessage)
			else:
				CheckMessage = "{0} uptime is in critical status. Reboot has occured after last check. " \
				"Uptime is {1} minutes.".format(hostname, uptime)
				output_result(args.output,scheme,STATE_CRITICAL,CheckMessage)
		else:
			CheckMessage = "'{0} uptime not found.".format(hostname)
			output_result(args.output,scheme,STATE_UNKNOWN,CheckMessage)

	except Exception, e:
		CheckMessage = "Unexpected error occurred traceback: {0}".format(e.message)
		output_result(args.output,scheme,STATE_UNKNOWN,CheckMessage)
	return

if __name__ == '__main__':
	main()