from common.openstack import OpenStackClient
from common.sensu import Sensu
from common.retries import retries
from argparse import ArgumentParser
import socket


@retries(max_tries=3, delay=1, backoff=2)
def main():
    parser = ArgumentParser()
    parser.add_argument('--scheme', required=True)
    parser.add_argument('--user', required=True)
    parser.add_argument('--password', required=True)
    parser.add_argument('--tenant', help='OpenStack tenant name, case sensitive', required=True)
    parser.add_argument('--auth-url', help='Example url http://192.168.0.2:5000/v2.0', required=True)
    parser.add_argument('--auth-version', default=2)
    args = parser.parse_args()

    scheme = "{0}.openstack.servers_status.".format(args.scheme.lower())
    sensu = Sensu(scheme)

    nova = OpenStackClient('nova', args.auth_version, args.user, args.password, args.tenant, args.auth_url).client()

    servers = nova.servers.list()

    # http://docs.openstack.org/api/openstack-compute/2/content/List_Servers-d1e2078.html
    states = {
        'ACTIVE': 0,
        'BUILD': 0,
        'DELETED': 0,
        'ERROR': 0,
        'HARD_REBOOT': 0,
        'PASSWORD': 0,
        'REBOOT': 0,
        'REBUILD': 0,
        'RESCUE': 0,
        'RESIZE': 0,
        'REVERT_RESIZE': 0,
        'SHUTOFF': 0,
        'SUSPENDED': 0,
        'UNKNOWN': 0,
        'VERIFY_RESIZE': 0,
    }

    for server in servers:
        if server.status not in states:
            states[server.status] = 0
        states[server.status] += 1

    for state, count in states.iteritems():
        sensu.output_metric(state.lower(), count)
    return

if __name__ == '__main__':
    main()
