######################################################################################
## Name: check-git-service.Py
## 
## Purpose: Checks the status of a GIT service via git-ctl command. 
##
## Input:
##
##		RequestedService(String): The name of the service to check the health of. 	
##
##		MetricScheme(String): The metric scheme name to be used in influxdb. Optional. 	
##
##		Oouput(String): The ouput format to be returned. 	
##
## Return:
##		0: STATE_OK
##		1: STATE_WARNING
##		2: STATE_CRITICAL
##		3: STATE_UNKNOWN
##
## Author: Charles Curran
## Date: 7/22/2015
## Version: 1.0 - Original Working Version
######################################################################################
import sys
from argparse import ArgumentParser
import time
import socket
import os

# Sensu valid check return codes
STATE_OK = 0
STATE_WARNING = 1
STATE_CRITICAL = 2
STATE_UNKNOWN = 3

def output_result(output,scheme, value, outputMessage):

	if output.lower() == "check":
		print outputMessage
		sys.exit(value)

	if output.lower() == "metric":
		"""
		Output metric to stdout
		"""
		print '{0}\t{1}\t{2}'.format(scheme, value, int(time.time()))
		sys.exit(0)

def main():
	#Read in the parameters provided
	parser = ArgumentParser()
	parser.add_argument('-s',
						'--service',
						choices=['logrotate', 'nginx', 'sidekiq',
								'postgresql', 'redis', 'unicorn'],
						required=True)
	parser.add_argument('-ms',
						'--metricscheme',
						help='Metric Sceheme format: Environment.<ENV>.Tenant.<Tenant>.host.<FQDN Hostname (replace . with _ )>.<Metric Name>',
						required=False)
	parser.add_argument('-o',
						'--output',
						choices=['check', 'metric'],
						required=True)
	args = parser.parse_args()

	#Set Scheme
	if args.metricscheme :
		scheme = args.metricscheme
	else:
		hostname = (socket.gethostname()).replace('.','_')
		env = hostname.split('_')[1]
		tenant =  hostname.split('_')[2]
		scheme = 'env.{0}.lob.{1}.host.{2}.{3}.{4}'.format(env,tenant,hostname,'git_service_health_check',args.service)

	command = 'sudo /usr/bin/gitlab-ctl status {0}'.format(args.service)

	try:
		CheckMessage = ""
		
		# Check for the Request Service
		response = os.popen(command).read()
		result = response.strip().split(';')[0].split(":")
		service = result[1].strip()

		# Get service status
		if service.upper() == args.service.upper():
			service_status = result[0].strip()
		else:
			CheckMessage = "Service {0} not found.".format(args.service)
			output_result(args.output,scheme,STATE_UNKNOWN,CheckMessage)

		# If not in running state exit with critical error
		if not service_status.upper() == 'RUN':
			downtime = result[2].split(",")[0].strip(" ")
			CheckMessage = "GIT service '{0}' is not running. " \
				"Service status is '{1}'".format(args.service, service_status.upper())
			output_result(args.output,scheme,STATE_CRITICAL,CheckMessage)

		# State is good exit OK
		processDetails = result[2].strip("(").split(")")
		pid = processDetails[0]
		uptime = processDetails[1]
		CheckMessage = "GIT service '{0}' is in nominal status. " \
			"Service status is '{1}'".format(args.service, service_status.upper())
		output_result(args.output,scheme,STATE_OK,CheckMessage)

		 # run: redis: (pid 2497) 262048s; run: log: (pid 30036) 269179s
		 # down: redis: 3s, normally up; run: log: (pid 30036) 269205s
	except Exception, e:
		CheckMessage = "Unexpected error occurred traceback: {0}".format(e.message)
		output_result(args.output,scheme,STATE_UNKNOWN,CheckMessage)
	return

if __name__ == '__main__':
	main()