RULES FOR CREATING SENSU PLUGINS

Plugin Naming Convention:
1. Plugin names must start with 'metric' or 'check'
2. Plugin names must use dashs as spaces '-'
3. Plugin names be all lowercase

Shared Helper Libraries:
Shared libraries must be stored in the common folder

