from common.openstack import OpenStackClient
from common.sensu import Sensu
from common.retries import retries
from argparse import ArgumentParser


@retries(max_tries=3, delay=1, backoff=2)
def main():
    parser = ArgumentParser()
    parser.add_argument('--scheme', required=True)
    parser.add_argument('--user', required=True)
    parser.add_argument('--password', required=True)
    parser.add_argument('--tenant', help='OpenStack tenant name, case sensitive', required=True)
    parser.add_argument('--auth-url', help='Example url http://192.168.0.2:5000/v2.0', required=True)
    parser.add_argument('--auth-version', default=2)
    args = parser.parse_args()

    scheme = "{0}.openstack.quota_usage".format(args.scheme.lower())
    sensu = Sensu(scheme)

    nova = OpenStackClient('nova', args.auth_version, args.user, args.password, args.tenant, args.auth_url).client()
    keystone = OpenStackClient('keystone', args.auth_version, args.user, args.password, args.tenant, args.auth_url).client()    
    cinder = OpenStackClient('cinder', args.auth_version, args.user, args.password, args.tenant, args.auth_url).client()

    tenant_id = keystone.tenants.find(name=args.tenant).id

    servers = nova.servers.list()
    cinder_quotas = cinder.quotas.get(tenant_id=tenant_id, usage=True)

    cores = 0
    ram = 0
    instances = len(servers)

    for server in servers:
        flavor = nova.flavors.get(server.flavor['id'])
        if flavor:
            cores += flavor.vcpus
            ram += flavor.ram

    sensu.output_metric('cores', cores)
    sensu.output_metric('ram', ram)
    sensu.output_metric('instances', instances)
    sensu.output_metric('volumes_size', cinder_quotas.gigabytes['in_use'])
    sensu.output_metric('volumes', cinder_quotas.volumes['in_use'])
    return

if __name__ == '__main__':
    main()
