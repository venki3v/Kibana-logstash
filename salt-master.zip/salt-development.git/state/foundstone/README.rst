Foundstone Clientless Agent
===========================

Description:
~~~~~~~~~~~~
McAfee Vulnerability Manager AKA Foundstone is a vulnerability scanner that will scan networks for nodes
when a node is found the nodes ports are scanned and it logs into the node and it looks for patching
levels for products installed.

Supported Operating Systems:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- RedHat

Key contacts:
~~~~~~~~~~~~~
- TRMIS Contact: Channa, Balkar <Balkar.Channa@td.com>