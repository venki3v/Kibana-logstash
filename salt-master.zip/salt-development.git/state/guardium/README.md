Guardium (Database Auditing) Salt State
=======================================

Description:
~~~~~~~~~~~~
IBM® InfoSphere® Guardium® Data Activity Monitor prevents unauthorized 
data access, alerts on changes or leaks to help ensure data integrity, 
automates compliance controls and protects against internal and external 
threats. Continuous monitoring and real time security policies protect 
data across the enterprise without changes to databases or applications 
or performance impact. InfoSphere Guardium Data Activity Monitor is a 
market leader for big data security solutions delivering a 239% ROI in 
less than 6 months and protects data at the source where controls 
are the most scalable and effective.

Dependencies:
~~~~~~~~~~~~~
Python 2.6+ Libraries

Supported Operating Systems:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
- RedHat
- Windows

Key contacts:
~~~~~~~~~~~~~
- Salt Formula:  Sinclair, Ian J <ian.j.sinclair@td.com>
- Operational:   Szabo, Steve <steve.szabo@td.com>
- Compliance:    Ptacnik, Daniel <daniel.ptacnik@td.com>
