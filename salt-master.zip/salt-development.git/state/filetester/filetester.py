import logging
import shutil
import os

# Setup logging
try:
    os.remove("filetester.log")
except OSError:
    pass 
logging.basicConfig(filename='filetester.log', format='%(asctime)s %(levelname)s: %(message)s', level=logging.DEBUG)

# Salt client api
import salt.client  # Import salt.client messes with logging if not previously initialized
saltcaller = salt.client.Caller()

# Number of times to test
test_runs = 10

# Testing folder
f = "/tmp/filetester"

# Collect results
results_summary = []

# Break stuff
for test_run in range(test_runs):
    msg = "...starting file.managed test {0}/{1}...".format(test_run + 1, test_runs)
    logging.info(msg)
    print (msg)

    results_dict = {'test_run': test_run, 'success_results': [], 'error_results': []}

    logging.info("starting filetester state...")
    results = saltcaller.function('state.sls', 'filetester')

    logging.info("verifying results...")
    for k, data in results.iteritems():
        l = k.split('_|-')

        if not data['result']:
            error_msg =  "File test failed on state {0}! State comment: {1}, State result: {2}".format(l[1], data['comment'], data['result'])
            logging.error(error_msg)
            results_dict['error_results'].append(error_msg)
        else:
            success_msg = "File test passed on state {0}! State comment: {1}, State result: {2}".format(l[1], data['comment'], data['result'])
            logging.info(success_msg)
            results_dict['success_results'].append(success_msg)
 
    logging.info("cleaning test data")
    shutil.rmtree(f)
    shutil.rmtree("/var/cache/salt/minion/files")
    
    results_summary.append(results_dict)

# Print results
error_count = 0
success_count = 0
for r in results_summary:
   error_count += len(r['error_results'])
   success_count += len(r['success_results'])

e = "file.managed state errors: {0}".format(error_count)
s = "file.managed state successes: {0}".format(success_count)

logging.info(e)
logging.info(s)

print ""
print e 
print s 
print ""
print "view the filetester.log for more details"
print ""
